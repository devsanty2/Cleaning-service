<?php
namespace TwinkleCore;

use TwinkleCore\PageSettings\Page_Settings;
use Elementor\Controls_Manager;


/**
 * Class Plugin
 *
 * Main Plugin class
 * @since 1.2.0
 */
class Twinkle_Core_Plugin {

	/**
	 * Instance
	 *
	 * @since 1.2.0
	 * @access private
	 * @static
	 *
	 * @var Plugin The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.2.0
	 * @access public
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Add Category
	 */

    public function twinkle_core_elementor_category($manager)
    {
        $manager->add_category(
            'twinkle_core',
            array(
                'title' => esc_html__('Twinkle Core Addons', 'twinkle-core'),
                'icon' => 'eicon-banner',
            )
        );
    }

	/**
	 * widget_styles
	 *
	 * Load required plugin core files.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function widget_styles() {
		wp_enqueue_style('twinkle-core', TWINKLE_CORE_ADDONS_URL . 'assets/css/twinkle-core.css', null, '1.0');
	}

	/**
	 * widget_scripts
	 *
	 * Load required plugin core files.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function widget_scripts() {
		wp_enqueue_script( 'twinkle-core', plugins_url( '/assets/js/hello-world.js', __FILE__ ), [ 'jquery' ], false, true );
	}

	/**
	 * Editor scripts
	 *
	 * Enqueue plugin javascripts integrations for Elementor editor.
	 *
	 * @since 1.2.1
	 * @access public
	 */
	public function editor_scripts() {
		add_filter( 'script_loader_tag', [ $this, 'editor_scripts_as_a_module' ], 10, 2 );

		wp_enqueue_script(
			'twinkle_core-editor',
			plugins_url( '/assets/js/editor/editor.js', __FILE__ ),
			[
				'elementor-editor',
			],
			'1.2.1',
			true
		);
	}


	/**
	 * twinkle_enqueue_editor_scripts
	 */
    function twinkle_enqueue_editor_scripts()
    {
        wp_enqueue_style('twinkle-element-addons-editor', TWINKLE_CORE_ADDONS_URL . 'assets/css/editor.css', null, '1.0');
    }

	/**
	 * Force load editor script as a module
	 *
	 * @since 1.2.1
	 *
	 * @param string $tag
	 * @param string $handle
	 *
	 * @return string
	 */
	public function editor_scripts_as_a_module( $tag, $handle ) {
		if ( 'twinkle-core-editor' === $handle ) {
			$tag = str_replace( '<script', '<script type="module"', $tag );
		}

		return $tag;
	}

	/**
	 * Register Widgets
	 *
	 * Register new Elementor widgets.
	 *
	 * @since 1.2.0
	 * @access public
	 *
	 * @param Widgets_Manager $widgets_manager Elementor widgets manager.
	 */
	public function register_widgets( $widgets_manager ) {
		// Its is now safe to include Widgets files
		foreach($this->twinkle_core_widget_list() as $widget_file_name){
			require_once( TWINKLE_CORE_ELEMENTS_PATH . "/{$widget_file_name}.php" );
		}
	}

	public function twinkle_core_widget_list() {
		return [
			'advanced-tab',
			'heading',
			'slider',
			'about',
			'services',
			'service-list',
			'project',
			'project-info',
			'promotion',
			'team',
			'team-slider',
			'team-details',
			'pricing',
			'features',
			'testimonial-slider',
			'blog-post',
			'post-list',
			'gallery',
			'gallery-info',
			'faq',
			'skill',
			'fun-fact',
			'video-popup',
			'brand',
			'brand-slider',
			'image',
			'image-slider',
			'cta',
			'contact-info',
			'contact-form',
			'info-point',
			'twinkle-btn',
		];
	}

	/**
	 * Add page settings controls
	 *
	 * Register new settings for a document page settings.
	 *
	 * @since 1.2.1
	 * @access private
	 */
	private function add_page_settings_controls() {
		require_once( __DIR__ . '/page-settings/manager.php' );
		new Page_Settings();
	}

	/**
	 * Register controls
	 *
	 * @param Controls_Manager $controls_Manager
	 */

    public function register_controls(Controls_Manager $controls_Manager)
    {
        include_once(TWINKLE_CORE_ADDONS_DIR . '/controls/twinklegradient.php');
        $twinklegradient = 'TwinkleCore\Elementor\Controls\Group_Control_TWINKLEGradient';
        $controls_Manager->add_group_control($twinklegradient::get_type(), new $twinklegradient());

        include_once(TWINKLE_CORE_ADDONS_DIR . '/controls/twinklebggradient.php');
        $twinklebggradient = 'TwinkleCore\Elementor\Controls\Group_Control_TWINKLEBGGradient';
        $controls_Manager->add_group_control($twinklebggradient::get_type(), new $twinklebggradient());
    }

    public function twinkle_add_custom_icons_tab($tabs = array()){

        // Append new icons
        $twinkle_icons = array(
            'icon-email',
            'icon-wall-clock',
            'icon-house',
            'icon-window-cleaning',
            'icon-flat',
            'icon-carpet-cleaner',
            'icon-house-1',
            'icon-house-2',
            'icon-electric-vehicle',
            'icon-link',
            'icon-left-quote',
            'icon-plus',
            'icon-facebook',
            'icon-instagram',
            'icon-twitter',
            'icon-maps-and-flags',
            'icon-certificate-1',
            'icon-rating',
            'icon-certificate',
            'icon-computer',
        );

        $tabs['twinkle-icons'] = array(
            'name' => 'twinkle-icons',
            'label' => esc_html__('Twinkle Core Icons', 'twinkle-core'),
            'labelIcon' => 'twinkle-icon',
            'prefix' => '',
            'displayPrefix' => '',
            'url' => TWINKLE_CORE_ADDONS_URL . 'assets/vendors/conult-icons/style.css',
            'icons' => $twinkle_icons,
            'ver' => '1.0.0',
        );

        return $tabs;
    }

	/**
	 *  Plugin class constructor
	 *
	 * Register plugin action hooks and filters
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function __construct() {

        add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'widget_styles' ] );
        add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'widget_scripts' ] );

		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );

		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'editor_scripts' ] );

		add_action('elementor/elements/categories_registered', [$this, 'twinkle_core_elementor_category']);

	    add_action('elementor/controls/controls_registered', [$this, 'register_controls']);

	    add_filter('elementor/icons_manager/additional_tabs', [$this, 'twinkle_add_custom_icons_tab']);

	    add_action('elementor/editor/after_enqueue_scripts', [$this, 'twinkle_enqueue_editor_scripts'] );

		$this->add_page_settings_controls();

	}
}

// Instantiate Plugin Class
Twinkle_Core_Plugin::instance();