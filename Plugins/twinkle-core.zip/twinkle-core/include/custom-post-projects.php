<?php 
class TwinkleProjectPost 
{
	function __construct() {
		add_action( 'init', array( $this, 'register_custom_post_type' ) );
		add_action( 'init', array( $this, 'create_cat' ) );
		add_filter( 'template_include', array( $this, 'project_template_include' ) );
	}
	
	public function project_template_include( $template ) {
		if ( is_singular( 'project' ) ) {
			return $this->get_template( 'single-project.php');
		}
		return $template;
	}
	
	public function get_template( $template ) {
		if ( $theme_file = locate_template( array( $template ) ) ) {
			$file = $theme_file;
		} 
		else {
			$file = TWINKLE_CORE_ADDONS_DIR . '/include/template/'. $template;
		}
		return apply_filters( __FUNCTION__, $file, $template );
	}
	
	
	public function register_custom_post_type() {
		// $medidove_mem_slug = get_theme_mod('medidove_mem_slug','member'); 
		$labels = array(
			'name'                  => esc_html_x( 'Projects', 'Post Type General Name', 'twinkle-core' ),
			'singular_name'         => esc_html_x( 'Project', 'Post Type Singular Name', 'twinkle-core' ),
			'menu_name'             => esc_html__( 'Projects', 'twinkle-core' ),
			'name_admin_bar'        => esc_html__( 'Project', 'twinkle-core' ),
			'archives'              => esc_html__( 'Item Archives', 'twinkle-core' ),
			'parent_item_colon'     => esc_html__( 'Parent Item:', 'twinkle-core' ),
			'all_items'             => esc_html__( 'All Items', 'twinkle-core' ),
			'add_new_item'          => esc_html__( 'Add New Project', 'twinkle-core' ),
			'add_new'               => esc_html__( 'Add New', 'twinkle-core' ),
			'new_item'              => esc_html__( 'New Item', 'twinkle-core' ),
			'edit_item'             => esc_html__( 'Edit Item', 'twinkle-core' ),
			'update_item'           => esc_html__( 'Update Item', 'twinkle-core' ),
			'view_item'             => esc_html__( 'View Item', 'twinkle-core' ),
			'search_items'          => esc_html__( 'Search Item', 'twinkle-core' ),
			'not_found'             => esc_html__( 'Not found', 'twinkle-core' ),
			'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'twinkle-core' ),
			'featured_image'        => esc_html__( 'Featured Image', 'twinkle-core' ),
			'set_featured_image'    => esc_html__( 'Set featured image', 'twinkle-core' ),
			'remove_featured_image' => esc_html__( 'Remove featured image', 'twinkle-core' ),
			'use_featured_image'    => esc_html__( 'Use as featured image', 'twinkle-core' ),
			'inserbt_into_item'     => esc_html__( 'Insert into item', 'twinkle-core' ),
			'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'twinkle-core' ),
			'items_list'            => esc_html__( 'Items list', 'twinkle-core' ),
			'items_list_navigation' => esc_html__( 'Items list navigation', 'twinkle-core' ),
			'filter_items_list'     => esc_html__( 'Filter items list', 'twinkle-core' ),
		);

		$args   = array(
			'label'                 => esc_html__( 'Project', 'twinkle-core' ),
			'labels'                => $labels,
			'supports'              => array( 'title', 'editor', 'excerpt', 'thumbnail'),
			'hierarchical'          => false,
			'public'                => true,
			'show_ui'               => true,
			'show_in_menu'          => true,
			'menu_position'         => 5,
			'menu_icon'   			=> 'dashicons-index-card',
			'show_in_admin_bar'     => true,
			'show_in_nav_menus'     => true,
			'can_export'            => true,
			'has_archive'           => true,		
			'exclude_from_search'   => false,
			'publicly_queryable'    => true,
			'capability_type'       => 'page',
		);

		register_post_type( 'project', $args );
	}
	
	public function create_cat() {
		$labels = array(
			'name'                       => esc_html_x( 'Project Categories', 'Taxonomy General Name', 'twinkle-core' ),
			'singular_name'              => esc_html_x( 'Project Categories', 'Taxonomy Singular Name', 'twinkle-core' ),
			'menu_name'                  => esc_html__( 'Project Categories', 'twinkle-core' ),
			'all_items'                  => esc_html__( 'All Project Category', 'twinkle-core' ),
			'parent_item'                => esc_html__( 'Parent Item', 'twinkle-core' ),
			'parent_item_colon'          => esc_html__( 'Parent Item:', 'twinkle-core' ),
			'new_item_name'              => esc_html__( 'New Project Category Name', 'twinkle-core' ),
			'add_new_item'               => esc_html__( 'Add New Project Category', 'twinkle-core' ),
			'edit_item'                  => esc_html__( 'Edit Project Category', 'twinkle-core' ),
			'update_item'                => esc_html__( 'Update Project Category', 'twinkle-core' ),
			'view_item'                  => esc_html__( 'View Project Category', 'twinkle-core' ),
			'separate_items_with_commas' => esc_html__( 'Separate items with commas', 'twinkle-core' ),
			'add_or_remove_items'        => esc_html__( 'Add or remove items', 'twinkle-core' ),
			'choose_from_most_used'      => esc_html__( 'Choose from the most used', 'twinkle-core' ),
			'popular_items'              => esc_html__( 'Popular Project Category', 'twinkle-core' ),
			'search_items'               => esc_html__( 'Search Project Category', 'twinkle-core' ),
			'not_found'                  => esc_html__( 'Not Found', 'twinkle-core' ),
			'no_terms'                   => esc_html__( 'No Project Category', 'twinkle-core' ),
			'items_list'                 => esc_html__( 'Project Category list', 'twinkle-core' ),
			'items_list_navigation'      => esc_html__( 'Project Category list navigation', 'twinkle-core' ),
		);

		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
		);

		register_taxonomy('project-cat','project', $args );
	}

}

new TwinkleProjectPost();