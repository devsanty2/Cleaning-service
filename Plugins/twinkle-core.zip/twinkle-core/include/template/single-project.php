<?php 
/** 
 * The main template file
 *
 * @package  WordPress
 * @subpackage  Twinkle Core
 */
get_header(); 

?>

   <section class="all-project">
      <div class="container">
         <div class="row">
            <div class="col-xl-12">
               <?php the_content(); ?>
            </div>
         </div>
      </div>
   </section>

<?php get_footer();  ?>