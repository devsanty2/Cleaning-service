<?php 
/** 
 * The main template file
 *
 * @package  WordPress
 * @subpackage  tpcore
 */
get_header(); 

?>


<?php the_content(); ?>


<?php get_footer();  ?>