<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;

use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Post_List extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_post_list';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Post List', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        $this->start_controls_section(
            'twinkle_post_list',
            [
                'label' => esc_html__('Gallery Info', 'twinkle-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'twinkle_title', [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Recent Posts', 'twinkle-core'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'twinkle_post_list_date', [
                'label' => esc_html__('Date', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'twinkle_post_list_title', [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        
        $repeater->add_control(
            'twinkle_post_link_switcher',
            [
                'label' => esc_html__( 'Add Services link', 'twinkle-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'twinkle-core' ),
                'label_off' => esc_html__( 'No', 'twinkle-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $repeater->add_control(
            'twinkle_post_link_type',
            [
                'label' => esc_html__( 'Service Link Type', 'twinkle-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'twinkle_post_link_switcher' => 'yes'
                ]
            ]
        );

        $repeater->add_control(
            'twinkle_post_link',
            [
                'label' => esc_html__( 'Service Link link', 'twinkle-core' ),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'https://your-link.com', 'twinkle-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'twinkle_post_link_type' => '1',
                    'twinkle_post_link_switcher' => 'yes',
                ]
            ]
        );

        $repeater->add_control(
            'twinkle_post_page_link',
            [
                'label' => esc_html__( 'Select Service Link Page', 'twinkle-core' ),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => twinkle_get_all_pages(),
                'condition' => [
                    'twinkle_post_link_type' => '2',
                    'twinkle_post_link_switcher' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'twinkle_post_list_list',
            [
                'label' => esc_html__('Info List', 'twinkle-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'twinkle_post_list_date' => esc_html__('21 June, 2023', 'twinkle-core'),
                        'twinkle_post_list_title' => esc_html__('It is a long established fact that a reader', 'twinkle-core'),
                    ],
                    [
                        'twinkle_post_list_date' => esc_html__('21 June, 2023', 'twinkle-core'),
                        'twinkle_post_list_title' => esc_html__('There are many variations of passages', 'twinkle-core'),
                    ],
                    [
                        'twinkle_post_list_date' => esc_html__('21 June, 2023', 'twinkle-core'),
                        'twinkle_post_list_title' => esc_html__('The standard chunk of Lorem Ipsum used', 'twinkle-core'),
                    ],
                ],
                'title_field' => '{{{ twinkle_post_list_title }}}',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            '_section_layout_style',
            [
                'label' => __( 'Design Layout', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .list-unstyled.all-project__list li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .list-unstyled.all-project__list li' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_border_color',
            [
                'label' => __( 'Border', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .list-unstyled.all-project__list li' => 'border-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'content_border_color_hover',
            [
                'label' => __( 'Border (Hover)', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .list-unstyled.all-project__list li:hover' => 'border-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_info_list_style',
            [
                'label' => __( 'Info List', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            '_heading_label',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Label', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'label_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .all-project__name' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'label_typography',
                'selector' => '{{WRAPPER}} .all-project__name',
            ]
        );

        $this->add_responsive_control(
            'label_width',
            [
                'label' => __( 'Width', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
				],
                'selectors' => [
                    '{{WRAPPER}} .all-project__name-box' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            '_content_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .all-project__content' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .all-project__content',
            ]
        );

        $this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

            <div class="projects-detalis__sidebar-single pd-b22 wow animated fadeInUp">
                <div class="projects-detalis__sidebar-recent-post">
                    <?php if ( !empty($settings['twinkle_title']) ) : ?>
                        <div class="title">
                            <h2><?php echo twinkle_kses($settings['twinkle_title' ]); ?></h2>
                        </div>
                    <?php endif; ?>
                    
                    <ul class="projects-detalis__sidebar-recent-post-list pl-0">
                        <?php foreach ($settings['twinkle_post_list_list'] as $item) : 
                            // Link
                            if ('2' == $item['twinkle_post_link_type']) {
                                $link = get_permalink($item['twinkle_post_page_link']);
                                $target = '_self';
                                $rel = 'nofollow';
                            } else {
                                $link = !empty($item['twinkle_post_link']['url']) ? $item['twinkle_post_link']['url'] : '';
                                $target = !empty($item['twinkle_post_link']['is_external']) ? '_blank' : '';
                                $rel = !empty($item['twinkle_post_link']['nofollow']) ? 'nofollow' : '';
                            }
                        ?>
                        <li>
                            <div class="post-date"><i class="far fa-clock"></i> <?php echo twinkle_kses($item['twinkle_post_list_date' ]); ?> </div>
                            <h4>
                                <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>">
                                    <?php echo twinkle_kses($item['twinkle_post_list_title' ]); ?>
                                </a>
                            </h4>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

        <?php 
	}
}

$widgets_manager->register( new Twinkle_Post_List() );