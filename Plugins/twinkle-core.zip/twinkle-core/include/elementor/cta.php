<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Cta extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_cta';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'CTA', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        $this->start_controls_section(
            'twinkle_cta_content',
            [
                'label' => esc_html__('CTA', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_image',
            [
                'label' => esc_html__( 'Choose Image', 'twinkle-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'twinkle_title',
            [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Our Best Service', 'twinkle-core'),
                'placeholder' => esc_html__('Type Heading Text', 'twinkle-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'twinkle-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'twinkle-core'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'twinkle-core'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'twinkle-core'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'twinkle-core'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'twinkle-core'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'twinkle-core'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );

        $this->add_control(
            'twinkle_phone_number',
            [
                'label' => esc_html__('Phone', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('+019999999', 'twinkle-core'),
                'placeholder' => esc_html__('Type Heading Text', 'twinkle-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_btn_text',
            [
                'label' => esc_html__('Button Text', 'twinkle-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'twinkle-core'),
                'title' => esc_html__('Enter button text', 'twinkle-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_btn_link',
            [
                'label' => esc_html__('Button link', 'twinkle-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'twinkle-core'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'twinkle_btn_link_type' => '1',
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'twinkle_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'twinkle-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => twinkle_get_all_pages(),
                'condition' => [
                    'twinkle_btn_link_type' => '2',
                ]
            ]
        );
        
        $this->end_controls_section();

		$this->start_controls_section(
			'twinkle_cta_style',
			[
				'label' => __( 'CTA', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
            '_heading_title',
            [
                'label' => esc_html__( 'Title', 'twinkle-core' ),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .cta-one__inner .title h1' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .cta-one__inner .title h2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .cta-one__inner .title h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .cta-one__inner .title h4' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .cta-one__inner .title h5' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .cta-one__inner .title h6' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cta-one__inner .title h1' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .cta-one__inner .title h2' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .cta-one__inner .title h3' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .cta-one__inner .title h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .cta-one__inner .title h5' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .cta-one__inner .title h6' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'    => esc_html__( 'Typography', 'twinkle-core' ),
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .cta-one__inner .title h1, .cta-one__inner .title h2, .cta-one__inner .title h3, .cta-one__inner .title h4, .cta-one__inner .title h5, .cta-one__inner .title h6',
            ]
        );

        $this->add_control(
            '_heading_phone',
            [
                'label' => esc_html__( 'Phone', 'twinkle-core' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'phone_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .cta-one__inner .title .number p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .cta-one__inner .title .number p a' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'phone_color',
            [
                'label' => esc_html__( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cta-one__inner .title .number p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .cta-one__inner .title .number p a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'    => esc_html__( 'Typography', 'twinkle-core' ),
                'name'     => 'phone_typography',
                'selector' => '{{WRAPPER}} .cta-one__inner .title .number p, .cta-one__inner .title .number p a',
            ]
        );

        $this->add_control(
            '_heading_button',
            [
                'label' => esc_html__( 'Button', 'twinkle-core' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'button_color',
            [
                'label'     => esc_html__( 'Color', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cta-one__inner .button-box .thm-btn span'    => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_background',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .cta-one__inner .button-box .thm-btn .liquid' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'twinkle-core' ),
                'type'      => Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn' => 'border-radius: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'    => esc_html__( 'Typography', 'twinkle-core' ),
                'name'     => 'button_typography',
                'selector' => '{{WRAPPER}} .thm-btn span',
            ]
        );

        $this->add_control(
            '_heading_cta_layout',
            [
                'label' => esc_html__( 'Layout', 'text-domain' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'cta_layout_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .cta-one .image-layer::before',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        // Link
        if ('2' == $settings['twinkle_btn_link_type']) {
            $this->add_render_attribute('twinkle-button-arg', 'href', get_permalink($settings['twinkle_btn_page_link']));
            $this->add_render_attribute('twinkle-button-arg', 'target', '_self');
            $this->add_render_attribute('twinkle-button-arg', 'rel', 'nofollow');
            $this->add_render_attribute('twinkle-button-arg', 'class', 'thm-btn service-details__btn');
        } else {
            if ( ! empty( $settings['twinkle_btn_link']['url'] ) ) {
                $this->add_link_attributes( 'twinkle-button-arg', $settings['twinkle_btn_link'] );
                $this->add_render_attribute('twinkle-button-arg', 'class', 'thm-btn service-details__btn');
            }
        }

		?>
            <section class="cta-one cta-one--gallery">
                <div class="image-layer" style="background-image: url(<?php echo $settings['twinkle_image']['url']; ?>"></div>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="cta-one__inner">
                                <div class="title">
                                    <h2>
                                        <?php
                                            if ( !empty($settings['twinkle_title' ]) ) :
                                                printf( '<%1$s %2$s>%3$s</%1$s>',
                                                    tag_escape( $settings['twinkle_title_tag'] ),
                                                    $this->get_render_attribute_string( 'title_args' ),
                                                    twinkle_kses( $settings['twinkle_title' ] )
                                                    );
                                            endif;
                                        ?> 
                                    </h2>
                                    <div class="number">
                                        <p>Call: <a href="tel:+<?php echo esc_attr__( $settings['twinkle_phone_number'] ); ?>"><?php echo esc_html__( $settings['twinkle_phone_number'] ); ?></a></p>
                                    </div>
                                </div>
                                <?php if (!empty($settings['twinkle_btn_text'])) : ?>
                                    <div class="button-box">
                                        <a <?php echo $this->get_render_attribute_string( 'twinkle-button-arg' ); ?> class="thm-btn">
                                            <span><?php echo $settings['twinkle_btn_text']; ?></span>
                                            <div class="liquid"></div>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        <?php 
	}
}

$widgets_manager->register( new Twinkle_Cta() );