<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Blog_Post extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_blog_post';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Blog Post', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        $this->start_controls_section(
            'twinkle_section_title',
            [
                'label' => esc_html__('Title & Content', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_design_style',
            [
                'label' => esc_html__( 'Style', 'twinkle-core' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'layout-1',
                'options' => [
                    'layout-1' => esc_html__( 'Layout 1', 'twinkle-core' ),
                    'layout-2'  => esc_html__( 'Layout 2', 'twinkle-core' ),
                ],
            ]
        );

        $this->add_control(
            'twinkle_sub_title',
            [
                'label' => esc_html__('Sub Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Our Blog', 'twinkle-core'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'twinkle-core'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'twinkle_title',
            [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Latest News & Articles', 'twinkle-core'),
                'placeholder' => esc_html__('Type Heading Text', 'twinkle-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_description',
            [
                'label' => esc_html__('Description', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('will reenergize your ome and enhance your life. From everyday housekeeping to routine cleanings, our professional this to members can provide you.', 'twinkle-core'),
                'placeholder' => esc_html__('Type section description here', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'twinkle-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'twinkle-core'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'twinkle-core'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'twinkle-core'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'twinkle-core'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'twinkle-core'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'twinkle-core'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );

        $this->add_control(
			'blog_bg_img_1',
			[
				'label' => esc_html__( 'Choose Image', 'twinkle-core' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
        
        $this->end_controls_section();

        // Blog Query
		$this->start_controls_section(
            'twinkle_post_query',
            [
                'label' => esc_html__('Blog Query', 'twinkle-core'),
            ]
        );

        $post_type = 'post';
        $taxonomy = 'category';

        $this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__('Posts Per Page', 'twinkle-core'),
                'description' => esc_html__('Leave blank or enter -1 for all.', 'twinkle-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => '3',
            ]
        );

        $this->add_control(
            'category',
            [
                'label' => esc_html__('Include Categories', 'twinkle-core'),
                'description' => esc_html__('Select a category to include or leave blank for all.', 'twinkle-core'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => twinkle_get_categories($taxonomy),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'exclude_category',
            [
                'label' => esc_html__('Exclude Categories', 'twinkle-core'),
                'description' => esc_html__('Select a category to exclude', 'twinkle-core'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => twinkle_get_categories($taxonomy),
                'label_block' => true
            ]
        );

        $this->add_control(
            'post__not_in',
            [
                'label' => esc_html__('Exclude Item', 'twinkle-core'),
                'type' => Controls_Manager::SELECT2,
                'options' => twinkle_get_all_types_post($post_type),
                'multiple' => true,
                'label_block' => true
            ]
        );

        $this->add_control(
            'offset',
            [
                'label' => esc_html__('Offset', 'twinkle-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => '0',
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => esc_html__('Order By', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => array(
			        'ID' => 'Post ID',
			        'author' => 'Post Author',
			        'title' => 'Title',
			        'date' => 'Date',
			        'modified' => 'Last Modified Date',
			        'parent' => 'Parent Id',
			        'rand' => 'Random',
			        'comment_count' => 'Comment Count',
			        'menu_order' => 'Menu Order',
			    ),
                'default' => 'date',
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => esc_html__('Order', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc' 	=> esc_html__( 'Ascending', 'twinkle-core' ),
                    'desc' 	=> esc_html__( 'Descending', 'twinkle-core' )
                ],
                'default' => 'desc',

            ]
        );
        $this->add_control(
            'ignore_sticky_posts',
            [
                'label' => esc_html__( 'Ignore Sticky Posts', 'twinkle-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'twinkle-core' ),
                'label_off' => esc_html__( 'No', 'twinkle-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'twinkle_blog_title_word',
            [
                'label' => esc_html__('Title Word Count', 'twinkle-core'),
                'description' => esc_html__('Set how many word you want to displa!', 'twinkle-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => '6',
            ]
        );

        $this->add_control(
            'twinkle_post_content',
            [
                'label' => __('Content', 'twinkle-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'twinkle-core'),
                'label_off' => __('Hide', 'twinkle-core'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'twinkle_post_content_limit',
            [
                'label' => __('Content Limit', 'twinkle-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '14',
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'twinkle_post_content' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'twinkle_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'twinkle-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'twinkle-core' ),
                'label_off' => esc_html__( 'Hide', 'twinkle-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'twinkle_btn_text',
            [
                'label' => esc_html__('Button Text', 'twinkle-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'twinkle-core'),
                'title' => esc_html__('Enter button text', 'twinkle-core'),
                'label_block' => true,
                'condition' => [
                    'twinkle_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_layout_style',
            [
                'label' => __( 'Design Layout', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'section_content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .blog-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'section_content_background',
            [
                'label' => __( 'Content Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-one' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_style_content',
            [
                'label' => __( 'Title & Content', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // Subtitle    
        $this->add_control(
            '_section_subtitle',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Subtitle', 'twinkle-core' ),
            ]
        );

        $this->add_responsive_control(
            'section_subtitle_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__tagline' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'section_subtitle_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__tagline' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'section_subtitle_typography',
                'selector' => '{{WRAPPER}} .section-title__tagline',
            ]
        );

        // Title
        $this->add_control(
            '_section_heading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'section_title_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'section_title_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'section_title_typography',
                'selector' => '{{WRAPPER}} .section-title__title',
            ]
        );

        // Description
        $this->add_control(
            '_section_content_description',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Description', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'section_description_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__text' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .section-title__style2 .text-box p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'section_description_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__text' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .section-title__style2 .text-box p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'section_description_typography',
                'selector' => '{{WRAPPER}} .section-title__text, .section-title__style2 .text-box p',
            ]
        );

        $this->end_controls_section();

        // style control
		$this->start_controls_section(
			'twinkle_post_query_style',
			[
				'label' => __( 'Blog Query', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		// Title
        $this->add_control(
            '_heading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .blog-one__content h2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( '_title_style_tabs' );
        
        $this->start_controls_tab(
            'title_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'text-domain' ),
            ]
        );
        
        $this->add_control(
            'title_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-one__content h2 a' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->start_controls_tab(
            'title_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'text-domain' ),
            ]
        );
        
        $this->add_control(
            'title_color_hover',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-one__content h2 a:hover' => 'color: {{VALUE}}!important',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .blog-one__content h2 a',
            ]
        );

        // Description
        $this->add_control(
            '_content_description',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Description', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'description_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .blog-one__content p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .section-title__style2 .text-box p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-one__content p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .section-title__style2 .text-box p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .blog-one__content p, .section-title__style2 .text-box p',
            ]
        );

        // Link
        $this->add_control(
            '_content_link',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Link', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->start_controls_tabs( '_link_style_tabs' );
        
        $this->start_controls_tab(
            'link_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'text-domain' ),
            ]
        );
        
        $this->add_control(
            'link_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-one__content .btn-box a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog-one__content .btn-box a span::before' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->start_controls_tab(
            'link_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'text-domain' ),
            ]
        );
        
        $this->add_control(
            'link_color_hover',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-one__content .btn-box a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .blog-one__content .btn-box a:hover span::before' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'link_typography',
                'selector' => '{{WRAPPER}} .blog-one__content .btn-box a, .blog-one__content .btn-box a span::before',
            ]
        );

        // Link
        $this->add_control(
            '_blog_layout_style',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Layout', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'blog_layout_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .blog-one__content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'blog_layout_background_color',
            [
                'label' => __( 'Content Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-one__content' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'blog_layout_image_color',
            [
                'label' => __( 'Image Icon', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-one__single .blog-one__single-img .overlay-icon span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'blog_layout_image_background',
            [
                'label' => __( 'Image Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-one__single-img::before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

		$this->end_controls_section();
        
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if (get_query_var('paged')) {
            $paged = get_query_var('paged');
        } else if (get_query_var('page')) {
            $paged = get_query_var('page');
        } else {
            $paged = 1;
        }

        // include_categories
        $category_list = '';
        if (!empty($settings['category'])) {
            $category_list = implode(", ", $settings['category']);
        }
        $category_list_value = explode(" ", $category_list);

        // exclude_categories
        $exclude_categories = '';
        if(!empty($settings['exclude_category'])){
            $exclude_categories = implode(", ", $settings['exclude_category']);
        }
        $exclude_category_list_value = explode(" ", $exclude_categories);

        $post__not_in = '';
        if (!empty($settings['post__not_in'])) {
            $post__not_in = $settings['post__not_in'];
            $args['post__not_in'] = $post__not_in;
        }
        $posts_per_page = (!empty($settings['posts_per_page'])) ? $settings['posts_per_page'] : '-1';
        $orderby = (!empty($settings['orderby'])) ? $settings['orderby'] : 'post_date';
        $order = (!empty($settings['order'])) ? $settings['order'] : 'desc';
        $offset_value = (!empty($settings['offset'])) ? $settings['offset'] : '0';
        $ignore_sticky_posts = (! empty( $settings['ignore_sticky_posts'] ) && 'yes' == $settings['ignore_sticky_posts']) ? true : false ;


        // number
        $off = (!empty($offset_value)) ? $offset_value : 0;
        $offset = $off + (($paged - 1) * $posts_per_page);
        $p_ids = array();

        // build up the array
        if (!empty($settings['post__not_in'])) {
            foreach ($settings['post__not_in'] as $p_idsn) {
                $p_ids[] = $p_idsn;
            }
        }

        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => $posts_per_page,
            'orderby' => $orderby,
            'order' => $order,
            'offset' => $offset,
            'paged' => $paged,
            'post__not_in' => $p_ids,
            'ignore_sticky_posts' => $ignore_sticky_posts
        );

        // exclude_categories
        if ( !empty($settings['exclude_category'])) {

            // Exclude the correct cats from tax_query
            $args['tax_query'] = array(
                array(
                    'taxonomy'	=> 'category',
                    'field'	 	=> 'slug',
                    'terms'		=> $exclude_category_list_value,
                    'operator'	=> 'NOT IN'
                )
            );

            // Include the correct cats in tax_query
            if ( !empty($settings['category'])) {
                $args['tax_query']['relation'] = 'AND';
                $args['tax_query'][] = array(
                    'taxonomy'	=> 'category',
                    'field'		=> 'slug',
                    'terms'		=> $category_list_value,
                    'operator'	=> 'IN'
                );
            }

        } else {
            // Include the cats from $cat_slugs in tax_query
            if (!empty($settings['category'])) {
                $args['tax_query'][] = [
                    'taxonomy' => 'category',
                    'field' => 'slug',
                    'terms' => $category_list_value,
                ];
            }
        }

        $filter_list = $settings['category'];

        // The Query
        $query = new \WP_Query($args);
        
        $this->add_render_attribute('section_title_args', 'class', 'section-title__title');

        if ( !empty($settings['blog_bg_img_1']['url']) ) {
            $blog_bg_img_1 = !empty($settings['blog_bg_img_1']['id']) ? wp_get_attachment_image_url( $settings['blog_bg_img_1']['id'], 'full' ) : $settings['blog_bg_img_1']['url'];
        }

        ?>

            <?php if ( $settings['twinkle_design_style']  == 'layout-1' ): ?>

                <section class="blog-one pd-120-0-120">
                    <div class="container">
                        <div class="section-title text-center">
                            <?php if ( !empty($settings['twinkle_sub_title']) ) : ?>    
                                <span class="section-title__tagline"><?php echo twinkle_kses( $settings['twinkle_sub_title'] ); ?></span>
                            <?php endif; ?>

                            <?php
                                if ( !empty($settings['twinkle_title' ]) ) :
                                    printf( '<%1$s %2$s>%3$s</%1$s>',
                                        tag_escape( $settings['twinkle_title_tag'] ),
                                        $this->get_render_attribute_string( 'section_title_args' ),
                                        twinkle_kses( $settings['twinkle_title' ] )
                                        );
                                endif;
                            ?>

                            <?php if ( !empty($settings['twinkle_description']) ) : ?>
                                <p class="section-title__text"><?php echo twinkle_kses( $settings['twinkle_description'] ); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <?php if ($query->have_posts()) : ?>
                                <?php while ($query->have_posts()) : 
                                    $query->the_post();
                                    global $post;
                                    $categories = get_the_category($post->ID);
                                ?>
                                <div class="col-xl-4 col-lg-4">
                                    <div class="blog-one__single">
                                        <div class="blog-one__single-img">
                                            <?php the_post_thumbnail( $post->ID );?>
                                            <div class="overlay-icon">
                                                <a href="<?php the_permalink(); ?>"><span class="icon-plus"></span></a>
                                            </div>
                                        </div>
                                        <div class="blog-one__content">
                                            <h2><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), $settings['twinkle_blog_title_word'], ''); ?></a></h2>
                                            <?php if (!empty($settings['twinkle_post_content'])):
                                                $twinkle_post_content_limit = (!empty($settings['twinkle_post_content_limit'])) ? $settings['twinkle_post_content_limit'] : '';
                                                ?>
                                                <p><?php print wp_trim_words(get_the_excerpt(get_the_ID()), $twinkle_post_content_limit, ''); ?></p>
                                            <?php endif; ?>
                                            <?php if (!empty($settings['twinkle_btn_button_show'])): ?>
                                                <div class="btn-box">
                                                    <a href="<?php the_permalink();?>"><?php print esc_html($settings['twinkle_btn_text']);?> <span class="icon-plus"></span></a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endwhile; wp_reset_query(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </section>

            <?php elseif ( $settings['twinkle_design_style']  == 'layout-2' ): ?>

                <section class="blog-one blog-one--two pd-120-0-120">
                    <div class="container">
                        <div class="section-title__style2">
                            <div class="section-title">
                                <?php if ( !empty($settings['twinkle_sub_title']) ) : ?>    
                                    <span class="section-title__tagline"><?php echo twinkle_kses( $settings['twinkle_sub_title'] ); ?></span>
                                <?php endif; ?>
                                <?php
                                    if ( !empty($settings['twinkle_title' ]) ) :
                                        printf( '<%1$s %2$s>%3$s</%1$s>',
                                            tag_escape( $settings['twinkle_title_tag'] ),
                                            $this->get_render_attribute_string( 'section_title_args' ),
                                            twinkle_kses( $settings['twinkle_title' ] )
                                            );
                                    endif;
                                ?>
                            </div>
                            <?php if ( !empty($settings['twinkle_description']) ) : ?>
                                <div class="text-box">
                                    <p><?php echo twinkle_kses( $settings['twinkle_description'] ); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <?php if ($query->have_posts()) : ?>
                                <?php while ($query->have_posts()) : 
                                    $query->the_post();
                                    global $post;
                                    $categories = get_the_category($post->ID);
                                ?>
                                <div class="col-xl-4 col-lg-4">
                                    <div class="blog-one__single">
                                        <div class="blog-one__single-img">
                                            <?php the_post_thumbnail( $post->ID );?>
                                            <div class="overlay-icon">
                                                <a href="<?php the_permalink(); ?>"><span class="icon-plus"></span></a>
                                            </div>
                                        </div>
                                        <div class="blog-one__content">
                                            <h2><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), $settings['twinkle_blog_title_word'], ''); ?></a></h2>
                                            <?php if (!empty($settings['twinkle_post_content'])):
                                                $twinkle_post_content_limit = (!empty($settings['twinkle_post_content_limit'])) ? $settings['twinkle_post_content_limit'] : '';
                                                ?>
                                                <p><?php print wp_trim_words(get_the_excerpt(get_the_ID()), $twinkle_post_content_limit, ''); ?></p>
                                            <?php endif; ?>
                                            <?php if (!empty($settings['twinkle_btn_button_show'])): ?>
                                                <div class="btn-box">
                                                    <a href="<?php the_permalink();?>"><?php print esc_html($settings['twinkle_btn_text']);?> <span class="icon-plus"></span></a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endwhile; wp_reset_query(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </section>

            <?php endif; ?>
            
       <?php
	}

}

$widgets_manager->register( new Twinkle_Blog_Post() );