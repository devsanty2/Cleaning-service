<?php

namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Services extends Widget_Base {

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'twinkle_services';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Services', 'twinkle-core' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'twinkle-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'twinkle_core' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'twinkle-services' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'twinkle_layout',
            [
                'label' => esc_html__('Design Layout', 'twinkle-core'),
            ]
        );
        $this->add_control(
            'twinkle_design_style',
            [
                'label' => esc_html__('Select Layout', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'twinkle-core'),
                    'layout-2' => esc_html__('Layout 2', 'twinkle-core'),
                    'layout-3' => esc_html__('Layout 3', 'twinkle-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // Service group
        $this->start_controls_section(
            'twinkle_services',
            [
                'label' => esc_html__('Services List', 'twinkle-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'twinkle_service_image',
            [
                'label' => esc_html__('Upload Image', 'twinkle-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1', 'layout-2' ],
                ],
            ]
        );

        if (twinkle_is_elementor_version('<', '2.6.0')) {
            $this->add_control(
                'twinkle_service_icon',
                [
                    'label' => esc_html__('Icon', 'twinkle-core'),
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'icon-house',
                ]
            );
        } else {
            $this->add_control(
                'twinkle_service_selected_icon',
                [
                    'label' => esc_html__('Icon', 'twinkle-core'),
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'icon-house',
                        'library' => 'solid',
                    ],
                ]
            );
        }
        $this->add_control(
            'twinkle_service_title', [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Bedroom Cleaning', 'twinkle-core'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'twinkle_service_description',
            [
                'label' => esc_html__('Description', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('We provide janitorial and this <br> specialized is services.', 'twinkle-core'),
                'label_block' => true,
            ]
        ); 

        $this->add_control(
            'twinkle_services_link_switcher',
            [
                'label' => esc_html__( 'Add Services link', 'twinkle-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'twinkle-core' ),
                'label_off' => esc_html__( 'No', 'twinkle-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'twinkle_services_btn_text',
            [
                'label' => esc_html__('Button Text', 'twinkle-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'twinkle-core'),
                'title' => esc_html__('Enter button text', 'twinkle-core'),
                'label_block' => true,
                'condition' => [
                    'twinkle_services_link_switcher' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'twinkle_services_link_type',
            [
                'label' => esc_html__( 'Service Link Type', 'twinkle-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'twinkle_services_link_switcher' => 'yes'
                ]
            ]
        );
        $this->add_control(
            'twinkle_services_link',
            [
                'label' => esc_html__( 'Service Link link', 'twinkle-core' ),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'https://your-link.com', 'twinkle-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'twinkle_services_link_type' => '1',
                    'twinkle_services_link_switcher' => 'yes',
                ]
            ]
        );
        $this->add_control(
            'twinkle_services_page_link',
            [
                'label' => esc_html__( 'Select Service Link Page', 'twinkle-core' ),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => twinkle_get_all_pages(),
                'condition' => [
                    'twinkle_services_link_type' => '2',
                    'twinkle_services_link_switcher' => 'yes',
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'twinkle_layout_style',
			[
				'label' => __( 'Design Layout', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .services-one__single-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .service-two__single-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .services-three__single' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_image_hover_color',
            [
                'label' => __( 'Image Hover', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__single-img-inner::before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .service-two__single-img-inner:before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .service-two__single-content::before' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1', 'layout-2' ],
                ],
            ]
        );

        $this->add_control(
            'content_hover_color',
            [
                'label' => __( 'Content Hover', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-three__single:before' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .services-three__single:after' => 'border-color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-3' ],
                ],
            ]
        );

        $this->add_control(
            'content_background_color',
            [
                'label' => __( 'Content Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__single-content' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .service-two__single-content' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .services-three__single' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'content_bottom_spacing',
            [
                'label' => esc_html__( 'Bottom Spacing', 'text-domain' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 5,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 30,
                ],
                'selectors' => [
                    '{{WRAPPER}} .services-one__single' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .service-two__single-content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .services-three__single' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // TAB_STYLE
        $this->start_controls_section(
            'twinkle_services_list_style',
            [
                'label' => __( 'Services List', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            '_icon_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Icon', 'twinkle-core' ),
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => __( 'Icon Size', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .services-one__single-img .icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .service-two__single-img .icon-box' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .services-three__single-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'tabs_button_style' );

        $this->start_controls_tab(
            'icon_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __( 'Text', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__single-img .icon' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .service-two__single-img .icon-box' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services-three__single-icon' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_background_color',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__single-img .icon' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .service-two__single-img .icon-box' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1', 'layout-2' ],
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'icon_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'icon_color_hover',
            [
                'label' => __( 'Text', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__single:hover .services-one__single-img .icon' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .service-two__single:hover .service-two__single-img .icon-box' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services-three__single:hover .services-three__single-icon' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_background_color_hover',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__single-img .icon::before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .service-two__single-img .icon-box:before' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1', 'layout-2' ],
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            '_heading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .services-one__single-content h2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .service-two__single-content h2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .services-three__single-content h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__single-content h2 a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .service-two__single-content h2 a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services-three__single-content h3 a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .services-one__single-content h2 a, .service-two__single-content h2 a, .services-three__single-content h3 a',
            ]
        );

        // Description
        $this->add_control(
            '_content_description',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Description', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'description_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .services-one__single-content p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .service-two__single-content p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .services-three__single-content p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'services_list_description_color',
            [
                'label' => __( 'Text', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-one__single-content p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .service-two__single-content p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .services-three__single-content p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .services-one__single-content p, .service-two__single-content p, .services-three__single-content p',
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        // Link
        if ('2' == $settings['twinkle_services_link_type']) {
            $link = get_permalink($settings['twinkle_services_page_link']);
            $target = '_self';
            $rel = 'nofollow';
        } else {
            $link = !empty($settings['twinkle_services_link']['url']) ? $settings['twinkle_services_link']['url'] : '';
            $target = !empty($settings['twinkle_services_link']['is_external']) ? '_blank' : '';
            $rel = !empty($settings['twinkle_services_link']['nofollow']) ? 'nofollow' : '';
        }

        ?>

        <?php if ( $settings['twinkle_design_style']  == 'layout-1' ): ?>

            <div class="services-one__single">
                <div class="services-one__single-img">
                    <?php if (!empty($settings['twinkle_service_image']['url'])): ?>
                    <div class="services-one__single-img-inner">
                        <img class="parallax-img" src="<?php echo $settings['twinkle_service_image']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($settings['twinkle_service_image']['url']), '_wp_attachment_image_alt', true); ?>" />
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($settings['twinkle_service_icon']) || !empty($settings['twinkle_service_selected_icon']['value'])) : ?>
                        <div class="icon">
                            <?php twinkle_render_icon($settings, 'twinkle_service_icon', 'twinkle_service_selected_icon'); ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="services-one__single-content text-center">
                    <?php if (!empty($settings['twinkle_service_title' ])): ?>
                        <h2>
                            <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>">
                                <?php echo twinkle_kses($settings['twinkle_service_title' ]); ?>
                            </a>
                        </h2>
                    <?php endif; ?>
                    <?php if (!empty($settings['twinkle_service_description' ])): ?>
                        <p><?php echo twinkle_kses($settings['twinkle_service_description']); ?></p>
                    <?php endif; ?>
                    <p></p>
                </div>
            </div>

        <?php elseif ( $settings['twinkle_design_style']  == 'layout-2' ): ?>

            <div class="service-two__single">
                <div class="service-two__single-img">
                    <?php if (!empty($settings['twinkle_service_image']['url'])): ?>
                        <div class="service-two__single-img-inner">
                            <img class="parallax-img" src="<?php echo $settings['twinkle_service_image']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($settings['twinkle_service_image']['url']), '_wp_attachment_image_alt', true); ?>" />
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($settings['twinkle_service_icon']) || !empty($settings['twinkle_service_selected_icon']['value'])) : ?>
                        <div class="icon-box">
                            <?php twinkle_render_icon($settings, 'twinkle_service_icon', 'twinkle_service_selected_icon'); ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="service-two__single-content text-center">
                    <?php if (!empty($settings['twinkle_service_title' ])): ?>
                        <h2>
                            <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>">
                                <?php echo twinkle_kses($settings['twinkle_service_title' ]); ?>
                            </a>
                        </h2>
                    <?php endif; ?>
                    <?php if (!empty($settings['twinkle_service_description' ])): ?>
                        <p><?php echo twinkle_kses($settings['twinkle_service_description']); ?></p>
                    <?php endif; ?>
                </div>
            </div>

        <?php elseif ( $settings['twinkle_design_style']  == 'layout-3' ): ?>

            <div class="services-three__single text-center">
                <?php if (!empty($settings['twinkle_service_icon']) || !empty($settings['twinkle_service_selected_icon']['value'])) : ?>
                    <div class="services-three__single-icon">
                        <?php twinkle_render_icon($settings, 'twinkle_service_icon', 'twinkle_service_selected_icon'); ?>
                    </div>
                <?php endif; ?>
                
                <div class="services-three__single-content">
                    <?php if (!empty($settings['twinkle_service_title' ])): ?>
                        <h3>
                            <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>">
                                <?php echo twinkle_kses($settings['twinkle_service_title' ]); ?>
                            </a>
                        </h3>
                    <?php endif; ?>
                    <?php if (!empty($settings['twinkle_service_description' ])): ?>
                        <p><?php echo twinkle_kses($settings['twinkle_service_description']); ?></p>
                    <?php endif; ?>
                </div>
            </div>

        <?php endif; ?>

        <?php 
    }
}

$widgets_manager->register( new Twinkle_Services() );