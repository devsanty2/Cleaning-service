<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Control_Media;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Gallery_Info extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_gallery_info';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Gallery Info', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        $this->start_controls_section(
            'twinkle_gallery_info',
            [
                'label' => esc_html__('Gallery Info', 'twinkle-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'twinkle_image',
            [
                'label' => esc_html__( 'Testimonial Image', 'twinkle-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'twinkle_gallery_info_label', [
                'label' => esc_html__('Label', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'twinkle_gallery_info_type',
            [
                'label' => esc_html__('Info Type', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'text' => esc_html__('Text', 'twinkle-core'),
                    'url' => esc_html__('URL', 'twinkle-core'),
                ],
                'default' => 'text',
            ]
        );

        $repeater->add_control(
            'twinkle_gallery_info_title', [
                'label' => esc_html__('Text', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'twinkle_gallery_info_url',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'URL', 'twinkle-core' ),
                'default' => __( '#', 'twinkle-core' ),
                'placeholder' => __( 'Type url here', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'twinkle_gallery_info_type' => [ 'url' ],
                ],
            ]
        );

        $this->add_control(
            'twinkle_gallery_info_list',
            [
                'label' => esc_html__('Info List', 'twinkle-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'twinkle_gallery_info_label' => esc_html__('Date', 'twinkle-core'),
                        'twinkle_gallery_info_title' => esc_html__('03 may, 2023', 'twinkle-core'),
                    ],
                    [
                        'twinkle_gallery_info_label' => esc_html__('Client', 'twinkle-core'),
                        'twinkle_gallery_info_title' => esc_html__('Themeforest, Envato', 'twinkle-core'),
                    ],
                    [
                        'twinkle_gallery_info_label' => esc_html__('Website', 'twinkle-core'),
                        'twinkle_gallery_info_title' => esc_html__('Washup.com', 'twinkle-core'),
                    ],
                    [
                        'twinkle_gallery_info_label' => esc_html__('Location', 'twinkle-core'),
                        'twinkle_gallery_info_title' => esc_html__('New York, USA', 'twinkle-core'),
                    ],
                    [
                        'twinkle_gallery_info_label' => esc_html__('Value', 'twinkle-core'),
                        'twinkle_gallery_info_title' => esc_html__('$65,2000', 'twinkle-core'),
                    ],
                ],
                'title_field' => '{{{ twinkle_gallery_info_label }}}',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            '_section_layout_style',
            [
                'label' => __( 'Design Layout', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'content_margin',
            [
                'label' => __( 'Content Margin', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .gallery-details__information' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .gallery-details__information' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_border_radius',
            [
                'label' => __( 'Content Border Radius', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .gallery-details__information' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_background',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .gallery-details__information' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_info_list_style',
            [
                'label' => __( 'Info List', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            '_heading_label',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Label', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'label_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .gallery-details__information ul li h5' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'label_typography',
                'selector' => '{{WRAPPER}} .gallery-details__information ul li h5',
            ]
        );

        $this->add_responsive_control(
            'label_bottom_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 5,
					],
				],
                'selectors' => [
                    '{{WRAPPER}} .gallery-details__information ul li h5' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            '_content_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .gallery-details__information ul li p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .gallery-details__information ul li p',
            ]
        );

        $this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        if ( !empty($settings['twinkle_image']['url']) ) {
            $twinkle_image = !empty($settings['twinkle_image']['id']) ? wp_get_attachment_image_url( $settings['twinkle_image']['id'], 'full') : $settings['twinkle_image']['url'];
            $twinkle_image_alt = get_post_meta($settings["twinkle_image"]["id"], "_wp_attachment_image_alt", true);
        }

		?>

            <div class="gallery-details__wrapper">
                <div class="gallery-details__img">
                    <img src="<?php echo esc_url($twinkle_image); ?>" alt="<?php echo esc_url($twinkle_image_alt); ?>" />
                </div>

                <!--Projects Details Information Start-->
                <div class="gallery-details__information">
                    <ul>
                        <?php foreach ($settings['twinkle_gallery_info_list'] as $item) : ?>
                        <li>
                            <?php if ( !empty($item['twinkle_gallery_info_label']) ) : ?>
                                <h5><?php echo twinkle_kses($item['twinkle_gallery_info_label' ]); ?></h5>
                            <?php endif; ?>
                            <?php if ( !empty($item['twinkle_gallery_info_title']) ) : ?>
                                <?php if ( $item['twinkle_gallery_info_type']  == 'text' ): ?>
                                    <p><?php echo twinkle_kses($item['twinkle_gallery_info_title' ]); ?></p>
                               <?php elseif ( $item['twinkle_gallery_info_type']  == 'url' ): ?>
                                    <p><a href="<?php echo esc_url($item['twinkle_gallery_info_url' ]); ?>"><?php echo twinkle_kses($item['twinkle_gallery_info_title' ]); ?></a></p>
                                <?php endif; ?>
                                
                            <?php endif; ?>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

        <?php 
	}
}

$widgets_manager->register( new Twinkle_Gallery_Info() );