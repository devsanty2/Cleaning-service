<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Contact_Form extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_contact_form';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Contact Form', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}


    public function get_twinkle_contact_form(){
        if ( ! class_exists( 'WPCF7' ) ) {
            return;
        }
        $twinkle_cfa         = array();
        $twinkle_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
        $twinkle_forms       = get_posts( $twinkle_cf_args );
        $twinkle_cfa         = ['0' => esc_html__( 'Select Form', 'twinkle-core' ) ];
        if( $twinkle_forms ){
            foreach ( $twinkle_forms as $twinkle_form ){
                $twinkle_cfa[$twinkle_form->ID] = $twinkle_form->post_title;
            }
        }else{
            $twinkle_cfa[ esc_html__( 'No contact form found', 'twinkle-core' ) ] = 0;
        }
        return $twinkle_cfa;
    }


	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'twinkle_layout',
            [
                'label' => esc_html__('Design Layout', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_design_style',
            [
                'label' => esc_html__('Select Layout', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'twinkle-core'),
                    'layout-2' => esc_html__('Layout 2', 'twinkle-core'),
                ],
                'default' => 'layout-1',
            ]
        );

		$this->add_control(
            'twinkle_form_bg_img',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Background Image One', 'twinkle-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
				'condition' => [
                    'twinkle_design_style' => 'layout-1'
                ],
            ]
        );

        $this->add_control(
            'twinkle_image',
            [
                'label' => esc_html__( 'Choose Image', 'twinkle-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'twinkle_design_style' => 'layout-1'
                ],
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
            'twinkle_section_title',
            [
                'label' => esc_html__('Title & Content', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_sub_title',
            [
                'label' => esc_html__('Sub Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Contact With Us', 'twinkle-core'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'twinkle-core'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'twinkle_title',
            [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Write A Message', 'twinkle-core'),
                'placeholder' => esc_html__('Type Heading Text', 'twinkle-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'twinkle-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'twinkle-core'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'twinkle-core'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'twinkle-core'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'twinkle-core'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'twinkle-core'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'twinkle-core'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'twinkle_contact',
            [
                'label' => esc_html__('Contact Form', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_select_contact_form',
            [
                'label'   => esc_html__( 'Select Form', 'twinkle-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '0',
                'options' => $this->get_twinkle_contact_form(),
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'twinkle_layout_style',
			[
				'label' => __( 'Design Layout', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .contact-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .contact-page-form' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_inner_padding',
            [
                'label' => __( 'Content Inner Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .contact-page-form__inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'twinkle_design_style' => 'layout-2'
                ],
            ]
        );

        $this->add_control(
            'content_background',
            [
                'label' => __( 'Content Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-one__bg::before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .contact-page-form__inner' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'content_box_shadow',
				'selector' => '{{WRAPPER}} .contact-page-form__inner',
			]
		);

        $this->end_controls_section();

		$this->start_controls_section(
            '_section_style_content',
            [
                'label' => __( 'Title / Content', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // Subtitle    
        $this->add_control(
            '_heading_subtitle',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Subtitle', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'subtitle_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__tagline' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'subtitle_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__tagline' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typography',
                'selector' => '{{WRAPPER}} .section-title__tagline',
            ]
        );

        // Title
        $this->add_control(
            '_heading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .section-title__title',
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'twinkle_contact_style',
			[
				'label' => __( 'Contact Form', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
            'input_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'twinkle-core' ),
                'type'      => Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .contact-page-form__input-box input' => 'border-radius: {{SIZE}}px;',
                    '{{WRAPPER}} .contact-one__form-box input' => 'border-radius: {{SIZE}}px;',
                    '{{WRAPPER}} .contact-page-form__input-box textarea' => 'border-radius: {{SIZE}}px;',
                    '{{WRAPPER}} .contact-one__form-box textarea' => 'border-radius: {{SIZE}}px;',
                ],
            ]
        );

		// Input
        $this->add_control(
            '_content_input',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Input', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->start_controls_tabs( '_form_input_tabs' );
        
        $this->start_controls_tab(
            'form_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );
        
        $this->add_control(
            'input_color',
            [
                'label'     => esc_html__( 'Color', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-page-form__input-box input' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .contact-page-form__input-box label' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .contact-one__form-box input' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .contact-page-form__input-box textarea' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .contact-one__form-box textarea' => 'color: {{VALUE}}',
                ],
            ]
        );

		$this->add_control(
            'input_background',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-page-form__input-box input' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .contact-one__form-box input' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .contact-page-form__input-box textarea' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .contact-one__form-box textarea' => 'background-color: {{VALUE}}',
                ],
            ]
        );

		$this->add_control(
            'input_border_color',
            [
                'label'     => esc_html__( 'Border', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-page-form__input-box input' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .contact-one__form-box input' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .contact-page-form__input-box textarea' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .contact-one__form-box textarea' => 'border-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->start_controls_tab(
            'form_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'input_color_hover',
            [
                'label'     => esc_html__( 'Color', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-page-form__input-box input:focus' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .contact-one__form-box input:focus' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .contact-page-form__input-box textarea:focus' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .contact-one__form-box textarea:focus' => 'color: {{VALUE}}',
                ],
            ]
        );

		$this->add_control(
            'input_background_hover',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-page-form__input-box input:focus' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .contact-one__form-box input:focus' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .contact-page-form__input-box textarea:focus' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .contact-one__form-box textarea:focus' => 'background-color: {{VALUE}}',
                ],
            ]
        );

		$this->add_control(
            'input_border_color_hover',
            [
                'label'     => esc_html__( 'Border', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-page-form__input-box input:focus' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .contact-one__form-box input:focus' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .contact-page-form__input-box textarea:focus' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .contact-one__form-box textarea:focus' => 'border-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();

		// Button
        $this->add_control(
            '_content_button',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Button', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

		$this->add_control(
            'button_color',
            [
                'label'     => esc_html__( 'Color', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn span'    => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_background',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn .liquid' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'twinkle-core' ),
                'type'      => Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn' => 'border-radius: {{SIZE}}px;',
                ],
            ]
        );

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$this->add_render_attribute('title_args', 'class', 'section-title__title');

		if ( !empty($settings['twinkle_form_bg_img']['url']) ) {
            $twinkle_form_bg_img = !empty($settings['twinkle_form_bg_img']['id']) ? wp_get_attachment_image_url( $settings['twinkle_form_bg_img']['id'], 'full' ) : $settings['twinkle_form_bg_img']['url'];
        }

		if ( !empty($settings['twinkle_image']['url']) ) {
            $twinkle_image = !empty($settings['twinkle_image']['id']) ? wp_get_attachment_image_url( $settings['twinkle_image']['id'], 'full' ) : $settings['twinkle_image']['url'];
            $twinkle_image_alt = get_post_meta($settings["twinkle_image"]["id"], "_wp_attachment_image_alt", true);
        }

		?>

		<?php if ( $settings['twinkle_design_style']  == 'layout-1' ): ?>

            <section class="contact-one pd-120-0-120">
                <div class="contact-one__bg jarallax" data-jarallax data-speed="0.2" data-imgPosition="50% 0%" style="background-image: url(<?php echo esc_url($twinkle_form_bg_img); ?>);">
                </div>
                <div class="contact-one__img wow slideInRight" data-wow-delay="500ms" data-wow-duration="2500ms">
                    <img src="<?php echo esc_url($twinkle_image); ?>" alt="<?php echo esc_attr($twinkle_image_alt); ?>" />
                </div>
                <div class="container">
                    <div class="row">
                        <!--Start Contact One Form Box-->
                        <div class="col-xl-8">
                            <div class="contact-one__form-box">
                                <div class="section-title">
                                    <?php if ( !empty($settings['twinkle_sub_title']) ) : ?>
                                        <span class="section-title__tagline"><?php echo twinkle_kses( $settings['twinkle_sub_title'] ); ?></span>
                                    <?php endif; ?>
                                    <?php
                                        if ( !empty($settings['twinkle_title' ]) ) :
                                            printf( '<%1$s %2$s>%3$s</%1$s>',
                                                tag_escape( $settings['twinkle_title_tag'] ),
                                                $this->get_render_attribute_string( 'title_args' ),
                                                twinkle_kses( $settings['twinkle_title' ] )
                                                );
                                        endif;
                                    ?>
                                </div>
                                <div class="default-form2">
                                    <?php if( !empty($settings['twinkle_select_contact_form']) ) : ?> 
                                        <?php echo do_shortcode( '[contact-form-7  id="'.$settings['twinkle_select_contact_form'].'"]' ); ?> 
                                    
                                    <?php else : ?>
                                        <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'twinkle-core' ). '</p></div>'; ?>
                                    <?php endif; ?>   
                                    
                                </div>
                            </div>
                        </div>
                        <!--End Contact One Form Box-->
                    </div>
                </div>
            </section>

		<?php elseif ( $settings['twinkle_design_style']  == 'layout-2' ): ?>

            <section class="contact-page-form">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12">
                            <div class="contact-page-form__inner">
                                <div class="section-title text-center">
                                    <?php if ( !empty($settings['twinkle_sub_title']) ) : ?>
                                        <p class="section-title__tagline"><?php echo twinkle_kses( $settings['twinkle_sub_title'] ); ?></p>
                                    <?php endif; ?>
                                    <?php
                                        if ( !empty($settings['twinkle_title' ]) ) :
                                            printf( '<%1$s %2$s>%3$s</%1$s>',
                                                tag_escape( $settings['twinkle_title_tag'] ),
                                                $this->get_render_attribute_string( 'title_args' ),
                                                twinkle_kses( $settings['twinkle_title' ] )
                                                );
                                        endif;
                                    ?>
                                </div>
                                <div class="contact-page-form__input-box">
                                    <?php if( !empty($settings['twinkle_select_contact_form']) ) : ?> 
                                        <?php echo do_shortcode( '[contact-form-7  id="'.$settings['twinkle_select_contact_form'].'"]' ); ?> 
                                    <?php else : ?>
                                        <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'twinkle-core' ). '</p></div>'; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
			

        <?php endif; ?>

        <?php 
	}
}

$widgets_manager->register( new Twinkle_Contact_Form() );