<?php

namespace TwinkleCore\Widgets;

use \Elementor\Controls_Manager;
use \Elementor\Widget_Base;

if ( !defined( 'ABSPATH' ) ) {
    exit;
}
// Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Gallery extends Widget_Base {

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'twinkle_gallery';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Gallery', 'twinkle-core' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'twinkle-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return ['twinkle_core'];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return ['twinkle-project'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {

        // Project group
        $this->start_controls_section(
            'twinkle_project',
            [
                'label'       => esc_html__( 'Gallery', 'twinkle-core' ),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'twinkle-core' ),
                'tab'         => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'twinkle_design_style',
            [
                'label'   => esc_html__( 'Select Layout', 'twinkle-core' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__( 'Layout 1', 'twinkle-core' ),
                    'layout-2' => esc_html__( 'Layout 2', 'twinkle-core' ),
                    'layout-3' => esc_html__( 'Layout 3', 'twinkle-core' ),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->add_control(
            'important_note',
            [
                'type'            => Controls_Manager::RAW_HTML,
                'raw'             => esc_html__( 'Add photos from Dashboard Gallery.', 'twinkle-core' ),
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-danger',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_layout_stylesheet',
            [
                'label' => esc_html__( 'Layout', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'content_layout_background',
            [
                'label' => esc_html__( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .gallery-page' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .projects-one' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'content_layout_padding',
            [
                'label'      => esc_html__( 'Padding', 'twinkle-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .gallery-page' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .projects-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'gallery_stylesheet',
            [
                'label' => esc_html__( 'Gallery', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'filter_options',
            [
                'label' => esc_html__( 'Filter Options', 'twinkle-core' ),
                'type'  => Controls_Manager::HEADING,
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->start_controls_tabs( 'tabs_filter' );

        $this->start_controls_tab(
            'filter_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->add_control(
            'filter_color',
            [
                'label'     => esc_html__( 'Color', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-filter li .filter-text' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .project-filter li .count'       => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->add_control(
            'filter_background',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-filter li .filter-text' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'filter_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->add_control(
            'filter_color_hover',
            [
                'label'     => esc_html__( 'Color', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-filter li:hover .filter-text, .project-filter li.active .filter-text' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .project-filter li:hover .count, .project-filter li.active .count'             => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->add_control(
            'filter_background_hover',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-filter li .filter-text:before' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .project-filter li .count::before'      => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'filter_active_tab',
            [
                'label' => esc_html__( 'Active', 'twinkle-core' ),
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->add_control(
            'filter_color_active',
            [
                'label'     => esc_html__( 'Color', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-filter li.active .filter-text' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .project-filter li.active .count'       => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->add_control(
            'filter_background_active',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-filter li.active .filter-text:before' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .project-filter li.active .count::before'      => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'filter_bottom_spacing',
            [
                'label'      => esc_html__( 'Bottom Spacing', 'twinkle-core' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .gallery-page__menu-box' => 'padding-bottom: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->add_control(
            '_heading_icon',
            [
                'label'     => esc_html__( 'Icon', 'twinkle-core' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label'     => esc_html__( 'Color', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .gallery-page__single-icon a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .projects-one__single-img .overlay-icon a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_background',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .gallery-page__single-icon a' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .projects-one__single-img .overlay-icon a' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_color_hover',
            [
                'label'     => esc_html__( 'Color (Hover)', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .projects-one__single-img .overlay-icon a:hover' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-3' ],
                ],
            ]
        );

        $this->add_control(
            'icon_background_hover',
            [
                'label'     => esc_html__( 'Background (Hover)', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .projects-one__single-img .overlay-icon a:before' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-3' ],
                ],
            ]
        );

        $this->add_control(
            'icon_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'twinkle-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .gallery-page__single-icon a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .projects-one__single-img .overlay-icon a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            '_heading_layout',
            [
                'label'     => esc_html__( 'Layout', 'twinkle-core' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'gallery_layout_background',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .projects-one__single-img::before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .gallery-page__single-img:before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .gallery-page__single-img:after' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        $tags = get_terms( [
            'hide_empty' => true,
            'taxonomy'   => 'gallery-cat',
        ] );

        $portfolios = new \WP_Query( [
            'posts_per_page' => -1,
            'post_type'      => 'gallery',
            'post_status'    => 'publish',

        ] );

        ?>


        <?php if ( $settings['twinkle_design_style'] == 'layout-1' ): ?>

            <section class="gallery-page">
                <div class="container">
                    <div class="row">
                        <!--Start case-studies-one Top-->
                        <div class="gallery-page__top">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <div class="gallery-page__menu-box">
                                    <ul class="project-filter clearfix post-filter has-dynamic-filters-counter">
                                        <li data-filter=".filter-item" class="active"><span class="filter-text">Show All</span></li>
                                        <?php
                                            foreach ( $tags as $tag ) {
                                                printf( '<li data-filter=".%s"><span class="filter-text">%s</span></li>', esc_attr( $tag->slug ), esc_html( $tag->name ) );
                                            }
                                        ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!--End case-studies-one Top-->
                    </div>

                    <div class="row filter-layout masonary-layout">
                        <?php while ( $portfolios->have_posts() ) {
                            $portfolios->the_post();
                            $portfolio_tags = $this->get_portfolio_tags( get_the_ID() );
                            $image_url = get_the_post_thumbnail_url( get_the_ID(), 'large' )
                            ?>
                                <div class="col-xl-4 col-lg-4 col-md-6 filter-item <?php echo esc_attr( $portfolio_tags ); ?>">
                                    <div class="gallery-page__single wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                        <div class="gallery-page__single-img">
                                            <img src="<?php the_post_thumbnail_url( 'large' );?>" alt="">
                                            <div class="gallery-page__single-icon">
                                                <a class="img-popup" href="<?php the_post_thumbnail_url( 'large' );?>"><span class="icon-plus"></span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php
                        }?>
                    </div>
                </div>
            </section>

        <?php elseif ( $settings['twinkle_design_style'] == 'layout-2' ): ?>
            
            <section class="gallery-page">
                <div class="container">
                    <div class="row">
                        <?php while ( $portfolios->have_posts() ) {
                            $portfolios->the_post();
                            $portfolio_tags = $this->get_portfolio_tags( get_the_ID() );
                            $image_url = get_the_post_thumbnail_url( get_the_ID(), 'large' )
                            ?>
                            <div class="col-xl-4 col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0ms"
                                data-wow-duration="1500ms">
                                <div class="gallery-page__single">
                                    <div class="gallery-page__single-img">
                                        <img src="<?php the_post_thumbnail_url( 'large' );?>" alt="Gallery Image">
                                        <div class="gallery-page__single-icon">
                                            <a class="img-popup" href="<?php the_post_thumbnail_url( 'large' );?>"><span
                                                    class="icon-plus"></span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }?>
                    </div>
                </div>
            </section>

        <?php elseif ( $settings['twinkle_design_style'] == 'layout-3' ): ?>

            <section class="projects-one pd-120-0-90">
                <div class="container">
                    <div class="row">
                        <?php while ( $portfolios->have_posts() ) {
                            $portfolios->the_post();
                            $portfolio_tags = $this->get_portfolio_tags( get_the_ID() );
                            $image_url = get_the_post_thumbnail_url( get_the_ID(), 'large' )
                            ?>
                            <div class="col-xl-4 col-lg-4 col-md-4 wow animated fadeInUp" data-wow-delay="0.1s">
                                <div class="projects-one__single">
                                    <div class="projects-one__single-img">
                                        <img class="parallax-img" src="<?php the_post_thumbnail_url( 'large' );?>" alt="Gallery Image" />
                                        <div class="overlay-icon">
                                            <a class="img-popup" href="<?php the_post_thumbnail_url( 'large' );?>"><span class="icon-link"></span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        } ?>
                    </div>
                </div>
            </section>

        <?php endif;?>

	    <?php wp_reset_query();?>



        <?php
}

    function get_portfolio_tags( $post_id ) {
        $tags = get_the_terms( $post_id, 'gallery-cat' );
        $_tags = [];

        if ( !empty( $tags ) ) {

            foreach ( $tags as $tag ) {
                $_tags[$tag->term_id] = $tag->slug;
            }
        }

        return join( ' ', $_tags );
    }
}

$widgets_manager->register( new Twinkle_Gallery() );