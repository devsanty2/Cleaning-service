<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Slider extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Slider', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'twinkle_layout',
            [
                'label' => esc_html__('Design Layout', 'twinkle-core'),
            ]
        );
        $this->add_control(
            'twinkle_design_style',
            [
                'label' => esc_html__('Select Layout', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'twinkle-core'),
                    'layout-2' => esc_html__('Layout 2', 'twinkle-core'),
                    'layout-3' => esc_html__('Layout 3', 'twinkle-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
		
		$this->start_controls_section(
            'twinkle_main_slider',
            [
                'label' => esc_html__('Main Slider', 'twinkle-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

	        $repeater->add_control(
	            'twinkle_slider_image',
	            [
	                'label' => esc_html__('Upload Image', 'twinkle-core'),
	                'type' => Controls_Manager::MEDIA,
	                'default' => [
	                    'url' => Utils::get_placeholder_image_src(),
	                ]
	            ]
	        );

            $repeater->add_control(
                'twinkle_slider_subheading',
                [
                    'label' => esc_html__('Top Big Title', 'twinkle-core'),
                    'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => esc_html__('Welcome to Washup.', 'twinkle-core'),
                ]
            );

            $repeater->add_control(
                'twinkle_slider_title',
                [
                    'label' => esc_html__('Title', 'twinkle-core'),
                    'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('The Best Business <br> for Agency', 'twinkle-core'),
                    'label_block' => true,
                ]
            );

            $repeater->add_control(
                'twinkle_slider_title_tag',
                [
                    'label' => esc_html__('Title HTML Tag', 'twinkle-core'),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        'h1' => [
                            'title' => esc_html__('H1', 'twinkle-core'),
                            'icon' => 'eicon-editor-h1'
                        ],
                        'h2' => [
                            'title' => esc_html__('H2', 'twinkle-core'),
                            'icon' => 'eicon-editor-h2'
                        ],
                        'h3' => [
                            'title' => esc_html__('H3', 'twinkle-core'),
                            'icon' => 'eicon-editor-h3'
                        ],
                        'h4' => [
                            'title' => esc_html__('H4', 'twinkle-core'),
                            'icon' => 'eicon-editor-h4'
                        ],
                        'h5' => [
                            'title' => esc_html__('H5', 'twinkle-core'),
                            'icon' => 'eicon-editor-h5'
                        ],
                        'h6' => [
                            'title' => esc_html__('H6', 'twinkle-core'),
                            'icon' => 'eicon-editor-h6'
                        ]
                    ],
                    'default' => 'h2',
                    'toggle' => false,
                ]
            );

            $repeater->add_control(
                'twinkle_slider_description',
                [
                    'label' => esc_html__('Description', 'twinkle-core'),
                    'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => __('We will help you to feel better and enjoy every single day of <br>may be the fastest growing health.', 'twinkle-core'),
                ]
            );

			$repeater->add_control(
	            'twinkle_btn_link_switcher',
	            [
	                'label' => esc_html__( 'Add Button link', 'twinkle-core' ),
	                'type' => Controls_Manager::SWITCHER,
	                'label_on' => esc_html__( 'Yes', 'twinkle-core' ),
	                'label_off' => esc_html__( 'No', 'twinkle-core' ),
	                'return_value' => 'yes',
	                'default' => 'yes',
	                'separator' => 'before',
	            ]
	        );

	        $repeater->add_control(
	            'twinkle_btn_btn_text',
	            [
	                'label' => esc_html__('Button Text', 'twinkle-core'),
	                'type' => Controls_Manager::TEXT,
	                'default' => esc_html__('Discover Now', 'twinkle-core'),
	                'title' => esc_html__('Enter button text', 'twinkle-core'),
	                'label_block' => true,
	                'condition' => [
	                    'twinkle_btn_link_switcher' => 'yes'
	                ],
	            ]
	        );

	        $repeater->add_control(
	            'twinkle_btn_link_type',
	            [
	                'label' => esc_html__( 'Button Link Type', 'twinkle-core' ),
	                'type' => Controls_Manager::SELECT,
	                'options' => [
	                    '1' => 'Custom Link',
	                    '2' => 'Internal Page',
	                ],
	                'default' => '1',
	                'condition' => [
	                    'twinkle_btn_link_switcher' => 'yes'
	                ]
	            ]
	        );
	        $repeater->add_control(
	            'twinkle_btn_link',
	            [
	                'label' => esc_html__( 'Button Link link', 'twinkle-core' ),
	                'type' => Controls_Manager::URL,
	                'dynamic' => [
	                    'active' => true,
	                ],
	                'placeholder' => esc_html__( 'https://your-link.com', 'twinkle-core' ),
	                'show_external' => true,
	                'default' => [
	                    'url' => '#',
	                    'is_external' => false,
	                    'nofollow' => false,
	                ],
	                'condition' => [
	                    'twinkle_btn_link_type' => '1',
	                    'twinkle_btn_link_switcher' => 'yes',
	                ]
	            ]
	        );
	        $repeater->add_control(
	            'twinkle_btn_page_link',
	            [
	                'label' => esc_html__( 'Select Button Link Page', 'twinkle-core' ),
	                'type' => Controls_Manager::SELECT2,
	                'label_block' => true,
	                'options' => twinkle_get_all_pages(),
	                'condition' => [
	                    'twinkle_btn_link_type' => '2',
	                    'twinkle_btn_link_switcher' => 'yes',
	                ]
	            ]
	        );


        $this->add_control(
            'slider_list',
            [
                'label' => esc_html__('Slider List', 'twinkle-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'twinkle_slider_title' => __('Examples of great cleaning <br> that get it right.', 'twinkle-core')
                    ],
                    [
                        'twinkle_slider_title' => __('Examples of great cleaning <br> that get it right.', 'twinkle-core')
                    ],
                    [
                        'twinkle_slider_title' => __('Examples of great cleaning <br> that get it right.', 'twinkle-core')
                    ],
                ],
                'title_field' => '{{{ twinkle_slider_title }}}',
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
            '_main_slider_style',
            [
                'label' => __( 'Main Slider', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // Dots    
        $this->add_control(
            '_arrow_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Arrow', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );
        $this->start_controls_tabs( '_arrow_style_tabs' );
        
        $this->start_controls_tab(
            'arrow_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'text-domain' ),
            ]
        );

        $this->add_control(
            'arrow_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-slider-one__carousel.owl-theme .owl-nav .owl-prev' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-two__carousel.owl-theme .owl-nav .owl-prev' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-three__carousel.owl-theme .owl-nav .owl-prev' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-one__carousel.owl-theme .owl-nav .owl-next' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-two__carousel.owl-theme .owl-nav .owl-next' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-three__carousel.owl-theme .owl-nav .owl-next' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'arrow_background_color',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-slider-one__carousel.owl-theme .owl-nav .owl-prev' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-two__carousel.owl-theme .owl-nav .owl-prev' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-three__carousel.owl-theme .owl-nav .owl-prev' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-one__carousel.owl-theme .owl-nav .owl-next' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-two__carousel.owl-theme .owl-nav .owl-next' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-three__carousel.owl-theme .owl-nav .owl-next' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->start_controls_tab(
            'arrow_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'text-domain' ),
            ]
        );

        $this->add_control(
            'arrow_color_hover',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-slider-one__carousel.owl-theme .owl-nav .owl-prev:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-two__carousel.owl-theme .owl-nav .owl-prev:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-three__carousel.owl-theme .owl-nav .owl-prev:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-one__carousel.owl-theme .owl-nav .owl-next:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-two__carousel.owl-theme .owl-nav .owl-next:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-three__carousel.owl-theme .owl-nav .owl-next:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'arrow_background_color_hover',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-slider-one__carousel.owl-theme .owl-nav .owl-prev::before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-two__carousel.owl-theme .owl-nav .owl-prev::before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-three__carousel.owl-theme .owl-nav .owl-prev::before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-one__carousel.owl-theme .owl-nav .owl-next::before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-two__carousel.owl-theme .owl-nav .owl-next::before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-three__carousel.owl-theme .owl-nav .owl-next::before' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        // Title    
        $this->add_control(
            '_subheading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Subheading', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'subheading_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .main-slider-one__content .tagline' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .main-slider-two__content .tagline' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .main-slider-three__content .tagline' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'subheading_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-slider-one__content .tagline p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-two__content .tagline p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-three__content .tagline p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subheading_typography',
                'selector' => '{{WRAPPER}} .main-slider-one__content .tagline p, .main-slider-two__content .tagline p, .main-slider-three__content .tagline p',
            ]
        );

        // Title    
        $this->add_control(
            '_heading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .main-slider__title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-slider__title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .main-slider__title',
            ]
        );

        // Description
        $this->add_control(
            '_content_description',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Description', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'description_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .main-slider-one__content .text p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .main-slider-two__content .text p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .main-slider-three__content .text p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .main-slider-one__content .text p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-two__content .text p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .main-slider-three__content .text p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .main-slider-one__content .text p, .main-slider-two__content .text p, .main-slider-three__content .text p',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        $this->start_controls_section(
			'twinkle_button_style',
			[
				'label' => __( 'Button', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs( 'tabs_button_style' );

        $this->start_controls_tab(
            'button_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'button_color',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn span'    => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_background',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn .liquid' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'button_color_hover',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn:hover span' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_hover',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn:hover .liquid' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'button_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'twinkle-core' ),
                'type'      => Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn' => 'border-radius: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'    => esc_html__( 'Typography', 'twinkle-core' ),
                'name'     => 'button_typography',
                'selector' => '{{WRAPPER}} .thm-btn',
            ]
        );

        $this->add_control(
            'button_padding',
            [
                'label'      => esc_html__( 'Padding', 'twinkle-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .thm-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_margin',
            [
                'label'      => esc_html__( 'Margin', 'twinkle-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .thm-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<?php if ( $settings['twinkle_design_style']  == 'layout-1' ): ?>

            <section class="main-slider-one">
                <div class="main-slider-one__carousel owl-carousel owl-theme">
                    <?php foreach ($settings['slider_list'] as $item) :

                        $this->add_render_attribute('title_args', 'class', 'main-slider__title');

                        if ( !empty($item['twinkle_slider_image']['url']) ) {
                            $twinkle_slider_image_url = !empty($item['twinkle_slider_image']['id']) ? wp_get_attachment_image_url( $item['twinkle_slider_image']['id'], 'full') : $item['twinkle_slider_image']['url'];
                            $twinkle_slider_image_alt = get_post_meta($item["twinkle_slider_image"]["id"], "_wp_attachment_image_alt", true);
                        }

                        // btn Link
                        if ('2' == $item['twinkle_btn_link_type']) {
                            $link = get_permalink($item['twinkle_btn_page_link']);
                            $target = '_self';
                            $rel = 'nofollow';
                        } else {
                            $link = !empty($item['twinkle_btn_link']['url']) ? $item['twinkle_btn_link']['url'] : '';
                            $target = !empty($item['twinkle_btn_link']['is_external']) ? '_blank' : '';
                            $rel = !empty($item['twinkle_btn_link']['nofollow']) ? 'nofollow' : '';
                        }
                    ?>
                    <div class="main-slider-one__single">
                        <div class="top-shape"></div>
                        <div class="bottom-shape"></div>
                        <div class="image-layer" style="background-image:url(<?php echo esc_url($twinkle_slider_image_url); ?>)"></div>
                        <div class="container">
                            <div class="main-slider-one__content">
                                <div class="tagline">
                                    <p><?php echo twinkle_kses( $item['twinkle_slider_subheading'] ); ?></p>
                                </div>
                                <div class="title">
                                    <?php
                                        if ($item['twinkle_slider_title_tag']) :
                                            printf('<%1$s %2$s>%3$s</%1$s>',
                                                tag_escape($item['twinkle_slider_title_tag']),
                                                $this->get_render_attribute_string('title_args'),
                                                twinkle_kses($item['twinkle_slider_title'])
                                            );
                                        endif;
                                    ?>
                                </div>
                                <?php if (!empty($item['twinkle_slider_description'])) : ?>
                                    <div class="text">
                                        <p><?php echo twinkle_kses( $item['twinkle_slider_description'] ); ?></p>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($link)) : ?>
                                    <div class="btn-box">
                                        <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>" class="thm-btn">
                                            <span><?php echo twinkle_kses($item['twinkle_btn_btn_text']); ?></span>
                                            <div class="liquid"></div>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?> 
                </div>
            </section>
           		
        <?php elseif ( $settings['twinkle_design_style']  == 'layout-2' ): ?>

            <section class="main-slider-one main-slider-one--two">
                <div class="shape1 zoominout-2"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/shapes/main-slider-v2-shape1.png" alt="" /></div>
                <div class="main-slider-two__carousel owl-carousel owl-theme">
                    <?php foreach ($settings['slider_list'] as $item) :

                        $this->add_render_attribute('title_args', 'class', 'main-slider__title');

                        if ( !empty($item['twinkle_slider_image']['url']) ) {
                            $twinkle_slider_image_url = !empty($item['twinkle_slider_image']['id']) ? wp_get_attachment_image_url( $item['twinkle_slider_image']['id'], 'full') : $item['twinkle_slider_image']['url'];
                            $twinkle_slider_image_alt = get_post_meta($item["twinkle_slider_image"]["id"], "_wp_attachment_image_alt", true);
                        }

                        // btn Link
                        if ('2' == $item['twinkle_btn_link_type']) {
                            $link = get_permalink($item['twinkle_btn_page_link']);
                            $target = '_self';
                            $rel = 'nofollow';
                        } else {
                            $link = !empty($item['twinkle_btn_link']['url']) ? $item['twinkle_btn_link']['url'] : '';
                            $target = !empty($item['twinkle_btn_link']['is_external']) ? '_blank' : '';
                            $rel = !empty($item['twinkle_btn_link']['nofollow']) ? 'nofollow' : '';
                        }
                    ?>
                    <div class="main-slider-one__single">
                        <div class="main-slider-one--two-img">
                            <img src="<?php echo esc_url($twinkle_slider_image_url); ?>" alt="<?php echo esc_attr($twinkle_slider_image_alt); ?>" />
                        </div>
                        <div class="image-layer" style="background-image:url(<?php echo get_template_directory_uri(); ?>/assets/images/backgrounds/main-slider-v2-bg.png)"></div>
                        <div class="container">
                            <div class="main-slider-one__content">
                                <div class="tagline">
                                    <p><?php echo twinkle_kses( $item['twinkle_slider_subheading'] ); ?></p>
                                </div>
                                <div class="title">
                                    <?php
                                        if ($item['twinkle_slider_title_tag']) :
                                            printf('<%1$s %2$s>%3$s</%1$s>',
                                                tag_escape($item['twinkle_slider_title_tag']),
                                                $this->get_render_attribute_string('title_args'),
                                                twinkle_kses($item['twinkle_slider_title'])
                                            );
                                        endif;
                                    ?>
                                </div>
                                <?php if (!empty($item['twinkle_slider_description'])) : ?>
                                    <div class="text">
                                        <p><?php echo twinkle_kses( $item['twinkle_slider_description'] ); ?></p>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($link)) : ?>
                                    <div class="btn-box">
                                        <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>" class="thm-btn">
                                            <span><?php echo twinkle_kses($item['twinkle_btn_btn_text']); ?></span>
                                            <div class="liquid"></div>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

        <?php elseif ( $settings['twinkle_design_style']  == 'layout-3' ): ?>

            <section class="main-slider-three">
                <div class="main-slider-three__carousel owl-carousel owl-theme">
                    <?php foreach ($settings['slider_list'] as $item) :

                        $this->add_render_attribute('title_args', 'class', 'main-slider__title');

                        if ( !empty($item['twinkle_slider_image']['url']) ) {
                            $twinkle_slider_image_url = !empty($item['twinkle_slider_image']['id']) ? wp_get_attachment_image_url( $item['twinkle_slider_image']['id'], 'full') : $item['twinkle_slider_image']['url'];
                            $twinkle_slider_image_alt = get_post_meta($item["twinkle_slider_image"]["id"], "_wp_attachment_image_alt", true);
                        }

                        // btn Link
                        if ('2' == $item['twinkle_btn_link_type']) {
                            $link = get_permalink($item['twinkle_btn_page_link']);
                            $target = '_self';
                            $rel = 'nofollow';
                        } else {
                            $link = !empty($item['twinkle_btn_link']['url']) ? $item['twinkle_btn_link']['url'] : '';
                            $target = !empty($item['twinkle_btn_link']['is_external']) ? '_blank' : '';
                            $rel = !empty($item['twinkle_btn_link']['nofollow']) ? 'nofollow' : '';
                        }
                    ?>
                    <div class="main-slider-three__single">
                        <div class="shape1"></div>
                        <div class="image-layer" style="background-image:url(<?php echo esc_url($twinkle_slider_image_url); ?>)"></div>
                        <div class="container">
                            <div class="main-slider-three__content text-center">
                                <div class="tagline">
                                    <p><?php echo twinkle_kses( $item['twinkle_slider_subheading'] ); ?></p>
                                </div>
                                <div class="title">
                                    <?php
                                        if ($item['twinkle_slider_title_tag']) :
                                            printf('<%1$s %2$s>%3$s</%1$s>',
                                                tag_escape($item['twinkle_slider_title_tag']),
                                                $this->get_render_attribute_string('title_args'),
                                                twinkle_kses($item['twinkle_slider_title'])
                                            );
                                        endif;
                                    ?>
                                </div>
                                <?php if (!empty($item['twinkle_slider_description'])) : ?>
                                    <div class="text">
                                        <p><?php echo twinkle_kses( $item['twinkle_slider_description'] ); ?></p>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($link)) : ?>
                                    <div class="btn-box">
                                        <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>" class="thm-btn">
                                            <span><?php echo twinkle_kses($item['twinkle_btn_btn_text']); ?></span>
                                            <div class="liquid"></div>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <div class="bubbleContainer">
                    <div class="bubble-1"></div>
                    <div class="bubble-2"></div>
                    <div class="bubble-3"></div>
                    <div class="bubble-4"></div>
                    <div class="bubble-5"></div>
                    <div class="bubble-6"></div>
                    <div class="bubble-7"></div>
                    <div class="bubble-8"></div>
                    <div class="bubble-9"></div>
                    <div class="bubble-10"></div>
                    <div class="bubble-11"></div>
                    <div class="bubble-12"></div>
                    <div class="bubble-13"></div>
                    <div class="bubble-14"></div>
                    <div class="bubble-15"></div>
                </div>
            </section>
        
        <?php endif; ?>


		<?php 
	}
}

$widgets_manager->register( new Twinkle_Slider() );