<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Background;
use \Elementor\Control_Media;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Video_Popup extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_video_popup';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Video', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // twinkle_video
        $this->start_controls_section(
            'twinkle_video',
            [
                'label' => esc_html__('Video', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_design_style',
            [
                'label' => esc_html__('Select Layout', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'twinkle-core'),
                    'layout-2' => esc_html__('Layout 2', 'twinkle-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->add_control(
            'twinkle_video_url',
            [
                'label' => esc_html__('Video', 'twinkle-core'),
                'type' => Controls_Manager::TEXT,
                'default' => 'https://www.youtube.com/watch?v=AjgD3CvWzS0',
                'title' => esc_html__('Video url', 'twinkle-core'),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        // _twinkle_image
        $this->start_controls_section(
            '_twinkle_image_section',
            [
                'label' => esc_html__('Thumbnail', 'twinkle-core'),
            ]
        );
        $this->add_control(
            'twinkle_image',
            [
                'label' => esc_html__( 'Choose Image', 'twinkle-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'twinkle_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );
        $this->add_control(
            'twinkle_image_overlap',
            [
                'label' => esc_html__('Image overlap to top?', 'twinkle-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'twinkle-core'),
                'label_off' => esc_html__('No', 'twinkle-core'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );
        $this->add_responsive_control(
            'twinkle_image_height',
            [
                'label' => esc_html__( 'Image Height', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .video-one-bg' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tab-one__img img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'twinkle_image_overlap_x',
            [
                'label' => esc_html__( 'Image overlap position', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .video-one-bg' => 'margin-top: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tab-one__img img' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
                'condition' => array(
                    'twinkle_image_overlap' => 'yes',
                ),
            ]
        );

        $this->end_controls_section();

		// TAB_STYLE
		$this->start_controls_section(
			'content_layout_style',
			[
				'label' => __( 'Layout', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
            'content_background_color',
            [
                'label' => esc_html__( 'Content Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .video-one-bg:before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'video_style',
			[
				'label' => __( 'Video', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs( 'tabs_video_style' );

        $this->start_controls_tab(
            'video_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'video_color',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .video-one__video-icon'    => 'color: {{VALUE}}',
                    '{{WRAPPER}} .tab-one__img .icon .icon-play-button' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'video_background',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .video-one__video-icon' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .tab-one__video-icon:before, .tab-one__video-icon:after' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'video_layer_background',
            [
                'label'     => esc_html__( 'Layer', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .video-one__video-icon:before, .video-one__video-icon:after' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'video_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'video_color_hover',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .video-one__video-icon:hover' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->add_control(
            'video_background_hover',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .video-one__video-icon:hover' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->add_control(
            'video_layer_background_hover',
            [
                'label'     => esc_html__( 'Layer', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .video-one__video-link .ripple, .video-one__video-icon .ripple:before, .video-one__video-icon .ripple:after' => 'box-shadow: 0 0 0 0 {{VALUE}};',
                    '{{WRAPPER}} .tab-one__img .icon .ripple, .tab-one__video-icon .ripple:before, .tab-one__video-icon .ripple:after' => 'box-shadow: 0 0 0 0 {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        
        if ( !empty($settings['twinkle_image']['url']) ) {
            $twinkle_image = !empty($settings['twinkle_image']['id']) ? wp_get_attachment_image_url( $settings['twinkle_image']['id'], $settings['twinkle_image_size_size']) : $settings['twinkle_image']['url'];
            $twinkle_image_alt = get_post_meta($settings["twinkle_image"]["id"], "_wp_attachment_image_alt", true);
        }

		?>

        <?php if ( $settings['twinkle_design_style']  == 'layout-1' ): ?>

            <div class="video-one">
                <?php if ($settings['twinkle_image']['url'] || $settings['twinkle_image']['id']) : ?>
                    <div class="video-one-bg jarallax" data-jarallax data-speed="0.2" data-imgPosition="50% 0%" style="background-image: url(<?php echo esc_url($twinkle_image); ?>);"></div>
                <?php endif; ?>
                <div class="container">
                    <div class="video-one__inner">
                        <div class="video-one__video-link">
                            <?php if ( !empty($settings['twinkle_video_url']) ) : ?>
                                <a href="<?php echo esc_url($settings["twinkle_video_url"]); ?>" class="video-popup">
                                    <div class="video-one__video-icon">
                                        <span class="fa fa-play"></span>
                                        <i class="ripple"></i>
                                    </div>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

        <?php elseif ( $settings['twinkle_design_style']  == 'layout-2' ): ?>

            <?php if ( !empty($settings['twinkle_video_url']) ) : ?>
                <div class="tab-one__img">
                    <?php if ($settings['twinkle_image']['url'] || $settings['twinkle_image']['id']) : ?>
                        <img src="<?php echo esc_url($twinkle_image); ?>" alt="<?php echo esc_url($twinkle_image_alt); ?>" />
                    <?php endif; ?>
                    <div class="icon">
                        <a href="<?php echo esc_url($settings["twinkle_video_url"]); ?>" class="video-popup">
                            <div class="tab-one__video-icon">
                                <span class="icon-play-button"></span>
                                <i class="ripple"></i>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>

        <?php endif; ?>

        <?php
		
	}

}

$widgets_manager->register( new Twinkle_Video_Popup() );