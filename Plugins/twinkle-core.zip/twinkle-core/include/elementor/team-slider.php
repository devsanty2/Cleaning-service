<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Team_Slider extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_team_slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Team Slider', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		
        $this->start_controls_section(
            'twinkle_layout',
            [
                'label' => esc_html__('Design Layout', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_design_style',
            [
                'label' => esc_html__('Select Layout', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'twinkle-core'),
                    'layout-2' => esc_html__('Layout 2', 'twinkle-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->add_control(
            'twinkle_team_img_bg',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Background Image', 'twinkle-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'twinkle_section_title',
            [
                'label' => esc_html__('Title & Content', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_sub_title',
            [
                'label' => esc_html__('Sub Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Team', 'twinkle-core'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'twinkle_title',
            [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Our Team Member', 'twinkle-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_description',
            [
                'label' => esc_html__('Description', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('will reenergize your ome and enhance your life. From everyday housekeeping to routine cleanings, our professional this to members can provide you.', 'twinkle-core'),
                'placeholder' => esc_html__('Type section description here', 'twinkle-core'),
                'condition' => [
                    'twinkle_design_style' => [ 'layout-2' ],
                ],
            ]
        );

        $this->add_control(
            'twinkle_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'twinkle-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'twinkle-core'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'twinkle-core'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'twinkle-core'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'twinkle-core'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'twinkle-core'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'twinkle-core'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );
        
        $this->end_controls_section();

        $this->start_controls_section(
            'twinkle_teams',
            [
                'label' => esc_html__('Members', 'twinkle-core'),
            ]
        );

        $repeater = new Repeater();

        $repeater->start_controls_tabs( '_tab_style_member_box_item' );

        $repeater->start_controls_tab(
            'tab_member_info',
            [
                'label' => __( 'Information', 'twinkle-core' ),
            ]
        );

        $repeater->add_control(
            'image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image', 'twinkle-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );                      

        $repeater->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'Name', 'twinkle-core' ),
                'default' => __( 'Jessica Brown', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'designation',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'show_label' => true,
                'label' => __( 'Designation', 'twinkle-core' ),
                'default' => __( 'Manager', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->end_controls_tab();

        $repeater->start_controls_tab(
            '_tab_member_links',
            [
                'label' => __( 'Links', 'twinkle-core' ),
            ]
        );

        $repeater->add_control(
            'show_social',
            [
                'label' => __( 'Show Options?', 'twinkle-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'twinkle-core' ),
                'label_off' => __( 'No', 'twinkle-core' ),
                'return_value' => 'yes',
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'web_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Website Address', 'twinkle-core' ),
                'placeholder' => __( 'Add your profile link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'email_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Email', 'twinkle-core' ),
                'placeholder' => __( 'Add your email link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );           

        $repeater->add_control(
            'phone_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Phone', 'twinkle-core' ),
                'placeholder' => __( 'Add your phone link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'facebook_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Facebook', 'twinkle-core' ),
                'default' => __( '#', 'twinkle-core' ),
                'placeholder' => __( 'Add your facebook link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );                

        $repeater->add_control(
            'twitter_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Twitter', 'twinkle-core' ),
                'default' => __( '#', 'twinkle-core' ),
                'placeholder' => __( 'Add your twitter link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'instagram_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Instagram', 'twinkle-core' ),
                'default' => __( '#', 'twinkle-core' ),
                'placeholder' => __( 'Add your instagram link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );       

        $repeater->add_control(
            'linkedin_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'LinkedIn', 'twinkle-core' ),
                'placeholder' => __( 'Add your linkedin link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'youtube_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Youtube', 'twinkle-core' ),
                'placeholder' => __( 'Add your youtube link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );    

        $repeater->add_control(
            'flickr_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Flickr', 'twinkle-core' ),
                'placeholder' => __( 'Add your flickr link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'vimeo_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Vimeo', 'twinkle-core' ),
                'placeholder' => __( 'Add your vimeo link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'behance_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Behance', 'twinkle-core' ),
                'placeholder' => __( 'Add your hehance link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'dribble_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Dribbble', 'twinkle-core' ),
                'placeholder' => __( 'Add your dribbble link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'pinterest_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Pinterest', 'twinkle-core' ),
                'placeholder' => __( 'Add your pinterest link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'gitub_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Github', 'twinkle-core' ),
                'placeholder' => __( 'Add your github link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        ); 

        $repeater->end_controls_tab();

        $repeater->end_controls_tabs();

        // REPEATER
        $this->add_control(
            'teams',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(title || "Carousel Item"); #>',
                'default' => [
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ]
                ]
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'section_layout_style',
			[
				'label' => __( 'Design Layout', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .team-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'content_background',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->start_controls_tabs( 'content_dots_tabs' );
        
        $this->start_controls_tab(
            'dots_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'text-domain' ),
            ]
        );
        
        $this->add_control(
            'content_dots_border',
            [
                'label' => __( 'Dots Border', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .owl-dot-style1.owl-carousel .owl-dots .owl-dot' => 'border-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'content_dots_background',
            [
                'label' => __( 'Dots Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .owl-dot-style1.owl-carousel .owl-dots .owl-dot' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->start_controls_tab(
            'dots_active_tab',
            [
                'label' => esc_html__( 'Active', 'text-domain' ),
            ]
        );

        $this->add_control(
            'content_dots_border_active',
            [
                'label' => __( 'Dots Border', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .owl-dot-style1.owl-carousel .owl-dot.active' => 'border-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'content_dots_background_active',
            [
                'label' => __( 'Dots Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .owl-dot-style1.owl-carousel .owl-dot.active' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        

        

		$this->end_controls_section();

        $this->start_controls_section(
            '_section_style_content',
            [
                'label' => __( 'Title & Content', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .section-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Subtitle    
        $this->add_control(
            '_heading_subtitle',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Subtitle', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'subtitle_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__tagline' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'subtitle_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__tagline' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typography',
                'selector' => '{{WRAPPER}} .section-title__tagline',
            ]
        );

        // Title
        $this->add_control(
            '_heading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .section-title__title',
            ]
        );

        // Description
        $this->add_control(
            '_content_description',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Description', 'twinkle-core' ),
                'separator' => 'before',
                'condition' => [
                    'twinkle_design_style' => [ 'layout-2' ],
                ],
            ]
        );

        $this->add_responsive_control(
            'description_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__style2 .text-box p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-2' ],
                ],
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__style2 .text-box p' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-2' ],
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .section-title__style2 .text-box p',
                'condition' => [
                    'twinkle_design_style' => [ 'layout-2' ],
                ],
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'section_member_style',
			[
				'label' => __( 'Members', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        // Icon
        $this->add_control(
            '_heading_icon',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Icon', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->start_controls_tabs( 'tabs_icon_style' );

        $this->start_controls_tab(
            'icon_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .social-link a'    => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_background',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .social-link a' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'icon_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'icon_color_hover',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .social-link a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_background_hover',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .social-link a:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        // Content
        $this->add_control(
            '_heading_content',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Content', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'member_name_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .title-box h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'member_name_color',
            [
                'label' => __( 'Name', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .title-box h3' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'member_name_typography',
                'selector' => '{{WRAPPER}} .team-one__single .overlay-content .title-box h3',
            ]
        );

        $this->add_responsive_control(
            'member_designation_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .title-box p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'member_designation_color',
            [
                'label' => __( 'Designation', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .title-box p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'member_designation_typography',
                'selector' => '{{WRAPPER}} .team-one__single .overlay-content .title-box p',
            ]
        );

		$this->add_control(
            'member_content_background',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single:hover .overlay-content:before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $this->add_render_attribute('title_args', 'class', 'section-title__title');
        if ( !empty($settings['twinkle_team_img_bg']['url']) ) {
            $twinkle_team_img_bg = !empty($settings['twinkle_team_img_bg']['id']) ? wp_get_attachment_image_url( $settings['twinkle_team_img_bg']['id'], 'full' ) : $settings['twinkle_team_img_bg']['url'];
        }

		?>

            <?php if ( $settings['twinkle_design_style']  == 'layout-1' ): ?>

                <section class="team-one">
                    <?php if( !empty($twinkle_team_img_bg) ) : ?>
                        <div class="pattern-bg" style="background-image: url(<?php echo esc_url($twinkle_team_img_bg); ?>);"></div>
                    <?php endif; ?>
                    
                    <div class="container">
                        <div class="section-title text-center">
                            <?php if ( !empty($settings['twinkle_sub_title']) ) : ?> 
                                <span class="section-title__tagline"><?php echo twinkle_kses( $settings['twinkle_sub_title'] ); ?></span>
                            <?php endif; ?>
                            <?php
                                if ( !empty($settings['twinkle_title' ]) ) :
                                    printf( '<%1$s %2$s>%3$s</%1$s>',
                                        tag_escape( $settings['twinkle_title_tag'] ),
                                        $this->get_render_attribute_string( 'title_args' ),
                                        twinkle_kses( $settings['twinkle_title' ] )
                                        );
                                endif;
                            ?>
                        </div>
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="team-one__carousel owl-theme owl-carousel owl-dot-style1">
                                    <?php foreach ( $settings['teams'] as $item ) :
                                        $name = twinkle_kses( $item['title' ] );

                                        if ( !empty($item['image']['url']) ) {
                                            $twinkle_team_image_url = !empty($item['image']['id']) ? wp_get_attachment_image_url( $item['image']['id'], 'full') : $item['image']['url'];
                                            $twinkle_team_image_alt = get_post_meta($item["image"]["id"], "_wp_attachment_image_alt", true);
                                        }            
                                    ?>
                                        <div class="team-one__single">
                                            <div class="team-one__single-img">
                                                <?php if( !empty($twinkle_team_image_url) ) : ?>
                                                    <img src="<?php echo esc_url($twinkle_team_image_url); ?>" alt="<?php echo esc_attr($twinkle_team_image_alt); ?>">
                                                <?php endif; ?>
                                                <div class="overlay-content">
                                                    <div class="title-box">
                                                        <h3><?php echo twinkle_kses( $item['title'] ); ?></h3>
                                                        <?php if( !empty($item['designation']) ) : ?>
                                                            <p><?php echo twinkle_kses( $item['designation'] ); ?></p>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="social-link">
                                                        <?php if( !empty($item['facebook_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['facebook_title'] ); ?>"><i class="fab fa-facebook"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['twitter_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['twitter_title'] ); ?>"><i class="fab fa-twitter"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['pinterest_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['pinterest_title'] ); ?>"><i class="fab fa-pinterest-p"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['instagram_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['instagram_title'] ); ?>"><i class="fab fa-instagram"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['linkedin_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['linkedin_title'] ); ?>"><i class="fab fa-linkedin-in"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['youtube_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['youtube_title'] ); ?>"><i class="fab fa-youtube"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['flickr_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['flickr_title'] ); ?>"><i class="fab fa-flickr"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['vimeo_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['vimeo_title'] ); ?>"><i class="fab fa-vimeo-v"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['behance_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['behance_title'] ); ?>"><i class="fab fa-behance"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['dribble_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['dribble_title'] ); ?>"><i class="fab fa-dribbble"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['phone_title'] ) ) : ?>
                                                            <a href="tel:<?php echo esc_url( $item['phone_title'] ); ?>"><i class="fas fa-phone-alt"></i></a>
                                                        <?php endif; ?>  

                                                        <?php if( !empty($item['gitub_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['gitub_title'] ); ?>"><i class="fab fa-github"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['web_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['web_title'] ); ?>"><i class="fas fa-globe"></i></a>
                                                        <?php endif; ?>  

                                                        <?php if( !empty($item['email_title'] ) ) : ?>
                                                            <a href="mailto:<?php echo esc_url( $item['email_title'] ); ?>"><i class="fas fa-envelope"></i></a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

            <?php elseif ( $settings['twinkle_design_style']  == 'layout-2' ): ?>

                <section class="team-one">
                    <div class="pattern-bg" style="background-image: url(<?php echo esc_url($twinkle_team_img_bg); ?>);"></div>
                    <div class="container">
                        <div class="section-title__style2">
                            <div class="section-title">
                                <?php if ( !empty($settings['twinkle_sub_title']) ) : ?> 
                                    <span class="section-title__tagline"><?php echo twinkle_kses( $settings['twinkle_sub_title'] ); ?></span>
                                <?php endif; ?>
                                <?php
                                    if ( !empty($settings['twinkle_title' ]) ) :
                                        printf( '<%1$s %2$s>%3$s</%1$s>',
                                            tag_escape( $settings['twinkle_title_tag'] ),
                                            $this->get_render_attribute_string( 'title_args' ),
                                            twinkle_kses( $settings['twinkle_title' ] )
                                            );
                                    endif;
                                ?>
                            </div>
                            <?php if ( !empty($settings['twinkle_description']) ) : ?>
                                <div class="text-box">
                                    <p><?php echo twinkle_kses( $settings['twinkle_description'] ); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="team-one__carousel owl-theme owl-carousel owl-dot-style1">
                                    <?php foreach ( $settings['teams'] as $item ) :
                                        $name = twinkle_kses( $item['title' ] );

                                        if ( !empty($item['image']['url']) ) {
                                            $twinkle_team_image_url = !empty($item['image']['id']) ? wp_get_attachment_image_url( $item['image']['id'], 'full') : $item['image']['url'];
                                            $twinkle_team_image_alt = get_post_meta($item["image"]["id"], "_wp_attachment_image_alt", true);
                                        }            
                                    ?>
                                        <div class="team-one__single">
                                            <div class="team-one__single-img">
                                                <?php if( !empty($twinkle_team_image_url) ) : ?>
                                                    <img src="<?php echo esc_url($twinkle_team_image_url); ?>" alt="<?php echo esc_attr($twinkle_team_image_alt); ?>">
                                                <?php endif; ?>
                                                <div class="overlay-content">
                                                    <div class="title-box">
                                                        <h3><?php echo twinkle_kses( $item['title'] ); ?></h3>
                                                        <?php if( !empty($item['designation']) ) : ?>
                                                            <p><?php echo twinkle_kses( $item['designation'] ); ?></p>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="social-link">
                                                        <?php if( !empty($item['facebook_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['facebook_title'] ); ?>"><i class="fab fa-facebook"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['twitter_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['twitter_title'] ); ?>"><i class="fab fa-twitter"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['pinterest_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['pinterest_title'] ); ?>"><i class="fab fa-pinterest-p"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['instagram_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['instagram_title'] ); ?>"><i class="fab fa-instagram"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['linkedin_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['linkedin_title'] ); ?>"><i class="fab fa-linkedin-in"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['youtube_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['youtube_title'] ); ?>"><i class="fab fa-youtube"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['flickr_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['flickr_title'] ); ?>"><i class="fab fa-flickr"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['vimeo_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['vimeo_title'] ); ?>"><i class="fab fa-vimeo-v"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['behance_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['behance_title'] ); ?>"><i class="fab fa-behance"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['dribble_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['dribble_title'] ); ?>"><i class="fab fa-dribbble"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['phone_title'] ) ) : ?>
                                                            <a href="tel:<?php echo esc_url( $item['phone_title'] ); ?>"><i class="fas fa-phone-alt"></i></a>
                                                        <?php endif; ?>  

                                                        <?php if( !empty($item['gitub_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['gitub_title'] ); ?>"><i class="fab fa-github"></i></a>
                                                        <?php endif; ?>

                                                        <?php if( !empty($item['web_title'] ) ) : ?>
                                                            <a href="<?php echo esc_url( $item['web_title'] ); ?>"><i class="fas fa-globe"></i></a>
                                                        <?php endif; ?>  

                                                        <?php if( !empty($item['email_title'] ) ) : ?>
                                                            <a href="mailto:<?php echo esc_url( $item['email_title'] ); ?>"><i class="fas fa-envelope"></i></a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

            <?php endif; ?>

		<?php
	}
}

$widgets_manager->register( new Twinkle_Team_Slider() );