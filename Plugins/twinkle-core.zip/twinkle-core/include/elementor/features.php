<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;

use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Features extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_features';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Features', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        $this->start_controls_section(
            'twinkle_info',
            [
                'label' => esc_html__('Info List', 'twinkle-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'twinkle_image',
            [
                'label' => esc_html__( 'Image', 'twinkle-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        if (twinkle_is_elementor_version('<', '2.6.0')) {
            $this->add_control(
                'twinkle_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'icon-house',
                ]
            );
        } else {
            $this->add_control(
                'twinkle_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'icon-house',
                        'library' => 'solid',
                    ],
                ]
            );
        }

        $this->add_control(
            'twinkle_title', [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('House Cleaning', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_description', [
                'label' => esc_html__('Description', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default' => __('We provide janitorial and this specialized is services.', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_btn_text',
            [
                'label' => esc_html__('Button Text', 'twinkle-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'twinkle-core'),
                'title' => esc_html__('Enter button text', 'twinkle-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_btn_link',
            [
                'label' => esc_html__('Button link', 'twinkle-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'twinkle-core'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'twinkle_btn_link_type' => '1',
                ],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'twinkle-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => twinkle_get_all_pages(),
                'condition' => [
                    'twinkle_btn_link_type' => '2',
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_layout_style',
            [
                'label' => __( 'Design Layout', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .list-unstyled.all-project__list li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .features-one__single' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_border_color',
            [
                'label' => __( 'Border', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .features-one__single::before' => 'border-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'content_border_color_hover',
            [
                'label' => __( 'Border (Hover)', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .list-unstyled.all-project__list li:hover' => 'border-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_info_list_style',
            [
                'label' => __( 'Info List', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            '_heading_label',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Label', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'label_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .all-project__name' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'label_typography',
                'selector' => '{{WRAPPER}} .all-project__name',
            ]
        );

        $this->add_responsive_control(
            'label_width',
            [
                'label' => __( 'Width', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
				],
                'selectors' => [
                    '{{WRAPPER}} .all-project__name-box' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            '_content_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .all-project__content' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .all-project__content',
            ]
        );

        $this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        if ( !empty($settings['twinkle_image']['url']) ) {
            $twinkle_image = !empty($settings['twinkle_image']['id']) ? wp_get_attachment_image_url( $settings['twinkle_image']['id'], 'large') : $settings['twinkle_image']['url'];
        }

        // Link
        if ('2' == $settings['twinkle_btn_link_type']) {
            $this->add_render_attribute('twinkle-button-arg', 'href', get_permalink($settings['twinkle_btn_page_link']));
            $this->add_render_attribute('twinkle-button-arg', 'target', '_self');
            $this->add_render_attribute('twinkle-button-arg', 'rel', 'nofollow');
            $this->add_render_attribute('twinkle-button-arg', 'class', 'thm-btn service-details__btn');
        } else {
            if ( ! empty( $settings['twinkle_btn_link']['url'] ) ) {
                $this->add_link_attributes( 'twinkle-button-arg', $settings['twinkle_btn_link'] );
                $this->add_render_attribute('twinkle-button-arg', 'class', 'thm-btn service-details__btn');
            }
        }

		?>

            <div class="features-one__single">
                <div class="layer-outer" style="background-image: url(<?php echo esc_url($twinkle_image); ?>);"></div>
                <div class="features-one__single-inner">
                    <?php if (!empty($settings['twinkle_icon']) || !empty($settings['twinkle_selected_icon']['value'])) : ?>
                        <div class="icon-box">
                            <?php twinkle_render_icon($settings, 'twinkle_icon', 'twinkle_selected_icon'); ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="content-box">
                        <h2><a <?php echo $this->get_render_attribute_string( 'twinkle-button-arg' ); ?>><?php echo twinkle_kses($settings['twinkle_title' ]); ?></a></h2>
                        <p><?php echo twinkle_kses($settings['twinkle_description' ]); ?></p>
                        <div class="btn-box">
                            <a <?php echo $this->get_render_attribute_string( 'twinkle-button-arg' ); ?>>Read More <i class="icon-plus"></i></a>
                        </div>
                    </div>
                </div>
            </div>

        <?php 
	}
}

$widgets_manager->register( new Twinkle_Features() );