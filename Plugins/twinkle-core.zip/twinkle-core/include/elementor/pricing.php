<?php
namespace TwinkleCore\Widgets;

use Elementor\Widget_Base;
use \Elementor\Repeater;
use \Elementor\Control_Media;
use \Elementor\Utils;
Use \Elementor\Core\Schemes\Typography;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Pricing extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle-pricing';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Pricing', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // Header
        $this->start_controls_section(
            '_section_header',
            [
                'label' => __('Header', 'twinkle-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'image',
            [
                'label' => esc_html__( 'Choose Image', 'text-domain' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __('Title', 'twinkle-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Basic', 'twinkle-core'),
                'dynamic' => [
                    'active' => true
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_pricing',
            [
                'label' => __('Pricing', 'twinkle-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'currency',
            [
                'label' => __('Currency', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'label_block' => false,
                'options' => [
                    '' => __('None', 'twinkle-core'),
                    'baht' => '&#3647; ' . _x('Baht', 'Currency Symbol', 'twinkle-core'),
                    'bdt' => '&#2547; ' . _x('BD Taka', 'Currency Symbol', 'twinkle-core'),
                    'dollar' => '&#36; ' . _x('Dollar', 'Currency Symbol', 'twinkle-core'),
                    'euro' => '&#128; ' . _x('Euro', 'Currency Symbol', 'twinkle-core'),
                    'franc' => '&#8355; ' . _x('Franc', 'Currency Symbol', 'twinkle-core'),
                    'guilder' => '&fnof; ' . _x('Guilder', 'Currency Symbol', 'twinkle-core'),
                    'krona' => 'kr ' . _x('Krona', 'Currency Symbol', 'twinkle-core'),
                    'lira' => '&#8356; ' . _x('Lira', 'Currency Symbol', 'twinkle-core'),
                    'peseta' => '&#8359 ' . _x('Peseta', 'Currency Symbol', 'twinkle-core'),
                    'peso' => '&#8369; ' . _x('Peso', 'Currency Symbol', 'twinkle-core'),
                    'pound' => '&#163; ' . _x('Pound Sterling', 'Currency Symbol', 'twinkle-core'),
                    'real' => 'R$ ' . _x('Real', 'Currency Symbol', 'twinkle-core'),
                    'ruble' => '&#8381; ' . _x('Ruble', 'Currency Symbol', 'twinkle-core'),
                    'rupee' => '&#8360; ' . _x('Rupee', 'Currency Symbol', 'twinkle-core'),
                    'indian_rupee' => '&#8377; ' . _x('Rupee (Indian)', 'Currency Symbol', 'twinkle-core'),
                    'shekel' => '&#8362; ' . _x('Shekel', 'Currency Symbol', 'twinkle-core'),
                    'won' => '&#8361; ' . _x('Won', 'Currency Symbol', 'twinkle-core'),
                    'yen' => '&#165; ' . _x('Yen/Yuan', 'Currency Symbol', 'twinkle-core'),
                    'custom' => __('Custom', 'twinkle-core'),
                ],
                'default' => 'dollar',
            ]
        );

        $this->add_control(
            'currency_custom',
            [
                'label' => __('Custom Symbol', 'twinkle-core'),
                'type' => Controls_Manager::TEXT,
                'condition' => [
                    'currency' => 'custom',
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'price',
            [
                'label' => __('Price', 'twinkle-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '11.99',
                'dynamic' => [
                    'active' => true
                ]
            ]
        );

        $this->add_control(
            'period',
            [
                'label' => __('Period', 'twinkle-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Per Hour', 'twinkle-core'),
                'dynamic' => [
                    'active' => true
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_features',
            [
                'label' => __('Features', 'twinkle-core'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'text',
            [
                'label' => __('Text', 'twinkle-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Exciting Feature', 'twinkle-core'),
                'dynamic' => [
                    'active' => true
                ]
            ]
        );

        $this->add_control(
            'features_list',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'show_label' => false,
                'default' => [
                    [
                        'text' => __('Trained Cleane', 'twinkle-core'),
                    ],
                    [
                        'text' => __('Maintenance Cleaning', 'twinkle-core'),
                    ],
                    [
                        'text' => __('Liability Insurance', 'twinkle-core'),
                    ],
                    [
                        'text' => __('Planned Holiday', 'twinkle-core'),
                    ],
                    [
                        'text' => __('Feedback Centre Access', 'twinkle-core'),
                    ],
                ],
                'title_field' => '<# print((text)); #>',
            ]
        );

        $this->end_controls_section();

		// twinkle_btn_button_group
        $this->start_controls_section(
            'twinkle_btn_button_group',
            [
                'label' => esc_html__('Button', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_btn_text',
            [
                'label' => esc_html__('Button Text', 'twinkle-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Choose Plan', 'twinkle-core'),
                'title' => esc_html__('Enter button text', 'twinkle-core'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'twinkle_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_btn_link',
            [
                'label' => esc_html__('Button link', 'twinkle-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'twinkle-core'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'twinkle_btn_link_type' => '1',
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'twinkle_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'twinkle-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => twinkle_get_all_pages(),
                'condition' => [
                    'twinkle_btn_link_type' => '2',
                ]
            ]
        );
        
        $this->end_controls_section();

        $this->start_controls_section(
			'twinkle_layout_style',
			[
				'label' => __( 'Design Layout', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_margin',
            [
                'label' => __( 'Content Margin', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'content_background_tabs' );
        
        $this->start_controls_tab(
            'content_background_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'text-domain' ),
            ]
        );

        $this->add_control(
            'content_background_color',
            [
                'label' => __( 'Content Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single-inner::before' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->start_controls_tab(
            'content_background_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'text-domain' ),
            ]
        );
        
        $this->add_control(
            'content_background_color_hover',
            [
                'label' => __( 'Content Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single::before' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->end_controls_section();

        $this->start_controls_section(
            'twinkle_header_style',
            [
                'label' => esc_html__('Header', 'twinkle-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs( 'tabs_header_style' );

        $this->start_controls_tab(
            'header_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'header_color',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single .table-header h3'    => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'header_background',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single .table-header h3' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .pricing-plan-one__single .table-header .category-wrapper:before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .pricing-plan-one__single .table-header .category-wrapper:after' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'header_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'header_color_hover',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single:hover .table-header h3' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'header_background_hover',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single:hover .table-header h3' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .pricing-plan-one__single:hover .table-header .category-wrapper:before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .pricing-plan-one__single:hover .table-header .category-wrapper:after' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'    => esc_html__( 'Typography', 'twinkle-core' ),
                'name'     => 'header_typography',
                'selector' => '{{WRAPPER}} .pricing-plan-one__single .table-header h3',
            ]
        );

        $this->add_control(
            'header_padding',
            [
                'label'      => esc_html__( 'Padding', 'twinkle-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .pricing-plan-one__single .table-header h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'header_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single .table-header h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'twinkle_pricing_style',
            [
                'label' => esc_html__('Pricing', 'twinkle-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'pricing_options',
            [
                'label' => esc_html__( 'Pricing Options', 'text-domain' ),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->start_controls_tabs( 'tabs_pricing_style' );

        $this->start_controls_tab(
            'pricing_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'pricing_color',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single .table-header h2'    => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'pricing_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'pricing_color_hover',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single:hover .table-header h2' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'    => esc_html__( 'Typography', 'twinkle-core' ),
                'name'     => 'pricing_typography',
                'selector' => '{{WRAPPER}} .pricing-plan-one__single .table-header h2',
            ]
        );

        $this->add_responsive_control(
            'pricing_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single .table-header h2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'pricing_duration_options',
            [
                'label' => esc_html__( 'Duration Options', 'text-domain' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->start_controls_tabs( 'tabs_pricing_duration_style' );

        $this->start_controls_tab(
            'pricing_duration_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'pricing_duration_color',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single .table-header p'    => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'pricing_duration_border',
            [
                'label'     => esc_html__( 'Border Bottom', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single .table-header' => 'border-bottom-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'pricing_duration_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'pricing_duration_color_hover',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single:hover .table-header p' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pricing_duration_border_hover',
            [
                'label'     => esc_html__( 'Border Bottom', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single:hover .table-header' => 'border-bottom-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'    => esc_html__( 'Typography', 'twinkle-core' ),
                'name'     => 'pricing_duration_typography',
                'selector' => '{{WRAPPER}} .pricing-plan-one__single .table-header p',
            ]
        );

        $this->add_responsive_control(
            'pricing_duration_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single .table-header h2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'twinkle_features_list_style',
			[
				'label' => __( 'Features List', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_responsive_control(
            'features_list_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single .table-content ul li' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'features_list_tabs' );
        
        $this->start_controls_tab(
            'features_list_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'text-domain' ),
            ]
        );
        
        $this->add_control(
            'features_list_point_color',
            [
                'label' => __( 'Point', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single .table-content ul li::before' => 'background: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'features_list_text_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single .table-content ul li' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->start_controls_tab(
            'features_list_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'text-domain' ),
            ]
        );

        $this->add_control(
            'features_list_point_color_hover',
            [
                'label' => __( 'Point', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single:hover .table-content ul li::before' => 'background: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'features_list_text_color_hover',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single:hover .table-content ul li' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'features_list_typography',
                'selector' => '{{WRAPPER}} .pricing-plan-one__single .table-content ul li',
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
			'twinkle_button_style',
			[
				'label' => __( 'Button', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs( 'tabs_button_style' );

        $this->start_controls_tab(
            'button_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'button_color',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn span'    => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn .liquid'    => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'button_color_hover',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single:hover .table-footer .thm-btn span' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_hover',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pricing-plan-one__single:hover .table-footer .thm-btn .liquid' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'button_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'twinkle-core' ),
                'type'      => Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn' => 'border-radius: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'    => esc_html__( 'Typography', 'twinkle-core' ),
                'name'     => 'button_typography',
                'selector' => '{{WRAPPER}} .thm-btn span',
            ]
        );

		$this->end_controls_section();

	}

    private static function get_currency_symbol($symbol_name)
    {
        $symbols = [
            'baht' => '&#3647;',
            'bdt' => '&#2547;',
            'dollar' => '&#36;',
            'euro' => '&#128;',
            'franc' => '&#8355;',
            'guilder' => '&fnof;',
            'indian_rupee' => '&#8377;',
            'pound' => '&#163;',
            'peso' => '&#8369;',
            'peseta' => '&#8359',
            'lira' => '&#8356;',
            'ruble' => '&#8381;',
            'shekel' => '&#8362;',
            'rupee' => '&#8360;',
            'real' => 'R$',
            'krona' => 'kr',
            'won' => '&#8361;',
            'yen' => '&#165;',
        ];

        return isset($symbols[$symbol_name]) ? $symbols[$symbol_name] : '';
    }


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

            // Link
            if ('2' == $settings['twinkle_btn_link_type']) {
                $this->add_render_attribute('twinkle-button-arg', 'href', get_permalink($settings['twinkle_btn_page_link']));
                $this->add_render_attribute('twinkle-button-arg', 'target', '_self');
                $this->add_render_attribute('twinkle-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('twinkle-button-arg', 'class', 'thm-btn pricing-one__btn');
            } else {
                if ( ! empty( $settings['twinkle_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'twinkle-button-arg', $settings['twinkle_btn_link'] );
                    $this->add_render_attribute('twinkle-button-arg', 'class', 'thm-btn pricing-one__btn');
                }
            }

	        if ($settings['currency'] === 'custom') {
	            $currency = $settings['currency_custom'];
	        } else {
	            $currency = self::get_currency_symbol($settings['currency']);
	        }
	        

		?>

            <div class="pricing-plan-one__single">
                <div class="pricing-plan-one__single-inner">
                    <div class="layer-outer" style="background-image: url(<?php echo wp_kses_post( $settings['image']['url'] ); ?>"></div>
                    <div class="table-header text-center">
                        <?php if ($settings['title']) : ?>
                            <div class="category-wrapper">
                                <h3><?php echo twinkle_kses($settings['title']); ?></h3>
                            </div>
                        <?php endif; ?>
                        <h2><?php echo esc_html($currency); ?><?php echo twinkle_kses($settings['price']); ?></h2>
                        <?php if ($settings['period']) : ?>
                            <p><?php echo twinkle_kses($settings['period']); ?></p>
                        <?php endif; ?>
                    </div>

                    <div class="table-content">
                        <ul>
                            <?php foreach ($settings['features_list'] as $index => $item) : ?>
                                <li><?php echo twinkle_kses($item['text']); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>

                    <div class="table-footer">
                        <a <?php echo $this->get_render_attribute_string( 'twinkle-button-arg' ); ?> class="thm-btn">
                            <span><?php echo $settings['twinkle_btn_text']; ?></span>
                            <div class="liquid"></div>
                        </a>
                    </div>
                </div>
            </div>

        <?php
	}

}

$widgets_manager->register( new Twinkle_Pricing() );