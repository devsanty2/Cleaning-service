<?php
namespace TwinkleCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
Use \Elementor\Core\Schemes\Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TWINKLE_About extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'about';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'About', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'twinkle_layout',
            [
                'label' => esc_html__('Design Layout', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_image',
            [
                'label' => esc_html__( 'Choose Image', 'twinkle-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'twinkle_image_text',
            [
                'label' => esc_html__('Image Text', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('25 +Years Experince', 'twinkle-core'),
                'placeholder' => esc_html__('Type Heading Text', 'twinkle-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_image_animation',
            [
                'label' => esc_html__( 'Choose Image Animation', 'twinkle-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->end_controls_section();

        // twinkle_section_title
        $this->start_controls_section(
            'twinkle_section_title',
            [
                'label' => esc_html__('Title & Content', 'twinkle-core'),
            ]
        );
        
        $this->add_control(
            'twinkle_subheading',
            [
                'label' => esc_html__('Subheading', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('About Us', 'twinkle-core'),
                'placeholder' => esc_html__('Type Heading Text', 'twinkle-core'),
                'label_block' => true,
            ]
        );       
        
        $this->add_control(
            'twinkle_title',
            [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('We Have 25 Years Of Experience In This Field', 'twinkle-core'),
                'placeholder' => esc_html__('Type Heading Text', 'twinkle-core'),
                'label_block' => true,
            ]
        );       

        $this->add_control(
            'twinkle_description_summery',
            [
                'label' => esc_html__('Description', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('will reenergize your ome and enhance your life. From every day this man housekeeping to.', 'twinkle-core'),
                'placeholder' => esc_html__('Type section description here', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_description',
            [
                'label' => esc_html__('Description', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('will reenergize your ome and enhance your life. From everyday housekeeping to routine cleanings, our professional this to members can provide you.', 'twinkle-core'),
                'placeholder' => esc_html__('Type section description here', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'twinkle-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'twinkle-core'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'twinkle-core'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'twinkle-core'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'twinkle-core'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'twinkle-core'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'twinkle-core'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );

        $this->end_controls_section();

        // Features group
        $this->start_controls_section(
            'twinkle_features',
            [
                'label' => esc_html__('Features List', 'twinkle-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'twinkle-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'twinkle-core' ),
                    'style_2' => __( 'Style 2', 'twinkle-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        if (twinkle_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'twinkle_features_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa-solid fa-check',
                ]
            );
        } else {
            $repeater->add_control(
                'twinkle_features_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fa fa-check',
                        'library' => 'solid',
                    ],
                ]
            );
        }

        $repeater->add_control(
            'twinkle_features_title', [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'twinkle-core'),
                'label_block' => true,
            ]
        );
     
        $this->add_control(
            'twinkle_features_list',
            [
                'label' => esc_html__('Services - List', 'twinkle-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'twinkle_features_title' => esc_html__('We provide janitorial and specialized is services.', 'twinkle-core'),
                    ],
                    [
                        'twinkle_features_title' => esc_html__('Tonstantly evolving and your brand must evolve.', 'twinkle-core')
                    ],
                    [
                        'twinkle_features_title' => esc_html__('Tempor incididunt ut labore dolore magna aliqua.', 'twinkle-core')
                    ]
                ],
                'title_field' => '{{{ twinkle_features_title }}}',
            ]
        );
        $this->end_controls_section();

        // twinkle_btn_button_group
        $this->start_controls_section(
            'twinkle_btn_button_group',
            [
                'label' => esc_html__('Button', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'twinkle-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'twinkle-core' ),
                'label_off' => esc_html__( 'Hide', 'twinkle-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'twinkle_btn_text',
            [
                'label' => esc_html__('Button Text', 'twinkle-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('About More', 'twinkle-core'),
                'title' => esc_html__('Enter button text', 'twinkle-core'),
                'label_block' => true,
                'condition' => [
                    'twinkle_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'twinkle_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'twinkle_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'twinkle_btn_link',
            [
                'label' => esc_html__('Button link', 'twinkle-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'twinkle-core'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'twinkle_btn_link_type' => '1',
                    'twinkle_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'twinkle_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'twinkle-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => twinkle_get_all_pages(),
                'condition' => [
                    'twinkle_btn_link_type' => '2',
                    'twinkle_btn_button_show' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();

		$this->start_controls_section(
			'twinkle_layout_style',
			[
				'label' => __( 'Design Layout', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
            'content_image_options',
            [
                'label' => esc_html__( 'Image Options', 'text-domain' ),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_responsive_control(
            'content_image_top',
            [
                'label' => __( 'Top', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .about-one__img .experince-box' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_image_text_color',
            [
                'label' => __( 'Image Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about-one__img .experince-box h2' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'content_image_text_background_color',
            [
                'label' => __( 'Image Text Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about-one__img .experince-box' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_image_text_typography',
                'selector' => '{{WRAPPER}} .about-one__img .experince-box h2',
            ]
        );

        $this->add_control(
            'content_options',
            [
                'label' => esc_html__( 'Content Options', 'text-domain' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .about-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_background_color',
            [
                'label' => __( 'Content Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about-one' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'twinkle_title_style',
			[
				'label' => __( 'Title & Content', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        // Title
        $this->add_control(
            '_subheading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Subheading', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'subheading_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__tagline' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'subheading_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__tagline' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subheading_typography',
                'selector' => '{{WRAPPER}} .section-title__tagline',
            ]
        );

        // Title
        $this->add_control(
            '_heading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .about-one__content .section-title' => 'padding-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .section-title__title',
            ]
        );

        // Description
        $this->add_control(
            '_content_description_summery',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Summery Description', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'description_summery_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .about-one__content-text1' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'description_summery_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about-one__content-text1' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_summery_typography',
                'selector' => '{{WRAPPER}} .about-one__content-text1',
            ]
        );

        // Description
        $this->add_control(
            '_content_description',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Description', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'description_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .about-one__content-text2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about-one__content-text2' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .about-one__content-text2',
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'twinkle_features_list_style',
			[
				'label' => __( 'Features List', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_responsive_control(
            'features_list_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .about-one__content-list ul li' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'features_list_point_color',
            [
                'label' => __( 'Point', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about-one__content-list ul li p::before' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'features_list_color',
            [
                'label' => __( 'Text', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .about-one__content-list ul li p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'features_list_typography',
                'selector' => '{{WRAPPER}} .about-one__content-list ul li p',
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
			'twinkle_button_style',
			[
				'label' => __( 'Button', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->start_controls_tabs( 'tabs_button_style' );

        $this->start_controls_tab(
            'button_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'button_color',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn span'    => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_background',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn .liquid' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .thm-btn',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'button_color_hover',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background_hover',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn:after, .thm-btn:before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'button_box_shadow_hover',
                'selector' => '{{WRAPPER}} .thm-btn:hover',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'button_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'twinkle-core' ),
                'type'      => Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .thm-btn' => 'border-radius: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'    => esc_html__( 'Typography', 'twinkle-core' ),
                'name'     => 'button_typography',
                'selector' => '{{WRAPPER}} .thm-btn span',
            ]
        );

        $this->add_control(
            'button_padding',
            [
                'label'      => esc_html__( 'Padding', 'twinkle-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .thm-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'button_margin',
            [
                'label'      => esc_html__( 'Margin', 'twinkle-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .thm-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        if ( !empty($settings['twinkle_image']['url']) ) {
            $twinkle_image = !empty($settings['twinkle_image']['id']) ? wp_get_attachment_image_url( $settings['twinkle_image']['id'], 'full') : $settings['twinkle_image']['url'];
            $twinkle_image_alt = get_post_meta($settings["twinkle_image"]["id"], "_wp_attachment_image_alt", true);
        }
        if ( !empty($settings['twinkle_image_animation']['url']) ) {
            $twinkle_image_animation = !empty($settings['twinkle_image_animation']['id']) ? wp_get_attachment_image_url( $settings['twinkle_image_animation']['id'], 'full') : $settings['twinkle_image_animation']['url'];
            $twinkle_image_animation_alt = get_post_meta($settings["twinkle_image_animation"]["id"], "_wp_attachment_image_alt", true);
        }
        $this->add_render_attribute('title_args', 'class', 'section-title__title');

        // Link
        if ('2' == $settings['twinkle_btn_link_type']) {
            $this->add_render_attribute('twinkle-button-arg', 'href', get_permalink($settings['twinkle_btn_page_link']));
            $this->add_render_attribute('twinkle-button-arg', 'target', '_self');
            $this->add_render_attribute('twinkle-button-arg', 'rel', 'nofollow');
            $this->add_render_attribute('twinkle-button-arg', 'class', 'thm-btn about-one__btn');
        } else {
            if ( ! empty( $settings['twinkle_btn_link']['url'] ) ) {
                $this->add_link_attributes( 'twinkle-button-arg', $settings['twinkle_btn_link'] );
                $this->add_render_attribute('twinkle-button-arg', 'class', 'thm-btn about-one__btn');
            }
        }

		?>

        <section class="about-one pd-120-0-120">
            <?php if ($settings['twinkle_image']['url'] || $settings['twinkle_image_animation']['id']) : ?>
                <div class="about-one__img2 wow slideInRight" data-wow-delay="500ms"><img class="float-bob-x" src="<?php echo esc_url($twinkle_image_animation); ?>" alt="<?php echo esc_attr($twinkle_image_animation_alt); ?>" /></div>
            <?php endif; ?>
            
            <div class="container">
                <div class="row">
                    <!--Start About One Img-->
                    <div class="col-xl-6">
                        <div class="about-one__img clearfix">
                            <?php if ($settings['twinkle_image']['url'] || $settings['twinkle_image']['id']) : ?>
                                <div class="about-one__img-inner">
                                    <img src="<?php echo esc_url($twinkle_image); ?>" alt="<?php echo esc_attr($twinkle_image_alt); ?>" />
                                </div>
                            <?php endif; ?>
                            <div class="experince-box">
                                <h2><?php echo twinkle_kses( $settings['twinkle_image_text'] ); ?></h2>
                            </div>
                        </div>
                    </div>
                    <!--End About One Img-->

                    <!--Start About One Content-->
                    <div class="col-xl-6">
                        <div class="about-one__content">
                            <div class="section-title">
                                <span class="section-title__tagline"><?php echo twinkle_kses( $settings['twinkle_subheading'] ); ?></span>
                                <?php
                                    if ( !empty($settings['twinkle_title' ]) ) :
                                        printf( '<%1$s %2$s>%3$s</%1$s>',
                                            tag_escape( $settings['twinkle_title_tag'] ),
                                            $this->get_render_attribute_string( 'title_args' ),
                                            twinkle_kses( $settings['twinkle_title' ] )
                                            );
                                    endif;
                                ?>
                            </div>
                            <div class="about-one__content-inner">
                                <?php if ( !empty($settings['twinkle_description_summery']) ) : ?>
                                    <p class="about-one__content-text1"><?php echo twinkle_kses( $settings['twinkle_description_summery'] ); ?></p>
                                <?php endif; ?>
                                <?php if ( !empty($settings['twinkle_description']) ) : ?>
                                    <p class="about-one__content-text2"><?php echo twinkle_kses( $settings['twinkle_description'] ); ?></p>
                                <?php endif; ?>
                                <div class="about-one__content-list">
                                    <ul>
                                        <?php foreach ($settings['twinkle_features_list'] as $item) : ?>
                                            <li>
                                                <p><?php echo twinkle_kses($item['twinkle_features_title' ]); ?></p>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                                <div class="about-one__content-btn">
                                    <?php if (!empty($settings['twinkle_btn_text'])) : ?>
                                        <a <?php echo $this->get_render_attribute_string( 'twinkle-button-arg' ); ?> class="thm-btn">
                                            <span><?php echo $settings['twinkle_btn_text']; ?></span>
                                            <div class="liquid"></div>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End About One Content-->
                </div>
            </div>
        </section>

        <?php 
	}
}

$widgets_manager->register( new TWINKLE_About() );