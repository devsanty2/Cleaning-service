<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Control_Media;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Css_Filter;
use \Elementor\Repeater;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Box_Shadow;
use TwinkleCore\Elementor\Controls\Group_Control_TWINKLEBGGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Team_Details extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_team_details';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Team Details', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected static function get_profile_names()
    {
        return [
            '500px' => esc_html__('500px', 'twinkle-core'),
            'apple' => esc_html__('Apple', 'twinkle-core'),
            'behance' => esc_html__('Behance', 'twinkle-core'),
            'bitbucket' => esc_html__('BitBucket', 'twinkle-core'),
            'codepen' => esc_html__('CodePen', 'twinkle-core'),
            'delicious' => esc_html__('Delicious', 'twinkle-core'),
            'deviantart' => esc_html__('DeviantArt', 'twinkle-core'),
            'digg' => esc_html__('Digg', 'twinkle-core'),
            'dribbble' => esc_html__('Dribbble', 'twinkle-core'),
            'email' => esc_html__('Email', 'twinkle-core'),
            'facebook' => esc_html__('Facebook', 'twinkle-core'),
            'flickr' => esc_html__('Flicker', 'twinkle-core'),
            'foursquare' => esc_html__('FourSquare', 'twinkle-core'),
            'github' => esc_html__('Github', 'twinkle-core'),
            'houzz' => esc_html__('Houzz', 'twinkle-core'),
            'instagram' => esc_html__('Instagram', 'twinkle-core'),
            'jsfiddle' => esc_html__('JS Fiddle', 'twinkle-core'),
            'linkedin' => esc_html__('LinkedIn', 'twinkle-core'),
            'medium' => esc_html__('Medium', 'twinkle-core'),
            'pinterest' => esc_html__('Pinterest', 'twinkle-core'),
            'product-hunt' => esc_html__('Product Hunt', 'twinkle-core'),
            'reddit' => esc_html__('Reddit', 'twinkle-core'),
            'slideshare' => esc_html__('Slide Share', 'twinkle-core'),
            'snapchat' => esc_html__('Snapchat', 'twinkle-core'),
            'soundcloud' => esc_html__('SoundCloud', 'twinkle-core'),
            'spotify' => esc_html__('Spotify', 'twinkle-core'),
            'stack-overflow' => esc_html__('StackOverflow', 'twinkle-core'),
            'tripadvisor' => esc_html__('TripAdvisor', 'twinkle-core'),
            'tumblr' => esc_html__('Tumblr', 'twinkle-core'),
            'twitch' => esc_html__('Twitch', 'twinkle-core'),
            'twitter' => esc_html__('Twitter', 'twinkle-core'),
            'vimeo' => esc_html__('Vimeo', 'twinkle-core'),
            'vk' => esc_html__('VK', 'twinkle-core'),
            'website' => esc_html__('Website', 'twinkle-core'),
            'whatsapp' => esc_html__('WhatsApp', 'twinkle-core'),
            'wordpress' => esc_html__('WordPress', 'twinkle-core'),
            'xing' => esc_html__('Xing', 'twinkle-core'),
            'yelp' => esc_html__('Yelp', 'twinkle-core'),
            'youtube' => esc_html__('YouTube', 'twinkle-core'),
        ];
    }


	protected function register_controls() {

        $this->start_controls_section(
            'twinkle_section_title',
            [
                'label' => esc_html__('Title & Content', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_image',
            [
                'label' => esc_html__( 'Choose Image', 'twinkle-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'twinkle_title',
            [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Team Details', 'twinkle-core'),
            ]
        );       

        $this->add_control(
            'twinkle_name_label',
            [
                'label' => esc_html__('Name Label', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Name:', 'twinkle-core'),
            ]
        );       

        $this->add_control(
            'twinkle_name',
            [
                'label' => esc_html__('Name', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Md Imran Hossain', 'twinkle-core'),
                'label_block' => true,
            ]
        );       

        $this->add_control(
            'twinkle_about_label',
            [
                'label' => esc_html__('About Label', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('About:', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_about',
            [
                'label' => esc_html__('About', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Phis are bound to ensue; and equal blame belongs to those who through weakness of will, which is the same as through.We have the and industry expertise to develop solutions that can connect.', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_phone_label',
            [
                'label' => esc_html__('Phone Label', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Call:', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_phone',
            [
                'label' => esc_html__('Phone', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('++0822155421', 'twinkle-core'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_social',
            [
                'label' => esc_html__('Social Profiles', 'twinkle-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_profiles',
            [
                'label' => esc_html__('Show Profiles', 'twinkle-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'twinkle-core'),
                'label_off' => esc_html__('Hide', 'twinkle-core'),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
                'style_transfer' => true,
            ]
        );

        $this->add_control(
            'twinkle_profile_label',
            [
                'label' => esc_html__('Social Label', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Follow us:', 'twinkle-core'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'name',
            [
                'label' => esc_html__('Profile Name', 'twinkle-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'select2options' => [
                    'allowClear' => false,
                ],
                'options' => self::get_profile_names()
            ]
        );

        $repeater->add_control(
            'link', [
                'label' => esc_html__('Profile Link', 'twinkle-core'),
                'placeholder' => esc_html__('Add your profile link', 'twinkle-core'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'autocomplete' => false,
                'show_external' => false,
                'condition' => [
                    'name!' => 'email'
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );
        $this->add_control(
            'profiles',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(name.slice(0,1).toUpperCase() + name.slice(1)) #>',
                'default' => [
                    [
                        'link' => ['url' => 'https://facebook.com/'],
                        'name' => 'facebook'
                    ],
                    [
                        'link' => ['url' => 'https://linkedin.com/'],
                        'name' => 'linkedin'
                    ],
                    [
                        'link' => ['url' => 'https://twitter.com/'],
                        'name' => 'twitter'
                    ]
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'twinkle_layout_style',
			[
				'label' => __( 'Layout', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .team-details' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'content_background',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-details' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'twinkle_title_style',
			[
				'label' => __( 'Title & Content', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        // Title
        $this->add_control(
            '_heading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'title_bottom_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .team-details__content .title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-details__content .title h2' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .team-details__content .title h2',
            ]
        );

        // Name
        $this->add_control(
            '_heading_name',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Name', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'name_color',
            [
                'label' => __( 'Text', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-details__content .name h6' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'name_typography',
                'selector' => '{{WRAPPER}} .team-details__content .name h6',
            ]
        );

        // About
        $this->add_control(
            '_heading_about',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'About', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'about_color',
            [
                'label' => __( 'About Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-details__content .text p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'about_typography',
                'selector' => '{{WRAPPER}} .team-details__content .text p',
            ]
        );

        // Phone
        $this->add_control(
            '_heading_phone',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Phone', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'phone_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-details__content .number p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team-details__content .number p a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'phone_typography',
                'selector' => '{{WRAPPER}} .team-details__content .number p, .team-details__content .number p a',
            ]
        );

        // Follow
        $this->add_control(
            '_heading_follow',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Follow', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'follow_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-details__content .social-icon .title h6' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'follow_typography',
                'selector' => '{{WRAPPER}} .team-details__content .social-icon .title h6',
            ]
        );

        $this->add_responsive_control(
            'follow_icon_size',
            [
                'label' => __( 'Icon Size', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .team-details__content .social-icon ul li a' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'follow_icon_color',
            [
                'label' => __( 'Icon Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-details__content .social-icon ul li a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'follow_icon_color_hover',
            [
                'label' => __( 'Icon Color (Hover)', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-details__content .social-icon ul li a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        // Phone
        $this->add_control(
            '_heading_layout',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Layout', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'layout_background',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-details__content' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'layout_border_bottom_color',
            [
                'label' => __( 'Border Bottom', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-details__content::before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

            if ( !empty($settings['twinkle_image']['url']) ) {
                $twinkle_image = !empty($settings['twinkle_image']['id']) ? wp_get_attachment_image_url( $settings['twinkle_image']['id'], 'full' ) : $settings['twinkle_image']['url'];
                $twinkle_image_alt = get_post_meta($settings["twinkle_image"]["id"], "_wp_attachment_image_alt", true);
            }

            if ( !empty($settings['twinkle_signature_image']['url']) ) {
                $twinkle_signature_image = !empty($settings['twinkle_signature_image']['id']) ? wp_get_attachment_image_url( $settings['twinkle_signature_image']['id'], 'full' ) : $settings['twinkle_signature_image']['url'];
                $twinkle_signature_image_alt = get_post_meta($settings["twinkle_signature_image"]["id"], "_wp_attachment_image_alt", true);
            }

		?>

            <section class="team-details">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-5">
                            <?php if ( !empty ( $settings['twinkle_image']['url'] ) ) : ?>  
                                <div class="team-details__img js-tilt">
                                    <img src="<?php echo esc_url($twinkle_image); ?>" alt="<?php echo esc_attr($twinkle_image_alt); ?>" />
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="col-xl-7">
                            <div class="team-details__content">
                                <?php if ( !empty($settings['twinkle_title' ]) ) : ?>
                                    <div class="title">
                                        <h2><?php echo twinkle_kses( $settings['twinkle_title'] ); ?></h2>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ( !empty($settings['twinkle_name' ]) ) : ?>
                                    <div class="name">
                                        <h6><?php echo twinkle_kses( $settings['twinkle_name_label'] ); ?> <?php echo twinkle_kses( $settings['twinkle_name'] ); ?></h6>
                                    </div>
                                <?php endif; ?>
                                <?php if ( !empty($settings['twinkle_about']) ) : ?>
                                    <div class="text">
                                        <p><?php echo twinkle_kses( $settings['twinkle_about_label'] ); ?> <?php echo twinkle_kses( $settings['twinkle_about'] ); ?></p>
                                    </div>
                                <?php endif; ?>
                                <?php if ( !empty($settings['twinkle_phone']) ) : ?>
                                    <div class="number">
                                        <p><?php echo twinkle_kses( $settings['twinkle_phone_label'] ); ?> <a href="tel:<?php echo twinkle_kses( $settings['twinkle_phone'] ); ?>"><?php echo twinkle_kses( $settings['twinkle_phone'] ); ?></a></p>
                                    </div>
                                <?php endif; ?>

                                <?php if ($settings['show_profiles'] && is_array($settings['profiles'])) : ?>
                                    <div class="social-icon">
                                        <div class="title">
                                            <h6><?php echo twinkle_kses( $settings['twinkle_profile_label'] ); ?></h6>
                                        </div>
                                        <ul class="mb-0">
                                            <?php
                                            foreach ($settings['profiles'] as $profile) :
                                                $icon = $profile['name'];
                                                $url = esc_url($profile['link']['url']);

                                                printf('<li><a target="_blank" rel="noopener"  href="%s" class="elementor-repeater-item-%s"><i class="fab fa-%s" aria-hidden="true"></i></a></li>',
                                                    $url,
                                                    esc_attr($profile['_id']),
                                                    esc_attr($icon)
                                                );
                                            endforeach; ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        <?php
	}

}

$widgets_manager->register( new Twinkle_Team_Details() );