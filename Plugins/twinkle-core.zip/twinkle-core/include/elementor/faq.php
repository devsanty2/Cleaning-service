<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;

use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Faq extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_faq';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Faq', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        $this->start_controls_section(
            'twinkle_faq',
            [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'twinkle_subheading',
            [
                'label' => esc_html__('Sub Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Services', 'twinkle-core'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'twinkle-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_title',
            [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Our Best Service', 'twinkle-core'),
                'placeholder' => esc_html__('Type Heading Text', 'twinkle-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_description',
            [
                'label' => esc_html__('Description', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('will reenergize your ome and enhance your life. From everyday housekeeping to routine cleanings, our professional this to members can provide you.', 'twinkle-core'),
                'placeholder' => esc_html__('Type section description here', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'twinkle-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'twinkle-core'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'twinkle-core'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'twinkle-core'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'twinkle-core'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'twinkle-core'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'twinkle-core'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );

        $this->add_control(
            'twinkle_image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image', 'twinkle-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_twinkle_faq_list',
            [
                'label' => esc_html__('FAQ List', 'twinkle-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'twinkle_faq_active',
            [
                'label' => esc_html__( 'Open', 'twinkle-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'twinkle-core' ),
                'label_off' => esc_html__( 'Hide', 'twinkle-core' ),
                'return_value' => 'active',
                'default' => '',
            ]
        );

        $repeater->add_control(
            'twinkle_faq_title', [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'twinkle_faq_description', [
                'label' => esc_html__('Description', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'twinkle_faq_image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image', 'twinkle-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );
     
        $this->add_control(
            'twinkle_faq_list',
            [
                'label' => esc_html__('Faq List', 'twinkle-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'twinkle_faq_open' => 'active',
                        'twinkle_faq_title' => esc_html__('How you will be take a short time?', 'twinkle-core'),
                        'twinkle_faq_description' => esc_html__('We denounce with righteous indignation and dislike men demoralized by the charms of pleasure of the moment, they cannot foresee the pain and trouble.', 'twinkle-core'),
                        'twinkle_faq_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'twinkle_faq_title' => esc_html__('Why are the cleaning rate will be lowest price?', 'twinkle-core'),
                        'twinkle_faq_description' => esc_html__('We denounce with righteous indignation and dislike men demoralized by the charms of pleasure of the moment, they cannot foresee the pain and trouble.', 'twinkle-core'),
                        'twinkle_faq_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'twinkle_faq_title' => esc_html__('Your pricing table will be possible?', 'twinkle-core'),
                        'twinkle_faq_description' => esc_html__('We denounce with righteous indignation and dislike men demoralized by the charms of pleasure of the moment, they cannot foresee the pain and trouble.', 'twinkle-core'),
                        'twinkle_faq_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'twinkle_faq_title' => esc_html__('Why do I need to remove toys from the pool?', 'twinkle-core'),
                        'twinkle_faq_description' => esc_html__('We denounce with righteous indignation and dislike men demoralized by the charms of pleasure of the moment, they cannot foresee the pain and trouble.', 'twinkle-core'),
                        'twinkle_faq_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'twinkle_faq_title' => esc_html__('Do I have to cover my pool when it rains?', 'twinkle-core'),
                        'twinkle_faq_description' => esc_html__('We denounce with righteous indignation and dislike men demoralized by the charms of pleasure of the moment, they cannot foresee the pain and trouble.', 'twinkle-core'),
                        'twinkle_faq_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                ],
                'title_field' => '{{{ twinkle_faq_title }}}',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            '_section_layout_style',
            [
                'label' => __( 'Design Layout', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .faq-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_background_color',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .faq-one' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_title_style',
            [
                'label' => __( 'Title', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // Subheading    
        $this->add_control(
            '_subheading_options',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Subheading', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'subheading_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__tagline' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'subheading_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__tagline' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subheading_typography',
                'selector' => '{{WRAPPER}} .section-title__tagline',
            ]
        );

        // Title
        $this->add_control(
            '_heading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .section-title__title',
            ]
        );

        // Description
        $this->add_control(
            '_content_description',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Description', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'description_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__text' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .section-title__style2 .text-box p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__text' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .section-title__style2 .text-box p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .section-title__text, .section-title__style2 .text-box p',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_faq_list_style',
            [
                'label' => __( 'Faq List', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            '_heading_icon',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Icon', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'faq_icon_size',
            [
                'label' => __( 'Font Size', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .faq-one-accrodion .accrodion-title-inner .icon span::before' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            '_heading_faq_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'faq_title_typography',
                'selector' => '{{WRAPPER}} .faq-one-accrodion .accrodion-title h4',
            ]
        );

        $this->start_controls_tabs( 'faq_list_tabs' );
        
        $this->start_controls_tab(
            'faq_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );
        
        $this->add_control(
            'faq_title_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .faq-one-accrodion .accrodion-title h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .faq-one-accrodion .accrodion-title::before' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .faq-one-accrodion .accrodion-title-inner .icon span::before' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'faq_title_background',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .faq-one-accrodion .accrodion-title' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->start_controls_tab(
            'faq_active_tab',
            [
                'label' => esc_html__( 'Active', 'twinkle-core' ),
            ]
        );
        
        $this->add_control(
            'faq_title_color_active',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .faq-one-accrodion .accrodion.active .accrodion-title h4' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .faq-one-accrodion  .accrodion.active .accrodion-title::before' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .faq-one-accrodion .accrodion.active .accrodion-title-inner .icon span::before' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'faq_title_background_active',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .faq-one-accrodion .accrodion.active .accrodion-title' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->add_control(
            '_heading_description',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Description', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'faq_description_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .faq-one-accrodion .accrodion-content p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'faq_description_background',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .faq-one-accrodion .accrodion-content' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'faq_description_typography',
                'selector' => '{{WRAPPER}} .faq-one-accrodion .accrodion-content p',
            ]
        );

        $this->add_responsive_control(
            'faq_description_padding',
            [
                'label' => __( 'Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .faq-one-accrodion .accrodion-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        $this->add_render_attribute('title_args', 'class', 'section-title__title');

        if ( !empty($settings['twinkle_image']['url']) ) {
            $twinkle_image_url = !empty($settings['twinkle_image']['id']) ? wp_get_attachment_image_url( $settings['twinkle_image']['id'],'full') : $settings['twinkle_image']['url'];
            $twinkle_image_alt = get_post_meta($settings["twinkle_image"]["id"], "_wp_attachment_image_alt", true);
        }

		?>

            <!--Start Faq One-->
            <section class="faq-one pd-120-0-120">
                <div class="container">
                    <div class="section-title__style2">
                        <div class="section-title">
                            <?php if ( !empty($settings['twinkle_subheading']) ) : ?>  
                                <span class="section-title__tagline"><?php echo twinkle_kses( $settings['twinkle_subheading'] ); ?></span>
                            <?php endif; ?>
                            <?php
                                if ( !empty($settings['twinkle_title' ]) ) :
                                    printf( '<%1$s %2$s>%3$s</%1$s>',
                                        tag_escape( $settings['twinkle_title_tag'] ),
                                        $this->get_render_attribute_string( 'title_args' ),
                                        twinkle_kses( $settings['twinkle_title' ] )
                                        );
                                endif;
                            ?>
                        </div>
                        <?php if ( !empty($settings['twinkle_description']) ) : ?>
                            <div class="text-box">
                                <p><?php echo twinkle_kses( $settings['twinkle_description'] ); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="row">
                        <!--Start Faq One Content-->
                        <div class="col-xl-7">
                            <div class="faq-one__content">
                                <div class="faq-one__faq">
                                    <div class="accrodion-grp faq-one-accrodion" data-grp-name="faq-one-accrodion-1">
                                        <?php foreach ($settings['twinkle_faq_list'] as $item) : 
                                            if ( !empty($item['twinkle_faq_image']['url']) ) {
                                                $twinkle_faq_image_url = !empty($item['twinkle_faq_image']['id']) ? wp_get_attachment_image_url( $item['twinkle_faq_image']['id']) : $item['twinkle_faq_image']['url'];
                                                $twinkle_faq_image_alt = get_post_meta($item["twinkle_faq_image"]["id"], "_wp_attachment_image_alt", true);
                                            }
                                        ?>
                                            
                                            <div class="accrodion wow fadeInUp <?php echo esc_attr( $item['twinkle_faq_active'] ); ?>" data-wow-delay="0ms" data-wow-duration="1000ms">
                                                <div class="accrodion-title">
                                                    <div class="accrodion-title-inner">
                                                        <div class="icon">
                                                            <span class="icon-maps-and-flags"></span>
                                                        </div>
                                                        <div class="text">
                                                            <h4><?php echo twinkle_kses($item['twinkle_faq_title' ]); ?></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accrodion-content">
                                                    <div class="inner">
                                                        <?php if ( !empty($item['twinkle_faq_image']) ) : ?>
                                                            <div class="img-box">
                                                                <img src="<?php echo esc_url($twinkle_faq_image_url); ?>" alt="<?php echo esc_url($twinkle_faq_image_alt); ?>" />
                                                            </div>
                                                        <?php endif; ?>
                                                        <?php if ( !empty($item['twinkle_faq_description']) ) : ?>
                                                            <div class="text">
                                                                <p><?php echo twinkle_kses($item['twinkle_faq_description' ]); ?></p>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Faq One Content-->

                        <!--Start Faq One Img-->
                        <div class="col-xl-5">
                            <div class="faq-one__img">
                                <img src="<?php echo esc_url($twinkle_image_url); ?>" alt="<?php echo esc_url($twinkle_image_alt); ?>" />
                            </div>
                        </div>
                        <!--End Faq One Img-->
                    </div>
                </div>
            </section>
            <!--End Faq One-->

        <?php 
	}
}

$widgets_manager->register( new Twinkle_Faq() );