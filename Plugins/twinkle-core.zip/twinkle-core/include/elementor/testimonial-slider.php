<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Testimonial_Slider extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_testimonial_slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Testimonial', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        $this->start_controls_section(
            'twinkle_section_title',
            [
                'label' => esc_html__( 'Title & Content', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'twinkle_design_style',
            [
                'label' => esc_html__( 'Style', 'twinkle-core' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'layout-1',
                'options' => [
                    'layout-1' => esc_html__( 'Layout 1', 'twinkle-core' ),
                    'layout-2'  => esc_html__( 'Layout 2', 'twinkle-core' ),
                ],
            ]
        );

        $this->add_control(
            'twinkle_subtitle',
            [
                'label' => esc_html__('Sub Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Team', 'twinkle-core'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'twinkle_title',
            [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Our Team Member', 'twinkle-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'twinkle_description',
            [
                'label' => esc_html__('Description', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('will reenergize your ome and enhance your life. From everyday housekeeping to routine cleanings, our professional this to members can provide you.', 'twinkle-core'),
                'placeholder' => esc_html__('Type section description here', 'twinkle-core'),
                'condition' => [
                    'twinkle_design_style' => [ 'layout-2' ],
                ],
            ]
        );

        $this->add_control(
            'twinkle_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'twinkle-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'twinkle-core'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'twinkle-core'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'twinkle-core'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'twinkle-core'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'twinkle-core'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'twinkle-core'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );
        
        $this->end_controls_section();

        // Testimonial List
        $this->start_controls_section(
            'testimonial_list_content',
            [
                'label' => esc_html__( 'Testimonial List', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'testimonial_image',
            [
                'label' => esc_html__( 'Testimonial Image', 'twinkle-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'testimonial_name', [
                'label' => esc_html__( 'Name', 'twinkle-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Rashal Khan' , 'twinkle-core' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'testimonial_position', [
                'label' => esc_html__( 'Position', 'twinkle-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Founder' , 'twinkle-core' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'testimonial_description',
            [
                'label' => esc_html__( 'Description', 'twinkle-core' ),
                'type' => Controls_Manager::TEXTAREA,
                'rows' => 10,
                'default' => esc_html__( 'Hiring managers are busy people, so you need to make yourout the crowd as quickly as possible. In the first section. This should headline achievements', 'twinkle-core' ),
            ]
        );

        $repeater->add_control(
			'twinkle_star_rating',
			[
				'label'                 => esc_html__( 'Star Rating', 'plugin-domain' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'four-star',
				'options' => [
					'one-star'          => esc_html__( 'One', 'plugin-domain' ),
					'two-star'          => esc_html__( 'Two', 'plugin-domain' ),
					'three-star'        => esc_html__( 'Three', 'plugin-domain' ),
					'four-star'         => esc_html__( 'Four', 'plugin-domain' ),
					'five-star'         => esc_html__( 'Five', 'plugin-domain' ),
                ],
			]
        );

        $this->add_control(
            'testimonial_list',
            [
                'label' => esc_html__( 'Testimonial List', 'twinkle-core' ),
                'type' => Controls_Manager::REPEATER,
                'fields' =>  $repeater->get_controls(),
                'default' => [
                    [
                        'testimonial_name' => esc_html__( 'Rashal Khan', 'twinkle-core' ),
                        'testimonial_position' => esc_html__( 'Founder', 'twinkle-core' ),
                        'testimonial_description' => esc_html__( 'Hiring managers are busy people, so you need to make yourout the crowd as quickly as possible. In the first section. This should headline achievements', 'twinkle-core' ),
                    ],
                    [
                        'testimonial_name' => esc_html__( 'Rubel Islam', 'twinkle-core' ),
                        'testimonial_position' => esc_html__( 'Manager', 'twinkle-core' ),
                        'testimonial_description' => esc_html__( 'Hiring managers are busy people, so you need to make yourout the crowd as quickly as possible. In the first section. This should headline achievements', 'twinkle-core' ),
                    ],
                    [
                        'testimonial_name' => esc_html__( 'Rashal Khan', 'twinkle-core' ),
                        'testimonial_position' => esc_html__( 'Founder', 'twinkle-core' ),
                        'testimonial_description' => esc_html__( 'Hiring managers are busy people, so you need to make yourout the crowd as quickly as possible. In the first section. This should headline achievements', 'twinkle-core' ),
                    ],
                    [
                        'testimonial_name' => esc_html__( 'Rubel Islam', 'twinkle-core' ),
                        'testimonial_position' => esc_html__( 'Manager', 'twinkle-core' ),
                        'testimonial_description' => esc_html__( 'Hiring managers are busy people, so you need to make yourout the crowd as quickly as possible. In the first section. This should headline achievements', 'twinkle-core' ),
                    ],
                    [
                        'testimonial_name' => esc_html__( 'Rashal Khan', 'twinkle-core' ),
                        'testimonial_position' => esc_html__( 'Founder', 'twinkle-core' ),
                        'testimonial_description' => esc_html__( 'Hiring managers are busy people, so you need to make yourout the crowd as quickly as possible. In the first section. This should headline achievements', 'twinkle-core' ),
                    ],
                    [
                        'testimonial_name' => esc_html__( 'Rubel Islam', 'twinkle-core' ),
                        'testimonial_position' => esc_html__( 'Manager', 'twinkle-core' ),
                        'testimonial_description' => esc_html__( 'Hiring managers are busy people, so you need to make yourout the crowd as quickly as possible. In the first section. This should headline achievements', 'twinkle-core' ),
                    ],

                ],
                'title_field' => '{{{ testimonial_name }}}',
            ]
        );

        $this->end_controls_section();

        // TAB_STYLE
		$this->start_controls_section(
			'twinkle_testimonial_layout_style',
			[
				'label' => __( 'Layout', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-two' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_background_separator',
            [
                'label' => esc_html__( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-two::before' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-2' ],
                ],
            ]
        );

        $this->add_control(
            'content_background',
            [
                'label' => esc_html__( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-two' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->start_controls_tabs( 'tabs_layout_style' );

        $this->start_controls_tab(
            'layout_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'content_dots',
            [
                'label' => __( 'Dots', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .owl-dot-style1.owl-carousel .owl-dots .owl-dot' => 'border-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'layout_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'content_dots_hover',
            [
                'label' => __( 'Dots', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .owl-dot-style1.owl-carousel .owl-dot.active' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

		$this->end_controls_section();

        $this->start_controls_section(
            '_section_style_content',
            [
                'label' => __( 'Title & Content', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'section_title_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .section-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Subtitle    
        $this->add_control(
            '_heading_subtitle',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Subtitle', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'subtitle_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__tagline' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'subtitle_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__tagline' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typography',
                'selector' => '{{WRAPPER}} .section-title__tagline',
            ]
        );

        // Title
        $this->add_control(
            '_heading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Heading', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .section-title__title',
            ]
        );

        // Description
        $this->add_control(
            'twinkle_content_description',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Description', 'twinkle-core' ),
                'separator' => 'before',
                'condition' => [
                    'twinkle_design_style' => [ 'layout-2' ],
                ],
            ]
        );

        $this->add_responsive_control(
            'twinkle_description_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .section-title__style2 .text-box' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-2' ],
                ],
            ]
        );

        $this->add_control(
            'twinkle_description_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title__style2 .text-box' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-2' ],
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'twinkle_description_typography',
                'selector' => '{{WRAPPER}} .section-title__style2 .text-box',
                'condition' => [
                    'twinkle_design_style' => [ 'layout-2' ],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'twinkle_testimonial_list_style',
			[
				'label' => __( 'Testimonial List', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        // Icon
        $this->add_control(
            '_heading_icon',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Icon', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'icon_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one__single-icon' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-two__single-content .icon' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one__single-icon span::before' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-two__single-content .icon i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_color_hover',
            [
                'label' => __( 'Color (Hover)', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one__single:hover .testimonials-one__single-icon span::before' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->add_control(
            'icon_background',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-two__single-content .icon i' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-2' ],
                ],
            ]
        );

        // Name
        $this->add_control(
            '_heading_name',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Name', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'name_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one__single .client-info .text h2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-two__single .title-box h2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'name_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one__single .client-info .text h2' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-two__single .title-box h2' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'name_color_hover',
            [
                'label' => __( 'Color (Hover)', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one__single:hover .client-info .text h2' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'name_typography',
                'selector' => '{{WRAPPER}} .testimonials-one__single .client-info .text h2, .testimonial-two__single .title-box h2',
            ]
        );

        // Position
        $this->add_control(
            '_heading_position',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Position', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'position_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one__single .client-info .text p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-two__single .title-box span' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'position_color_hover',
            [
                'label' => __( 'Color (Hover)', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one__single:hover .client-info .text p' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'position_typography',
                'selector' => '{{WRAPPER}} .testimonials-one__single .client-info .text p, .testimonial-two__single .title-box span',
            ]
        );

        // Description
        $this->add_control(
            '_content_description',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Description', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'description_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one__single-text p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .testimonial-two__single-content p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one__single-text p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-two__single-content p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'description_color_hover',
            [
                'label' => __( 'Color (Hover)', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one__single:hover .testimonials-one__single-text p' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .testimonials-one__single-text p, .testimonial-two__single-content p',
            ]
        );

        $this->add_control(
            '_heading_layout_testimonial_list',
            [
                'label' => esc_html__( 'Layout', 'twinkle-core' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'testimonial_list_background',
            [
                'label' => esc_html__( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one__single' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-two__single-content' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .testimonial-two__single-content:before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'testimonial_list_background_hover',
            [
                'label' => esc_html__( 'Background (Hover)', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonials-one__single::before' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-1' ],
                ],
            ]
        );

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        $this->add_render_attribute('title_args', 'class', 'section-title__title');
        if ( !empty($settings['twinkle_image']['url']) ) {
            $twinkle_image = !empty($settings['twinkle_image']['id']) ? wp_get_attachment_image_url( $settings['twinkle_image']['id']) : $settings['twinkle_image']['url'];
            $twinkle_image_alt = get_post_meta($settings["twinkle_image"]["id"], "_wp_attachment_image_alt", true);
        }

		?>

        <?php if ( $settings['twinkle_design_style']  == 'layout-1' ): ?>
            <section class="testimonials-one pd-120-0-120">
                <div class="testimonials-one__bg" style="background-image: url(<?php echo get_template_directory_uri(); ?>/assets/images/backgrounds/testimonials-v1-bg.jpg);"></div>
                <div class="container">
                    <div class="section-title text-center">
                        <?php if ( !empty($settings['twinkle_subtitle']) ) : ?>    
                            <span class="section-title__tagline"><?php echo twinkle_kses( $settings['twinkle_subtitle'] ); ?></span>
                        <?php endif; ?>

                        <?php
                            if ( !empty($settings['twinkle_title' ]) ) :
                                printf( '<%1$s %2$s>%3$s</%1$s>',
                                    tag_escape( $settings['twinkle_title_tag'] ),
                                    $this->get_render_attribute_string( 'title_args' ),
                                    twinkle_kses( $settings['twinkle_title' ] )
                                    );
                            endif;
                        ?>
                    </div>
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="testimonials-one__carousel owl-carousel owl-theme owl-dot-style1">
                                <?php foreach ($settings['testimonial_list'] as $index => $item) : 
                                    if ( !empty($item['testimonial_image']['url']) ) {
                                        $twinkle_testimonial_image = !empty($item['testimonial_image']['id']) ? wp_get_attachment_image_url( $item['testimonial_image']['id']) : $item['testimonial_image']['url'];
                                        $twinkle_testimonial_image_alt = get_post_meta($item["testimonial_image"]["id"], "_wp_attachment_image_alt", true);
                                    }
                                ?>
                                <div class="testimonials-one__single">
                                    <div class="testimonials-one__single-icon">
                                        <span class="icon-left-quote"></span>
                                    </div>
                                    <?php if ( !empty($item['testimonial_description']) ) : ?>
                                        <div class="testimonials-one__single-text">
                                            <p><?php echo twinkle_kses($item['testimonial_description']); ?></p>
                                        </div>
                                    <?php endif; ?>
                                    <div class="client-info">
                                        <?php if ( !empty($twinkle_testimonial_image) ) : ?>
                                            <div class="img">
                                                <img src="<?php echo esc_url($twinkle_testimonial_image); ?>" alt="<?php echo esc_url($twinkle_testimonial_image_alt); ?>">
                                            </div>
                                        <?php endif; ?>
                                        <div class="text">
                                            <?php if ( !empty($item['testimonial_name']) ) : ?> 
                                                <h2><?php echo twinkle_kses($item['testimonial_name']); ?></h2>
                                            <?php endif; ?>
                                            <?php if ( !empty($item['testimonial_position']) ) : ?>
                                                <p><?php echo twinkle_kses($item['testimonial_position']); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        
        <?php elseif ( $settings['twinkle_design_style']  == 'layout-2' ): ?>

            <section class="testimonial-two">
                <div class="shape1 wow slideInRight" data-wow-delay="500ms"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/shapes/shape-1.png"
                        alt="" /></div>
                <div class="container">
                    <div class="section-title__style2">
                        <div class="section-title">
                            <?php if ( !empty($settings['twinkle_subtitle']) ) : ?>    
                                <span class="section-title__tagline"><?php echo twinkle_kses( $settings['twinkle_subtitle'] ); ?></span>
                            <?php endif; ?>

                            <?php
                                if ( !empty($settings['twinkle_title' ]) ) :
                                    printf( '<%1$s %2$s>%3$s</%1$s>',
                                        tag_escape( $settings['twinkle_title_tag'] ),
                                        $this->get_render_attribute_string( 'title_args' ),
                                        twinkle_kses( $settings['twinkle_title' ] )
                                        );
                                endif;
                            ?>
                        </div>
                        <?php if ( !empty($settings['twinkle_description']) ) : ?>
                            <p class="text-box"><?php echo twinkle_kses( $settings['twinkle_description'] ); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="testimonial-two__carousel owl-carousel owl-theme owl-dot-style1">
                                <?php foreach ($settings['testimonial_list'] as $index => $item) : 
                                    if ( !empty($item['testimonial_image']['url']) ) {
                                        $twinkle_testimonial_image = !empty($item['testimonial_image']['id']) ? wp_get_attachment_image_url( $item['testimonial_image']['id']) : $item['testimonial_image']['url'];
                                        $twinkle_testimonial_image_alt = get_post_meta($item["testimonial_image"]["id"], "_wp_attachment_image_alt", true);
                                    }
                                ?>
                                <div class="testimonial-two__single text-center">
                                    <div class="testimonial-two__single-content">
                                        <div class="icon">
                                            <i class="fas fa-quote-left"></i>
                                        </div>
                                        <?php if ( !empty($item['testimonial_description']) ) : ?>
                                            <p><?php echo twinkle_kses($item['testimonial_description']); ?></p>
                                        <?php endif; ?>
                                        <div class="rating twinkle-star-rating <?php esc_attr_e( $item['twinkle_star_rating'] ); ?>">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                    </div>
                                    <?php if ( !empty($twinkle_testimonial_image) ) : ?>
                                        <div class="testimonial-two__single-thumb">
                                            <img src="<?php echo esc_url($twinkle_testimonial_image); ?>" alt="<?php echo esc_url($twinkle_testimonial_image_alt); ?>">
                                        </div>
                                    <?php endif; ?>
                                    <div class="title-box">
                                        <?php if ( !empty($item['testimonial_name']) ) : ?> 
                                            <h2><?php echo twinkle_kses($item['testimonial_name']); ?></h2>
                                        <?php endif; ?>
                                        <?php if ( !empty($item['testimonial_position']) ) : ?>
                                            <span><?php echo twinkle_kses($item['testimonial_position']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        <?php endif; ?>

        <?php 
	}
}

$widgets_manager->register( new Twinkle_Testimonial_Slider() );