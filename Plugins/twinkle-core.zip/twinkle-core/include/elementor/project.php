<?php

namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Project extends Widget_Base {

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'twinkle_project';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Project', 'twinkle-core' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'twinkle-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'twinkle_core' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'twinkle-project' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {

        // Project group
        $this->start_controls_section(
            'twinkle_project',
            [
                'label' => esc_html__('Project List', 'twinkle-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'twinkle_Project_image',
            [
                'label' => esc_html__('Upload Icon Image', 'twinkle-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],

            ]
        );

        $repeater->add_control(
            'twinkle_subheading',
            [
                'label' => esc_html__('Sub Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Commercial', 'twinkle-core'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'twinkle-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'twinkle_title',
            [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Apertment Park Cleaning', 'twinkle-core'),
                'placeholder' => esc_html__('Type Heading Text', 'twinkle-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'twinkle_project_link_switcher',
            [
                'label' => esc_html__( 'Add project link', 'twinkle-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'twinkle-core' ),
                'label_off' => esc_html__( 'No', 'twinkle-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $repeater->add_control(
            'twinkle_project_link_type',
            [
                'label' => esc_html__( 'Project Link Type', 'twinkle-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'twinkle_project_link_switcher' => 'yes'
                ]
            ]
        );
        $repeater->add_control(
            'twinkle_project_link',
            [
                'label' => esc_html__( 'Project Link link', 'twinkle-core' ),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'https://your-link.com', 'twinkle-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'twinkle_project_link_type' => '1',
                    'twinkle_project_link_switcher' => 'yes',
                ]
            ]
        );
        $repeater->add_control(
            'twinkle_project_page_link',
            [
                'label' => esc_html__( 'Select Project Link Page', 'twinkle-core' ),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => twinkle_get_all_pages(),
                'condition' => [
                    'twinkle_project_link_type' => '2',
                    'twinkle_project_link_switcher' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'twinkle_Project_list',
            [
                'label' => esc_html__('project - List', 'twinkle-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'twinkle_Project_image' => Utils::get_placeholder_image_src(),
                    ],
                    [
                        'twinkle_Project_image' => Utils::get_placeholder_image_src(),
                    ],
                    [
                        'twinkle_Project_image' => Utils::get_placeholder_image_src(),
                    ],
                    [
                        'twinkle_Project_image' => Utils::get_placeholder_image_src(),
                    ],
                    [
                        'twinkle_Project_image' => Utils::get_placeholder_image_src(),
                    ],
                    [
                        'twinkle_Project_image' => Utils::get_placeholder_image_src(),
                    ],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'twinkle_layout_style',
			[
				'label' => __( 'Design Layout', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .project-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_background',
            [
                'label' => __( 'Content Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-one' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

        // TAB_STYLE
        $this->start_controls_section(
            'twinkle_project_list_style',
            [
                'label' => __( 'Project List', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'project_image_background_hover',
            [
                'label' => __( 'Image Background (Hover)', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-one__img:before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            '_icon_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Icon', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->start_controls_tabs( 'tabs_icon_style' );

        $this->start_controls_tab(
            'icon_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __( 'Text', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-one__hover a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_background_color',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-one__hover a' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'icon_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'icon_color_hover',
            [
                'label' => __( 'Text', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-one__hover a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .project-one__hover a:before' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_background_color_hover',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-one__hover a:hover' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .project-one__hover a:before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>
            <div class="row">
                <?php foreach ($settings['twinkle_Project_list'] as $key => $item) :
                    // Link
                    if ('2' == $item['twinkle_project_link_type']) {
                        $link = get_permalink($item['twinkle_project_page_link']);
                        $target = '_self';
                        $rel = 'nofollow';
                    } else {
                        $link = !empty($item['twinkle_project_link']['url']) ? $item['twinkle_project_link']['url'] : '';
                        $target = !empty($item['twinkle_project_link']['is_external']) ? '_blank' : '';
                        $rel = !empty($item['twinkle_project_link']['nofollow']) ? 'nofollow' : '';
                    }
                ?>
                    <div class="col-xl-4 col-lg-4">
                        <div class="projects-two__single">
                            <div class="projects-two__single-img">
                                <div class="projects-two__single-img-inner">
                                    <img class="parallax-img" src="<?php echo $item['twinkle_Project_image']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($item['twinkle_Project_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                </div>
                                <div class="overlay-content text-center">
                                    <div class="text">
                                        <p><?php echo twinkle_kses( $item['twinkle_subheading'] ); ?></p>
                                        <h3><a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>"><?php echo twinkle_kses( $item['twinkle_title'] ); ?></a></h3>
                                    </div>
                                    <ul>
                                        <li>
                                            <a class="img-popup" href="<?php echo $item['twinkle_Project_image']['url']; ?>">
                                                <i class="icon-plus"></i>
                                            </a>
                                        </li>
                                        <?php if (!empty($link)) : ?>
                                            <li><a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>"><span class="icon-link"></span></a></li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php 
    }
}

$widgets_manager->register( new Twinkle_Project() );