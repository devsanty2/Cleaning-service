<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Team extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_team';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Team', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		
        $this->start_controls_section(
            'twinkle_layout',
            [
                'label' => esc_html__('Design Layout', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'twinkle_design_style',
            [
                'label' => esc_html__('Select Layout', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'twinkle-core'),
                    'layout-2' => esc_html__('Layout 2', 'twinkle-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'member_content',
            [
                'label' => esc_html__('Members', 'twinkle-core'),
            ]
        );

        $this->add_control(
            'image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image', 'twinkle-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );                      

        $this->add_control(
            'name',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'Name', 'twinkle-core' ),
                'default' => __( 'Jessica Brown', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'name_url',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'show_label' => true,
                'label' => __( 'Name URL', 'twinkle-core' ),
                'placeholder' => __( 'Type link here', 'twinkle-core' ),
                'default' => __( '#', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'twinkle_design_style' => [ 'layout-2' ],
                ],
            ]
        );

        $this->add_control(
            'designation',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'show_label' => true,
                'label' => __( 'Designation', 'twinkle-core' ),
                'default' => __( 'Manager', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'web_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Website Address', 'twinkle-core' ),
                'placeholder' => __( 'Add your profile link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $this->add_control(
            'email_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Email', 'twinkle-core' ),
                'placeholder' => __( 'Add your email link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );           

        $this->add_control(
            'phone_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Phone', 'twinkle-core' ),
                'placeholder' => __( 'Add your phone link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $this->add_control(
            'facebook_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Facebook', 'twinkle-core' ),
                'default' => __( '#', 'twinkle-core' ),
                'placeholder' => __( 'Add your facebook link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );                

        $this->add_control(
            'twitter_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Twitter', 'twinkle-core' ),
                'default' => __( '#', 'twinkle-core' ),
                'placeholder' => __( 'Add your twitter link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'instagram_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Instagram', 'twinkle-core' ),
                'default' => __( '#', 'twinkle-core' ),
                'placeholder' => __( 'Add your instagram link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );       

        $this->add_control(
            'linkedin_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'LinkedIn', 'twinkle-core' ),
                'placeholder' => __( 'Add your linkedin link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $this->add_control(
            'youtube_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Youtube', 'twinkle-core' ),
                'placeholder' => __( 'Add your youtube link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );    

        $this->add_control(
            'flickr_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Flickr', 'twinkle-core' ),
                'placeholder' => __( 'Add your flickr link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $this->add_control(
            'vimeo_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Vimeo', 'twinkle-core' ),
                'placeholder' => __( 'Add your vimeo link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'behance_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Behance', 'twinkle-core' ),
                'placeholder' => __( 'Add your hehance link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $this->add_control(
            'dribble_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Dribbble', 'twinkle-core' ),
                'placeholder' => __( 'Add your dribbble link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $this->add_control(
            'pinterest_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Pinterest', 'twinkle-core' ),
                'placeholder' => __( 'Add your pinterest link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'gitub_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Github', 'twinkle-core' ),
                'placeholder' => __( 'Add your github link', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        ); 
        
        $this->end_controls_section();

        $this->start_controls_section(
			'design_layout_style',
			[
				'label' => __( 'Design Layout', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_responsive_control(
            'content_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .team-two__single' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'content_background',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content:before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .team-two__single-img' => 'background-color: {{VALUE}}',
                ],
            ]
        );

		$this->add_control(
            'content_background_hover',
            [
                'label' => __( 'Background (Hover)', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single:hover .overlay-content:before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .team-two__single-img::before' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .team-two__single-img::after' => 'background-color: {{VALUE}}',
                ],
            ]
        );



		$this->end_controls_section();

        $this->start_controls_section(
			'team_member_style',
			[
				'label' => __( 'Members', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        // Icon
        $this->add_control(
            '_heading_icon',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Icon', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->start_controls_tabs( 'tabs_icon_style' );

        $this->start_controls_tab(
            'icon_tab',
            [
                'label' => esc_html__( 'Normal', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .social-link a'    => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team-two__single-social-links ul li a'    => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_background',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .social-link a' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .team-two__single-social-links ul li a' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'icon_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'twinkle-core' ),
            ]
        );

        $this->add_control(
            'icon_color_hover',
            [
                'label'     => esc_html__( 'Text', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .social-link a:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .team-two__single-social-links ul li a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_background_hover',
            [
                'label'     => esc_html__( 'Background', 'twinkle-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .social-link a:hover' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .team-two__single-social-links ul li a:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        // Content
        $this->add_control(
            '_heading_content',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Content', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'member_name_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .title-box h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .team-two__single-title h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'member_name_color',
            [
                'label' => __( 'Name', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .title-box h3' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team-two__single-title h3 a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'member_name_typography',
                'selector' => '{{WRAPPER}} .team-one__single .overlay-content .title-box h3, .team-two__single-title h3',
            ]
        );

        $this->add_responsive_control(
            'member_designation_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .title-box p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .team-two__single-title p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'member_designation_color',
            [
                'label' => __( 'Designation', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-one__single .overlay-content .title-box p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .team-two__single-title p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'member_designation_typography',
                'selector' => '{{WRAPPER}} .team-one__single .overlay-content .title-box p, .team-two__single-title p',
            ]
        );


        $this->add_control(
            '_heading_name_layout',
            [
                'label' => esc_html__( 'Layout', 'text-domain' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

		$this->add_control(
            'member_name_background',
            [
                'label' => __( 'Designation', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .team-two__single-title' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'member_name_padding',
            [
                'label' => __( 'Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .team-two__single-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        
        if ( !empty($settings['image']['url']) ) {
            $twinkle_team_image_url = !empty($settings['image']['id']) ? wp_get_attachment_image_url( $settings['image']['id'], 'full') : $settings['image']['url'];
            $twinkle_team_image_alt = get_post_meta($settings["image"]["id"], "_wp_attachment_image_alt", true);
        }  

		?>

            <?php if ( $settings['twinkle_design_style']  == 'layout-1' ): ?>

                <div class="team-one__single">
                    <div class="team-one__single-img">
                        <?php if( !empty($twinkle_team_image_url) ) : ?>
                            <img src="<?php echo esc_url($twinkle_team_image_url); ?>" alt="<?php echo esc_attr($twinkle_team_image_alt); ?>">
                        <?php endif; ?>
                        <div class="overlay-content">
                            <div class="title-box">
                                <h3><?php echo twinkle_kses( $settings['name'] ); ?></h3>
                                <?php if( !empty($settings['designation']) ) : ?>
                                    <p><?php echo twinkle_kses( $settings['designation'] ); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="social-link">
                                <?php if( !empty($settings['facebook_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['facebook_title'] ); ?>"><i class="fab fa-facebook"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['twitter_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['twitter_title'] ); ?>"><i class="fab fa-twitter"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['pinterest_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['pinterest_title'] ); ?>"><i class="fab fa-pinterest-p"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['instagram_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['instagram_title'] ); ?>"><i class="fab fa-instagram"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['linkedin_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['linkedin_title'] ); ?>"><i class="fab fa-linkedin-in"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['youtube_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['youtube_title'] ); ?>"><i class="fab fa-youtube"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['flickr_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['flickr_title'] ); ?>"><i class="fab fa-flickr"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['vimeo_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['vimeo_title'] ); ?>"><i class="fab fa-vimeo-v"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['behance_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['behance_title'] ); ?>"><i class="fab fa-behance"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['dribble_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['dribble_title'] ); ?>"><i class="fab fa-dribbble"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['phone_title'] ) ) : ?>
                                    <a href="tel:<?php echo esc_url( $settings['phone_title'] ); ?>"><i class="fas fa-phone-alt"></i></a>
                                <?php endif; ?>  

                                <?php if( !empty($settings['gitub_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['gitub_title'] ); ?>"><i class="fab fa-github"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['web_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['web_title'] ); ?>"><i class="fas fa-globe"></i></a>
                                <?php endif; ?>  

                                <?php if( !empty($settings['email_title'] ) ) : ?>
                                    <a href="mailto:<?php echo esc_url( $settings['email_title'] ); ?>"><i class="fas fa-envelope"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

            <?php elseif ( $settings['twinkle_design_style']  == 'layout-2' ): ?>

                <div class="team-two__single">
                    <div class="team-two__single-img">
                        <?php if( !empty($twinkle_team_image_url) ) : ?>
                            <img src="<?php echo esc_url($twinkle_team_image_url); ?>" alt="<?php echo esc_attr($twinkle_team_image_alt); ?>">
                        <?php endif; ?>
                        <div class="team-two__single-social-links clearfix">
                            <ul>
                                <?php if( !empty($settings['facebook_title'] ) ) : ?>
                                    <li><a class="thm-bgc3-v2" href="<?php echo esc_url( $settings['facebook_title'] ); ?>"><i class="fab fa-facebook"></i></a></li>
                                <?php endif; ?>

                                <?php if( !empty($settings['twitter_title'] ) ) : ?>
                                    <li><a class="thm-bgc3-v2" href="<?php echo esc_url( $settings['twitter_title'] ); ?>"><i class="fab fa-twitter"></i></a></li>
                                <?php endif; ?>

                                <?php if( !empty($settings['pinterest_title'] ) ) : ?>
                                    <li><a class="thm-bgc3-v2" href="<?php echo esc_url( $settings['pinterest_title'] ); ?>"><i class="fab fa-pinterest-p"></i></a></li>
                                <?php endif; ?>

                                <?php if( !empty($settings['instagram_title'] ) ) : ?>
                                    <li><a class="thm-bgc3-v2" href="<?php echo esc_url( $settings['instagram_title'] ); ?>"><i class="fab fa-instagram"></i></a></li>
                                <?php endif; ?>

                                <?php if( !empty($settings['linkedin_title'] ) ) : ?>
                                    <li><a class="thm-bgc3-v2" href="<?php echo esc_url( $settings['linkedin_title'] ); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                                <?php endif; ?>

                                <?php if( !empty($settings['youtube_title'] ) ) : ?>
                                    <li><a class="thm-bgc3-v2" href="<?php echo esc_url( $settings['youtube_title'] ); ?>"><i class="fab fa-youtube"></i></a></li>
                                <?php endif; ?>

                                <?php if( !empty($settings['flickr_title'] ) ) : ?>
                                    <li><a class="thm-bgc3-v2" href="<?php echo esc_url( $settings['flickr_title'] ); ?>"><i class="fab fa-flickr"></i></a></li>
                                <?php endif; ?>

                                <?php if( !empty($settings['vimeo_title'] ) ) : ?>
                                    <li><a class="thm-bgc3-v2" href="<?php echo esc_url( $settings['vimeo_title'] ); ?>"><i class="fab fa-vimeo-v"></i></a></li>
                                <?php endif; ?>

                                <?php if( !empty($settings['behance_title'] ) ) : ?>
                                    <li><a class="thm-bgc3-v2" href="<?php echo esc_url( $settings['behance_title'] ); ?>"><i class="fab fa-behance"></i></a></li>
                                <?php endif; ?>

                                <?php if( !empty($settings['dribble_title'] ) ) : ?>
                                    <li><a class="thm-bgc3-v2" href="<?php echo esc_url( $settings['dribble_title'] ); ?>"><i class="fab fa-dribbble"></i></a></li>
                                <?php endif; ?>

                                <?php if( !empty($settings['phone_title'] ) ) : ?>
                                    <li><a class="thm-bgc3-v2" href="tel:<?php echo esc_url( $settings['phone_title'] ); ?>"><i class="fas fa-phone-alt"></i></a></li>
                                <?php endif; ?>  

                                <?php if( !empty($settings['gitub_title'] ) ) : ?>
                                    <li><a class="thm-bgc3-v2" href="<?php echo esc_url( $settings['gitub_title'] ); ?>"><i class="fab fa-github"></i></a></li>
                                <?php endif; ?>

                                <?php if( !empty($settings['web_title'] ) ) : ?>
                                    <li><a class="thm-bgc3-v2" href="<?php echo esc_url( $settings['web_title'] ); ?>"><i class="fas fa-globe"></i></a></li>
                                <?php endif; ?>  

                                <?php if( !empty($settings['email_title'] ) ) : ?>
                                    <li><a class="thm-bgc3-v2" href="mailto:<?php echo esc_url( $settings['email_title'] ); ?>"><i class="fas fa-envelope"></i></a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>

                    <div class="team-two__single-title text-center">
                        <h3><a href="<?php echo esc_url( $settings['name_url'] ); ?>"><?php echo twinkle_kses( $settings['name'] ); ?></a></h3>
                        <?php if( !empty($settings['designation']) ) : ?>
                            <p><?php echo twinkle_kses( $settings['designation'] ); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

            <?php endif; ?>

		<?php
	}
}

$widgets_manager->register( new Twinkle_Team() );