<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Contact_Info extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_contact_info';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Contact Info', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        $this->start_controls_section(
            'twinkle_contact_info',
            [
                'label' => esc_html__('Contact Info', 'twinkle-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        if (twinkle_is_elementor_version('<', '2.6.0')) {
            $this->add_control(
                'twinkle_contact_info_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-map-marker',
                ]
            );
        } else {
            $this->add_control(
                'twinkle_contact_info_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fa fa-map-marker',
                        'library' => 'solid',
                    ],
                ]
            );
        }

        $this->add_control(
            'twinkle_contact_info_title', 
            [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__( 'Our Location', 'twinkle-core' ),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'twinkle_info_type',
            [
                'label' => esc_html__('Info Type', 'twinkle-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'text' => esc_html__('Text', 'twinkle-core'),
                    'phone' => esc_html__('Phone', 'twinkle-core'),
                    'email' => esc_html__('Email', 'twinkle-core'),
                    'url' => esc_html__('URL', 'twinkle-core'),
                ],
                'default' => 'text',
            ]
        );

        $repeater->add_control(
            'twinkle_contact_info_text', [
                'label' => esc_html__('Text', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'twinkle_contact_info_url',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'URL', 'twinkle-core' ),
                'default' => __( '#', 'twinkle-core' ),
                'placeholder' => __( 'Type url here', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'twinkle_info_type' => [ 'phone', 'email', 'url' ],
                ],
            ]
        );
     
        $this->add_control(
            'twinkle_contact_info_list',
            [
                'label' => esc_html__('Info List', 'twinkle-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'twinkle_contact_info_text' => esc_html__('354 Oakridge, Camden NJ 08102 - USA', 'twinkle-core'),
                    ],
                    [
                        'twinkle_contact_info_text' => esc_html__('354 Oakridge, Camden NJ 08102 - USA', 'twinkle-core'),
                    ],
                ],
                'title_field' => '{{{ twinkle_contact_info_text }}}',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            '_section_contact_info_style',
            [
                'label' => __( 'Contact Info', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            '_heading_layout',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Layout', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'content_background',
            [
                'label' => esc_html__( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-box__single-text' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_bottom_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .contact-box__single-text' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            '_heading_icon',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Icon', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-box__single-icon' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_background',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-box__single-icon::before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            '_content_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'title_bottom_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .contact-box__single-text h2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-box__single-text h2 a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .contact-box__single-text h2 a',
            ]
        );

        $this->add_control(
            '_heading_info',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Info', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'info_bottom_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .contact-box__single-text p a' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .contact-box__single-text p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'info_color',
            [
                'label' => __( 'Text Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .contact-box__single-text p a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .contact-box__single-text p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'info_typography',
                'selector' => '{{WRAPPER}} .contact-box__single-text p a, .contact-box__single-text p',
            ]
        );

        $this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

            <div class="contact-box__single text-center">
                <?php if (!empty($settings['twinkle_contact_info_icon']) || !empty($settings['twinkle_contact_info_selected_icon']['value'])) : ?>
                    <div class="contact-box__single-icon">
                        <?php twinkle_render_icon($settings, 'twinkle_contact_info_icon', 'twinkle_contact_info_selected_icon'); ?>
                    </div>
                <?php endif; ?>
                
                <div class="contact-box__single-text">
                    <?php if ( !empty($settings['twinkle_contact_info_title']) ) : ?>
                        <h2><a href="#"><?php echo twinkle_kses($settings['twinkle_contact_info_title' ]); ?></a></h2>
                    <?php endif; ?>
                    <?php foreach ($settings['twinkle_contact_info_list'] as $item) : ?>
                        <?php if ( $item['twinkle_info_type']  == 'text' ): ?>
                            <p><?php echo twinkle_kses($item['twinkle_contact_info_text' ]); ?></p>
                        <?php elseif ( $item['twinkle_info_type']  == 'phone' ): ?>
                            <p><a href="tel:<?php echo esc_attr($item['twinkle_contact_info_url' ]); ?>"><?php echo twinkle_kses($item['twinkle_contact_info_text' ]); ?></a></p>
                        <?php elseif ( $item['twinkle_info_type']  == 'email' ): ?>
                            <p><a href="mailto:<?php echo esc_attr($item['twinkle_contact_info_url' ]); ?>"><?php echo twinkle_kses($item['twinkle_contact_info_text' ]); ?></a></p>
                        <?php elseif ( $item['twinkle_info_type']  == 'url' ): ?>
                            <p><a href="<?php echo esc_url($item['twinkle_contact_info_url' ]); ?>"><?php echo twinkle_kses($item['twinkle_contact_info_text' ]); ?></a></p>
                        <?php endif; ?>
                    <?php endforeach; ?> 
                </div>
            </div>

        <?php 
	}
}

$widgets_manager->register( new Twinkle_Contact_Info() );