<?php
namespace TwinkleCore\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Twinkle Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Brand_Slider extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_brand_slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Brand Slider', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
            'twinkle_brand_section',
            [
                'label' => __( 'Brand Item', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

		$this->add_control(
			'twinkle_design_style',
			[
				'label' => esc_html__( 'Layout', 'twinkle-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'layout-1',
				'options' => [
					'layout-1' => esc_html__( 'Layout 1', 'twinkle-core' ),
					'layout-2'  => esc_html__( 'Layout 2', 'twinkle-core' ),
				],
			]
		);

        $repeater = new Repeater();

        $repeater->add_control(
            'twinkle_brand_image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image', 'twinkle-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'twinkle_brand_url',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'URL', 'twinkle-core' ),
                'default' => __( '#', 'twinkle-core' ),
                'placeholder' => __( 'Type url here', 'twinkle-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'twinkle_brand_slides',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => esc_html__( 'Brand Item', 'twinkle-core' ),
                'default' => [
                    [
                        'twinkle_brand_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'twinkle_brand_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'twinkle_brand_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'twinkle_brand_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'twinkle_brand_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                ]
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'twinkle_brand_style',
			[
				'label' => __( 'Brand Item', 'twinkle-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .brand-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'content_background',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .brand-one .single-slide' => 'background-color: {{VALUE}}',
                ],
            ]
        );

		$this->add_control(
            'content_border',
            [
                'label' => __( 'Border', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .brand-one .single-slide:before' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} .brand-one .single-slide:after' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
		
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

			<?php if ( $settings['twinkle_design_style']  == 'layout-1' ): ?>
				<section class="brand-one">
					<div class="container">
						<div class="brand-one__carousel thm-swiper__slider owl-theme owl-carousel">
							<?php foreach ($settings['twinkle_brand_slides'] as $item) : 
								if ( !empty($item['twinkle_brand_image']['url']) ) {
									$twinkle_brand_image_url = !empty($item['twinkle_brand_image']['id']) ? wp_get_attachment_image_url( $item['twinkle_brand_image']['id']) : $item['twinkle_brand_image']['url'];
									$twinkle_brand_image_alt = get_post_meta($item["twinkle_brand_image"]["id"], "_wp_attachment_image_alt", true);
								}
								?>
								<div class="single-slide">
									<a href="<?php echo esc_url($item['twinkle_brand_url']); ?>">
										<img src="<?php echo esc_url($twinkle_brand_image_url); ?>" alt="<?php echo esc_url($twinkle_brand_image_alt); ?>">
									</a>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</section>

			<?php elseif ( $settings['twinkle_design_style']  == 'layout-2' ): ?>

				<section class="brand-one brand-one--two">
					<div class="container">
						<div class="brand-one__carousel thm-swiper__slider owl-theme owl-carousel">
							<?php foreach ($settings['twinkle_brand_slides'] as $item) : 
								if ( !empty($item['twinkle_brand_image']['url']) ) {
									$twinkle_brand_image_url = !empty($item['twinkle_brand_image']['id']) ? wp_get_attachment_image_url( $item['twinkle_brand_image']['id']) : $item['twinkle_brand_image']['url'];
									$twinkle_brand_image_alt = get_post_meta($item["twinkle_brand_image"]["id"], "_wp_attachment_image_alt", true);
								}
								?>
								<div class="single-slide">
									<a href="<?php echo esc_url($item['twinkle_brand_url']); ?>">
										<img src="<?php echo esc_url($twinkle_brand_image_url); ?>" alt="<?php echo esc_url($twinkle_brand_image_alt); ?>">
									</a>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</section>

			<?php endif; ?>

		<?php
	}


}

$widgets_manager->register( new Twinkle_Brand_Slider() );