<?php

namespace TwinkleCore\Widgets;
use \Elementor\Widget_Base;
use \Elementor\Control_Media;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Twinkle_Service_List extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'twinkle_service_list';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Service List', 'twinkle-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'twinkle-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'twinkle_core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'twinkle-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        $this->start_controls_section(
            'twinkle_service_list',
            [
                'label' => esc_html__('Gallery Info', 'twinkle-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'twinkle-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'twinkle_title', [
                'label' => esc_html__('Title', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('All Service', 'twinkle-core'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'twinkle_service_list_title', [
                'label' => esc_html__('Text', 'twinkle-core'),
                'description' => twinkle_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        
        $repeater->add_control(
            'twinkle_service_link_switcher',
            [
                'label' => esc_html__( 'Add Services link', 'twinkle-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'twinkle-core' ),
                'label_off' => esc_html__( 'No', 'twinkle-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $repeater->add_control(
            'twinkle_service_link_type',
            [
                'label' => esc_html__( 'Service Link Type', 'twinkle-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'twinkle_service_link_switcher' => 'yes'
                ]
            ]
        );

        $repeater->add_control(
            'twinkle_service_link',
            [
                'label' => esc_html__( 'Service Link link', 'twinkle-core' ),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'https://your-link.com', 'twinkle-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'twinkle_service_link_type' => '1',
                    'twinkle_service_link_switcher' => 'yes',
                ]
            ]
        );

        $repeater->add_control(
            'twinkle_service_page_link',
            [
                'label' => esc_html__( 'Select Service Link Page', 'twinkle-core' ),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => twinkle_get_all_pages(),
                'condition' => [
                    'twinkle_service_link_type' => '2',
                    'twinkle_service_link_switcher' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'twinkle_service_list_list',
            [
                'label' => esc_html__('Info List', 'twinkle-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'twinkle_service_list_title' => esc_html__('Bedroom Cleaning', 'twinkle-core'),
                    ],
                    [
                        'twinkle_service_list_title' => esc_html__('Window Cleaning', 'twinkle-core'),
                    ],
                    [
                        'twinkle_service_list_title' => esc_html__('Office Cleaning', 'twinkle-core'),
                    ],
                    [
                        'twinkle_service_list_title' => esc_html__('Commercial Cleaning', 'twinkle-core'),
                    ],
                    [
                        'twinkle_service_list_title' => esc_html__('House Cleaning', 'twinkle-core'),
                    ],
                    [
                        'twinkle_service_list_title' => esc_html__('Car Cleaning', 'twinkle-core'),
                    ],
                ],
                'title_field' => '{{{ twinkle_service_list_title }}}',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            '_section_layout_style',
            [
                'label' => __( 'Design Layout', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'twinkle-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .service-details__sidebar' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .service-details__sidebar' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_background_color',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details__sidebar' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'content_background_active',
            [
                'label' => __( 'Bottom Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details__sidebar::before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            '_section_info_list_style',
            [
                'label' => __( 'Info List', 'twinkle-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            '_heading_title',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Title', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details__sidebar-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .service-details__sidebar-title',
            ]
        );

        $this->add_responsive_control(
            'bottom_spacing',
            [
                'label' => __( 'Bottom Spacing', 'twinkle-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 5,
					],
				],
                'selectors' => [
                    '{{WRAPPER}} .service-details__sidebar-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            '_content_list',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'List', 'twinkle-core' ),
                'separator' => 'before'
            ]
        );

        $this->start_controls_tabs( '_list_tabs' );
        
        $this->start_controls_tab(
            'list_normal_tab',
            [
                'label' => esc_html__( 'Normal', 'text-domain' ),
            ]
        );
        
        $this->add_control(
            'list_color',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details__sidebar-list-item a' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'list_background_color',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details__sidebar-list-item a' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->start_controls_tab(
            'list_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'text-domain' ),
            ]
        );
        
        $this->add_control(
            'list_color_hover',
            [
                'label' => __( 'Color', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details__sidebar-list-item a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'list_background_color_hover',
            [
                'label' => __( 'Background', 'twinkle-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-details__sidebar-list-item a:after' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .all-project__content',
            ]
        );

        $this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

            <div class="service-details__sidebar">
                <h2 class="service-details__sidebar-title"><?php echo twinkle_kses($settings['twinkle_title' ]); ?></h2>
                <ul class="service-details__sidebar-list pl-0">
                    <?php foreach ($settings['twinkle_service_list_list'] as $item) : 
                        // Link
                        if ('2' == $item['twinkle_service_link_type']) {
                            $link = get_permalink($item['twinkle_service_page_link']);
                            $target = '_self';
                            $rel = 'nofollow';
                        } else {
                            $link = !empty($item['twinkle_service_link']['url']) ? $item['twinkle_service_link']['url'] : '';
                            $target = !empty($item['twinkle_service_link']['is_external']) ? '_blank' : '';
                            $rel = !empty($item['twinkle_service_link']['nofollow']) ? 'nofollow' : '';
                        }
                    ?>
                        <?php if ( !empty($item['twinkle_service_list_title']) ) : ?>
                            <li class="service-details__sidebar-list-item">
                                <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>">
                                    <?php echo twinkle_kses($item['twinkle_service_list_title' ]); ?>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            </div>

        <?php 
	}
}

$widgets_manager->register( new Twinkle_Service_List() );