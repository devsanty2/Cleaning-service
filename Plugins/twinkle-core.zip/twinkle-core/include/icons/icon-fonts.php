<?php
    	
// Append new icons
$twinkle_icons = array(
	'icon-email',
	'icon-wall-clock',
	'icon-house',
	'icon-window-cleaning',
	'icon-flat',
	'icon-carpet-cleaner',
	'icon-house-1',
	'icon-house-2',
	'icon-electric-vehicle',
	'icon-link',
	'icon-left-quote',
	'icon-plus',
	'icon-facebook',
	'icon-instagram',
	'icon-twitter',
	'icon-maps-and-flags',
	'icon-certificate-1',
	'icon-rating',
	'icon-certificate',
	'icon-computer',
); 

return $twinkle_icons;